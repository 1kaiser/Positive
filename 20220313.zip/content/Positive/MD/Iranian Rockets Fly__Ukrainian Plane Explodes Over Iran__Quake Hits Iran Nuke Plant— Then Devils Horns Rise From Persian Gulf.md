        Iranian Rockets Fly\*\*Ukrainian Plane Explodes Over Iran\*\*Quake Hits Iran Nuke Plant—Then Devils Horns Rise From Persian Gulf  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Saudi Arabia Displays Missile Wreckage That Took Out Refinery—All Of Which Was Made For NATO Forces](https://www.whatdoesitmean.com/index2988.htm)**

**[Fears Grow Over Possible “_Missing_” US Nuclear Warhead As Mysterious Drones Flood Skies Over Colorado](https://www.whatdoesitmean.com/index3082.htm)**

**[America Seems Not To Know That War With Iran Is Impossible—Islamic Countries Simply Don’t Exist](https://www.whatdoesitmean.com/index3088.htm)**

**[Trump Gambit To Destroy Saudi Arabia Sees Iran Raising Blood Red Shiite Battle Flag For First Time Since Middle Ages](https://www.whatdoesitmean.com/index3089.htm)**

**[Attack Destroying Rare American Spy Planes Throws Missing Nuke Into Ready To Explode Middle East Caldron](https://www.whatdoesitmean.com/index3090.htm)**

**[Trump Initiated Iranian Chaos Theory Masterplan Sees Terrified Families Of Saudi Princes Fleeing To Europe](https://www.whatdoesitmean.com/index3091.htm)**

January 8, 2020

**Iranian Rockets Fly\*\*Ukrainian Plane Explodes Over Iran\*\*Quake Hits Iran Nuke Plant—Then Devils Horns Rise From Persian Gulf**

By: Sorcha Faal, and as reported to her Western Subscribers

A riveting new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today noting the **[unannounced surprise meeting](https://www.independent.co.uk/news/world/middle-east/putin-syria-damascus-assad-russia-a9273781.html)** held in **Damascus-Syria** yesterday between **President Putin** and his **Syrian** counterpart **President Bashar al-Assad** to discuss the “**[Iranian Chaos Theory Masterplan](https://www.whatdoesitmean.com/index3091.htm)**” initiated by **President Donald Trump** to bring about **[a lasting peace](https://www.whatdoesitmean.com/index3089.htm)** between the **West** and **Islamic** nations in the **Middle East**, states that **Trump’s** main agenda to destroy the regional power of **Sunni Muslim** terror supporting **Saudi Arabia** got a boost when **Iran** staged their missile launch charade a few hours ago against **US** bases in **Iraq**—that **[caused global oil prices to soar](https://oilprice.com/Latest-Energy-News/World-News/Oil-Prices-Soar-As-Irans-Retaliation-Begins.html)** to the benefit of **Iran** and **Russia**—but **[wiped out billions-of-dollars of Saudi wealth after their Saudi Aramco stock sank 10%](https://www.marketwatch.com/story/saudi-aramco-stock-sank-10-on-middle-east-tension-but-heres-why-its-still-too-pricey-2020-01-08)**\--a beginning of woes to be experienced by the **Saudis** whose **[Iranian supporting Shiite extremist organization, Hezbollah al-Hejaz, issued a statement calling for the revenge of General Soleimani’s death that includes their targeting Saudi rulers](https://carnegieendowment.org/2020/01/07/what-does-u.s.-killing-of-soleimani-mean-for-saudi-arabia-pub-80722)**—and whose expectation of the **Saudis** being supported by the **US** as they battle for their kingdom’s survival looks more unlikely by the day—best exampled by the **3 January** call held between **US Secretary of State Michael Pompeo** and **Saudi Crown Prince Mohammed bin Salman Al Saud**—the **American** readout of which for domestic propaganda purposes had such statements as: “**_[The Secretary thanked the Crown Prince for Saudi Arabia’s steadfast support and for recognizing the continuing aggressive threats posed by the Islamic Revolutionary Guard Corps Qods Force](https://www.state.gov/secretary-michael-r-pompeos-call-with-saudi-crown-prince-mohammed-bin-salman-al-saud/)_**”—but whose truer meaning **Saudi** readout of shows the **US** is tired of supporting endless wars: “**_[During telephone conversation, the latest developments in Iraq and efforts being exerted to defuse tensions in the region were reviewed, in addition to discussing what can be done to maintain peace and stability in the Middle East in this turbulent period](https://www.spa.gov.sa/viewfullstory.php?lang=en&newsid=2019026#2019026)_**”—all occurring near simultaneously with the **[explosion of an Ukrainian airliner taking off from the Tehran-Iran airport killing all 185 passengers and crew](https://www.rt.com/news/477693-engine-catching-fire-crash/)**—and a **[magnitude 4.9 earthquake striking the Bushehr nuclear plant in Iran](https://www.aninews.in/news/world/middle-east/49-magnitude-quake-jolts-iran20200108102927/)**—with all of this chaotic turmoil then being fittingly met with **[a rare “_Devils Horns_” eclipse rising from the Persian Gulf and reaching down from the clouds to halo an airliner](https://www.thesun.co.uk/news/10694515/red-devil-horns-sunrise-photos-captured-rare-solar-eclipse-mirage/)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](hon21.png)

![](hon22.jpg)

**Rare “_Devils Horn_” eclipse rises from Persian Gulf (_top photo_) and reaches down from clouds to halo airliner (_bottom photo_) as rockets fly, a plane explodes and quake strikes nuclear plant.**

According to this report, yesterday the **Foreign Ministry** **[exhaustively detailed](https://www.whatdoesitmean.com/index3091.htm)** the chaos theory masterplan initiated by **President Trump**—whose main “**_theater of the absurd_**” components of means nothing is as it first appears, and will frequently be the exact opposite of what one thinks is occurring—the only exception being the **Ministry** noting that the “**_[only actual battlefield death, so far, in the maelstrom of this chaos remains General Soleimani—the sacrificed chess piece pawn who began the most critical game of war and peace ever seen since World War II](https://www.whatdoesitmean.com/index3091.htm)_**”—the same **General Soleimani** who, in **July-2018**, threatened **Trump** with the words “**_[Mr. Gambler, Trump! I’m telling you that WE ARE CLOSE TO YOU, exactly where you wouldn’t think that we are](https://www.redstate.com/elizabeth-vaughn/2020/01/07/761476/)_**”—a threat made all too real this past **Sunday**, **5 January**, when a **[supposedly disgraced ex-US Marine named Brandon Magnan, and an as yet unidentified other man shockingly made it past two high-security checkpoints at a Florida airport, where Trump was preparing to board Air Force One, before they were captured](https://ultimatemilitaryalerts.com/a-disgraced-ex-marine-faked-his-way-past-presidential-security-checkpoints-at-a-florida-airport/)**.

As to the true and dangerous nature of **General Soleimani** being kept hidden from the **American** people, this report details, among the most important persons warning about this international terror leader was **President Trump’s** former national security advisor **US Army General Michael Flynn**—who, in **2015**, while working for the **Obama Regime**, sent out a warning **Tweet** asking: “**_[Soleimani–#1 terrorist in the world, now a good guy & Iran, #1 State Sponsor of Terrorism, now has nuke capabilities–what just happened?](https://www.thegatewaypundit.com/2020/01/this-2015-tweet-from-general-flynn-about-soleimani-is-one-reason-why-the-deep-state-targeted-flynn-for-ruin/)_**”—a warning **Tweet** that, of course, made **General Flynn** a prime target for **Deep State** destruction—and **[yesterday further saw these Deep State maniacs demanding that a judge throw General Flynn in prison](https://www.thegatewaypundit.com/2020/01/breaking-doj-accuses-general-flynn-of-failing-to-cooperate-and-asks-flynn-be-incarcerated-for-up-to-6-months/)**.

Most interesting to note about the leftist lies being told about **General Soleimani** to the **American** people, though, this report notes, is that at the same time **The New York Times** blared its comical headline “**[The Nightmare Stage of Trump’s Rule Is Here](https://www.nytimes.com/2020/01/06/opinion/trump-iran.html)**” for a distorted article warning that “**_[unstable and impeached, the president pushes the US toward war with Iran](https://www.nytimes.com/2020/01/06/opinion/trump-iran.html)_**” because **President Trump** ordered **Soleimani** assassinated—buried deep within in its pages was a little noticed or read other article about **Soleimani** titled “**[Trump Kills Iran’s Most Overrated Warrior](https://www.nytimes.com/2020/01/03/opinion/iran-general-soleimani.html)**”—which explained why **Trump** and **Iran’s Supreme Leader** turned **Soleimani** into a sacrificial chess piece pawn:

**_One day they may name a street after President Trump in Tehran._**

**_Why?_**

**_Because Trump just ordered the assassination of possibly the dumbest man in Iran and the most overrated strategist in the Middle East: Major General Qassim Soleimani._**

**_Think of the miscalculations this guy made. In 2015, the United States and the major European powers agreed to lift virtually all their sanctions on Iran, many dating back to 1979, in return for Iran halting its nuclear weapons program for a mere 15 years, but still maintaining the right to have a peaceful nuclear program. It was a great deal for Iran. Its economy grew by over 12 percent the next year._**

**_And what did Soleimani do with that windfall?_**

**_Mr. “Military Genius” Soleimani decided that he would overreach again and try to put direct pressure on Israel._**

**_He would do this by trying to transfer precision-guided rockets from Iran to Iranian proxy forces in Lebanon and Syria._**

**_Alas, Soleimani discovered that fighting Israel — specifically, its combined air force, special forces, intelligence and cyber — is not like fighting the Nusra front or the Islamic State._**

**_The Israelis hit back hard, sending a whole bunch of Iranians home from Syria in caskets and hammering their proxies as far away as Western Iraq._**

**_Indeed, Israeli intelligence had so penetrated Soleimani’s Quds Force and its proxies that Soleimani would land a plane with precision munitions in Syria at 5 p.m., and the Israeli air force would blow it up by 5:30 p.m. Soleimani men were like fish in a barrel._**

**_If Iran had a free press and a real parliament,_** **_he would have been fired for colossal mismanagement_****_._**

**_It was Soleimani and his proxies — his “kingmakers” in Lebanon, Syria and Iraq — who increasingly_** **_came to be seen, and hated, as imperial powers in the region, even more so than Trump’s America_****_._**

**_This triggered popular, authentic, bottom-up democracy movements in Lebanon and Iraq that involved_** **_Sunnis and Shiites locking arms together_** **_to demand noncorrupt, nonsectarian democratic governance._**

**_On Nov. 27, Iraqi Shiites —_** **_yes, Iraqi Shiites_** **_— burned down the Iranian consulate in Najaf, Iraq, removing the Iranian flag from the building and putting an Iraqi flag in its place._**

 **_That was after Iraqi Shiites, in September 2018, set the Iranian consulate in Basra ablaze, shouting condemnations of Iran’s interference in Iraqi politics._**

![](hon23.jpg)

As for the “**_crushing revenge_**” charade rocket attack to avenge the death of **General Soleimani**, this report notes, it began with **[Iran calling Iraqi Prime Minister Adil Abdul-Mahdi to pre-warn him about what was going to occur](https://sputniknews.com/middleeast/202001081077971856-live-updates-iran-launches-missile-strike-on-us-forces-in-iraq/#article_item_1077976859)**—which allowed both **US** and **Iraqi** troops the time they needed to go into their bomb proof bunkers so none of them would be harmed—an “**_attack_**” followed by **Iran** basically saying that’s it and “**_[we do not seek escalation or war](https://thehill.com/policy/international/middle-east-north-africa/477267-iranian-diplomat-after-strike-we-do-not-seek)_**”—that **President Trump** immediately responded to with his **Tweet** saying “**_[All is well](https://thehill.com/homenews/administration/477265-all-is-well-trump-tweets-after-iran-hits-iraq-base-housing-us-troops)_**”, going to bed, and [telling the **American** people he’d talk to them in the morning](https://thehill.com/homenews/administration/477265-all-is-well-trump-tweets-after-iran-hits-iraq-base-housing-us-troops)—all with **Trump** knowing that **Iranian President Rouhani** has declared that “**_[all US troops out of Middle East will be Iran’s final answer to Soleimani’s assassination](https://www.rt.com/news/477717-iran-kicking-us-troops-out/)_**”—which is exactly what **Trump** has been trying to do since the very day he took office.

![](hon24.jpg)

Unlike in past times when **President Trump** was blocked from bringing all of his **US** troops home from the **Middle East** and ending his nation’s endless wars, this report concludes, this time around he comically has all of his enemies crying for the same thing to be done before he can start **World War III**—a masterful move as **Trump** knows his deranged enemies will **_ALWAYS_** choose to take the opposite side of whatever they think his is—but whose endgame is yet to play out—thus meaning that more heart-stopping moves are going to made in this most dangerous of games before it’s finished—and makes one glad that even before he was elected, his personal doctor told the entire world: “**_[If elected, Mr. Trump, I can state unequivocally, will be the healthiest individual ever elected to the presidency](https://www.rt.com/news/477717-iran-kicking-us-troops-out/)_**”.

![](hon25.jpg)

January 8, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Trump Throws Leftists Into Chaos After Committing Crimestop Thought Offense](https://www.whatdoesitmean.com/index3080pl.htm)**

**[Magical Millennials Chart History Free Star-Path To Their Own Destruction](https://www.whatdoesitmean.com/index3080.htm)**

**[Lincoln Jailed Over 13,000 Journalists—Roosevelt Went Around Them—Now Trump Presides Over Their Destruction](https://www.whatdoesitmean.com/index3055pl.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**