        Climate Cultists In America Made To Pray To Plants Begin Committing Suicide  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Unintended Nuclear War Warning Issued—Whose First Victims Of Said Should Be Climate Crazies](https://www.whatdoesitmean.com/index2981.htm)**

September 20, 2019

**Climate Cultists In America Made To Pray To Plants Begin Committing Suicide**

By: Sorcha Faal, and as reported to her Western Subscribers

A very concerning new **Ministry of Foreign Affairs** ([MoFA](http://government.ru/en/department/92/events/)) report circulating in the **Kremlin** today discussing the [just completed meeting](https://www.aljazeera.com/news/2019/09/erdogan-hosts-putin-rouhani-syria-talks-190916063414345.html) held between **President Putin**, **Turkish President Recep Tayyip Erdogan** and **Iranian President Hassan Rouhani**, says it was no surprise when the **United States** yesterday **[backed off](https://www.thenational.ae/world/europe/us-unlikely-to-impose-sanctions-on-turkey-over-s400-missiles-says-turkish-official-1.912137)** of its threat to sanction **Turkey** for its purchasing the feared **Russian** missile defense system **S-400**—a timely purchase more than justified in light of the **[hundreds of NATO air defense systems all failing when Saudi Arabia was attacked last week](https://www.whatdoesitmean.com/index2988.htm)**—a deliberate failing as these **NATO** air defense systems aren’t able to target **[their own cruise missiles](https://www.whatdoesitmean.com/index2988.htm)**—but which **Erdogan** is further gravely responding to by his now declaring: “**_[They say we can't have nuclear-tipped missiles, though some have them…This, I can't accept](https://www.zerohedge.com/geopolitical/next-turkey-nuclear-weapons)_**”—that **Erdogan** explained to **Putin** is now a vital national security need for **Turkey** to defend itself against the socialist climate change cultists rapidly gaining power in the **US**—the danger of whom displayed over the past few days alone saw a **[Facebook employee jumping to his death from his company’s California headquarters building](https://www.cnbc.com/2019/09/19/police-respond-to-apparent-suicide-at-facebook-headquarters.html)** just hours after this tech giant **[banned its 40,000 workers from ever using water bottles again](https://www.breitbart.com/tech/2019/09/19/facebook-bans-plastic-water-bottles-in-offices/)**—and whose suicidal mindset is now threatening to grow after **[self-identified Christians in America are now being forced to confess their climate sins to plants](https://pjmedia.com/faith/idolatry-climate-crazed-seminary-confesses-sins-to-plants-in-beautiful-ritual/)**.  \[**Note:** Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](plansts1.jpg)

**Crazed climate cultists in America are now being forced to confess their sins to plants.**

According to this report, **Ministry** experts have **[exhaustively detailed](https://www.whatdoesitmean.com/index2981.htm)** how socialist forces in **America** have created a climate change cult religion to compete with their nation’s centuries long **Christian** founding and heritage—and whose reason for doing so is rooted in **Christianity** being centered on the moral values of family and community over the individual—which stands opposed to socialist ideology of always putting the individual over the needs of others—and as practiced by these socialists today is called “**_[identity politics](https://en.wikipedia.org/wiki/Identity_politics)_**”—but whose only true purpose of is to tear away and destroy all sense of community and belonging—which in turn plunges a nation and its peoples into a tribal chaos of factions taught to hate and despise each other—thus allowing these socialists to take power by force over peoples no longer having any sense of common purpose.

**Ministry** experts, also, this report continues, **[documented](https://www.whatdoesitmean.com/index2981.htm)** how the early **20th Century Marxist** philosopher and communist **[Antonio Gramsci](https://en.wikipedia.org/wiki/Antonio_Gramsci)** created the entire scenario that these socialists in **America** are now using to destroy their nation—even to include their using his **[fear tactic of climate change](https://www.zerohedge.com/news/2019-09-09/armstrong-climate-change-has-been-routine-scare-tactic-1930s)** to create a new religion to compete against **Christianity**—and whose “**_[Dead Hand Of Influence](https://www.redstate.com/robert_a_hahn/2019/09/12/dead-hand-antonio-gramsci/)_**” still stretches across all of the **United States** even today.

![](lunch3.jpg)

![](lunch4.jpg)

![](lunch2.jpg)

**Socialist forces in America have been using Marxist communist Antonio Gramsci’s climate change fear tactics since the 1930’s.**

Not being understood by the masses of the **American** people of what their socialist overlords are actually doing to them and their nation, this report explains, is that these godless socialists are psychologically manipulating for their own purposes the most basic human known as “**_[thanatophobia](https://en.wikipedia.org/wiki/Death_anxiety_(psychology))_**”—otherwise known as “**_death anxiety_**”, or more commonly “**_fear of death_**”—is a state in which people experience negative reactions in recognition of their own mortality—has since human records began [been linked with religion](https://www.verywellmind.com/religion-and-phobias-2671697)—and is the prime motivator and predictor of human behavior.

As no human being is able to prevent their physical death, this report details, **Christianity** has provided to all humanity an escape from this inevitability through one’s simple acknowledgement of the fact that **Jesus** died for their sins so they don’t have to, and when their physical body dies, they’ll live forever with **Him**—and as so stated in the **Book of John**, **Chapter 3**, **Verse 16**, which says: “**_[For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.](https://www.biblegateway.com/passage/?search=John+3%3A16&version=KJV)_**”

![](plansts2.jpg)

The socialist counter to **Christianity’s** simple offer of eternal life, this report further explains, is their claiming that [all religions are fundamentally the same](https://www.interfaith.org/community/threads/12146/)—but which couldn’t be further from the truth as **Jesus** actually proclaimed **Himself** as **God**—as opposed to every other religion being founded on the words of men claiming they represented “**_god_**”—and whether believed or not, makes it an undeniable fact that **Christianity** is the most unique belief system in human history—and in being such, makes its precepts of putting family and community over the individual the most consequential ever evidenced in human history—most particularly in the United States—whose entire foundation is based on **Christianity**—and is why its **Founding Father President John Adams** told his citizens: “**_[Our Constitution was made only for a moral and religious People.  It is wholly inadequate to the government of any other.](https://founders.archives.gov/documents/Adams/99-02-02-3102)_**”    

![](plansts3.jpg)

For over two centuries, this report continues, the **United States** used its **Christian** founding, beliefs and precepts to become the most powerful nation history has ever known—which they were able to accomplish because their peoples remained united and had overcome all fear of death—but which today only a fragment of which remains—and is entirely due to decades of socialist indoctrination that has turned these peoples away from **Christianity**—and back to their fearing death—that for decades these socialists have warned them will strike:

**_Such as these socialists [warning in the 1930s that millions of them would die when the waters from melting glaciers would destroy their major cities](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1967 that by 1975 millions of them would die from famine](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1969 that “everyone will disappear in a cloud of blue steam by 1989” because of air pollution](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1970 that everyone was going to die by 2000 because of the new ice age](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1970 that by the year 1980 every American would have rationed food and water, then would all die](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning again in 1971 that a new ice age was going to kill everyone](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1972 that by the year 2070 the world would be covered in ice and everyone would be dead](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1974 that the new ice was coming sooner than they thought](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1988 that by the 1990s everyone would die because of droughts](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_These socialists [warning in 1988 that the world was heating up instead of cooling to a new ice age](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._**

**_And, by 1988, [these socialists returning to the 1930s to warn that everyone was going to die when the waters from melting glaciers would destroy their major cities](https://cei.org/blog/wrong-again-50-years-failed-eco-pocalyptic-predictions)._** 

![](plansts4.jpg)

By these godless socialists having indoctrinated the peoples of **American** away from **Christianity** and into their new climate change death cult religion, this report concludes, the vast majority of these brainwashed citizens no longer know how to protect themselves using **Biblical** warnings such as “**_[Beware of false prophets, who come to you in sheep's clothing, but inwardly they are ravenous wolves.](https://www.creators.com/read/kids-talk-about-god/06/14/how-can-you-tell-a-false-prophet-from-a-true-prophet)_**”—and because of this now sees them **[praying to plants to confess their climate sins](https://pjmedia.com/faith/idolatry-climate-crazed-seminary-confesses-sins-to-plants-in-beautiful-ritual/)**—sees them flocking to their major leftist **NBC** television news network that’s **[hysterically making the exact same discredited climate prophecies they made 30 years ago](https://www.newsbusters.org/blogs/nb/kyle-drennen/2019/09/17/dc-drowns-nbc-makes-same-hysterical-prediction-30-years-ago)**, and has just **[set up an online confessional where these brainwashed peoples can confess their climate sins](https://www.rt.com/news/469124-climate-sins-religion-greta-nbc/)**—all of which culminated this past week with young socialist brainwashed school children testifying before the **US Congress** and saying such sad things like “**_[The World Is Ending So What’s The Point Of Studying?](https://www.thegatewaypundit.com/2019/09/teen-climate-change-activist-says-the-world-is-ending-so-whats-the-point-of-studying-video/)_**”—no doubt inspired by their leftist **Democrat Party** presidential candidates who are now saying they will **[ban all of the American people from owning cars because of climate change](https://www.dailywire.com/news/51981/democrat-andrew-yang-climate-plan-will-prevent-ryan-saavedra)**—as well as their saying not to even look at nuclear energy to save them because they’re all now ordered “**_[Don’t Use Hard Data, Think With Your Hearts](https://www.dailywire.com/news/51992/marianne-williamson-nuclear-energy-dont-use-hard-ryan-saavedra)_**”—thus making it clear why experts the world over all now **[warning to soon expect mass numbers of these socialist climate change cultists to begin committing suicide](https://www.rt.com/op-ed/469022-climate-change-anxiety-cult/)**—and as they themselves have declared their reason for doing so: “**_[we probably don’t even have a future anymore](https://www.rt.com/op-ed/469022-climate-change-anxiety-cult/)_**”—none of whom have ever been told the truth this isn’t even close to being true.  

![](plansts5.png)

September 20, 2019 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[“_Ghost Warrior_” Wants Trump Assassinated—Hints It’s Coming Soon](http://whatdoesitmean.com/index2968pl.htm)**

**[America Gets Mad Dog Warning—But Is Anyone Listening?](https://www.whatdoesitmean.com/index2968.htm)**

**[Truth Makes Last Stand In America—Looks For Allies To Defend It](https://www.whatdoesitmean.com/index2941.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**