        Americans Need To Remember That Tyranny Is An Illusion—And Qatar Is Helping Them <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

Note: This is an urgent private letter intended for the sole and exclusive use of the patron/donors to the Sisters of Sorcha Faal.

**Americans Need To Remember That Tyranny Is An Illusion—And Qatar Is Helping Them**

25 February 2021

Hello Folks,

For those of you who don’t know, the **[State of Qatar](https://en.wikipedia.org/wiki/Qatar)** is a country located in **Western Asia** occupying the small **Qatar Peninsula** on the northeastern coast of the **Arabian Peninsula**, and whose sole land border is with the neighboring **Gulf Cooperation Council** monarchy **Saudi Arabia** to the south, with the rest of its territory surrounded by the **Persian Gulf**.

Other facts you should know about **Qatar** is that it has a population of about **2.8-million** and has the world’s largest supply of natural gas—which is why you’ll see articles written about it like “**[Qatar: The Tiny But Super-Rich Middle Eastern State Buying Up The World](https://www.lovemoney.com/gallerylist/71250/qatar-the-tiny-but-superrich-middle-eastern-state-buying-up-the-world)**”.

Why you should know about this fabulously wealthy tiny **Persian Gulf** country existing in the most dangerous neighborhood in the world, **Sister Ciara** began explaining in her letter yesterday “**[American People Are Winning A War They Don't Even Know They're Fighting](https://www.whatdoesitmean.com/index3491.htm)**”—the gist of which was to show you that in spite of what you may think, average **American** people are winning out in the most insidious information war that’s ever been launched against them—and in also knowing this truth, is why **Qatar’s** global television news network **[Al Jazeera just announced that it’s launching a right-wing conservative news platform for the Americans “_who feel left out_” of the leftist mainstream media](https://www.zerohedge.com/political/qatars-al-jazeera-launches-right-wing-news-platform-americans-who-feel-left-out-msm)**. 

![](ajj21.jpg)

What you need to understand about why **Qatar** is siding with the **American** people in this information war, as opposed to **Biden** and his socialists, is that them living between the two powerful nations of **Saudi Arabia** and **Iran**, who hate each other, has taught them the value of picking the winning side—and in this case is the only logical choice they have, especially because the leftist mainstream propaganda media is imploding from all of their lies and misinformation that’s no longer able to be kept hidden—with one of the best examples of this happening this week being described in the article  “**[Tucker Carlson Strikes Gold, Triggers CNN Into Proving His Point After Segment on Disinformation](https://redstate.com/sister-toldjah/2021/02/24/tucker-carlson-strikes-gold-triggers-cnn-into-proving-his-point-after-segment-on-disinformation-watch-n332020)**”, that, in part, says:

**_One of the most unintentionally hilarious moments in cable news history happened last night during a lengthy segment Tucker Carlson did on disinformation in the mainstream media._**

**_In his commentary, the popular Fox News host took aim at CNN and MSNBC in particular for peddling fake news about police shootings, pointing out how such disinformation “is an offense against this country, an attack on America and, more critically, on something called our ‘norms.'”_**

**_At one point during the segment, Carlson talked about how a research paper from the Skeptic Research Center found that a large percentage of liberals believed “1,000 or more than 1,000 unarmed African-Americans were gunned down” by police officers in 2019. The actual number, he pointed out, was 27. With that in mind, Carlson then noted he went on a search to find out where people might have gotten the disinformation about police shootings._**

**_“So it’s worth finding out where the public is getting all this false information — this ‘disinformation,’ as we’ll call it,” Carlson stated. “So we checked. We spent all day trying to locate the famous QAnon, which in the end we learned is not even a website. If it’s out there, we could not find it. Then we checked Marjorie Taylor Greene’s Twitter feed because we have heard she traffics in disinformation, CNN told us, but nothing there.”_**

**_“Who is lying to America,” Carlson asked, “in ways that are certain to make us hate each other and certain to destroy our core institutions?”_**

**_The answer, he said, was cable news outlets like CNN and MSNBC and Democratic politicians talking on TV and spreading harmful disinformation about police shootings. He then played clips of them perpetuating false narratives that have further inflamed tensions, which some have alleged helped motivate BLM/Antifa-led agitators to riot, loot, and burn down buildings and target federal courthouses last year._**

![](ajj22.jpg)

While you contemplate this information, I’d like to also direct you to the article “**[How Societies Are Imprisoned: The Whole World Will One Day Be Like Hollywood?](https://www.zerohedge.com/covid-19/how-societies-are-imprisoned-whole-world-will-one-day-be-hollywood)**”, that will give you a fuller explanation of how this information war is being waged, but most importantly reminds you of the truth: “**_[All tyranny is an illusion predicated on fear within the minds of the enslaved. So, do not fear...](https://www.zerohedge.com/covid-19/how-societies-are-imprisoned-whole-world-will-one-day-be-hollywood)_**”.

Put another way, this information war isn’t against the leftist mainstream propaganda media, it’s against the fear they’re trying to instill and control you with—the antidote for which is truth—and is the mission the **Sisters** have dedicated themselves to.

And this is why I’m asking each of you to aid them in this mission by giving what you can today, and by doing so you’ll not only be a defender of truth, you’ll be a vanquisher of fear—not just your own fear, but the fear these evil forces are trying spread all over the world.

The great American writer **Ralph Waldo Emerson** once said: “**_He who is not everyday conquering some fear has not learned the secret of life_**”—and I hope you understand what this means, because when you do, you’ve taken your first step towards freedom!

Thank you for listening and aiding us in our hour of desperate need by going below and giving what you can, and as always, please feel free to write me at [sorchafaal@fastmail.fm](mailto:sorchafaal@fastmail.fm) with any comments/questions/suggestions, remembering to put **ATTN: BRIAN** in the subject line.

All the best folks,

Brian

Webmaster

Paris

Fr.

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

**[Return To Main Page](https://www.whatdoesitmean.com/)**