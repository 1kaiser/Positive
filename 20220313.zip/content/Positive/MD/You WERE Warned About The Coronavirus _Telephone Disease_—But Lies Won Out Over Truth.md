        You WERE Warned About The Coronavirus “Telephone Disease”—But Lies Won Out Over Truth <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

Note: This is an urgent private letter intended for the sole and exclusive use of the patron/donors to the Sisters of Sorcha Faal.

**You WERE Warned About The Coronavirus “_Telephone Disease_”—But Lies Won Out Over Truth**

28 February 2020

Hello Folks,

I’m pretty sure that most of you know the definition of a miracle is something that’s occurred which is not explainable by natural or scientific laws, and therefore is considered to be the work of a divine agency—while at the same time you’re knowing this, many of you may not have seen one fully documented—**UNTIL NOW!**

So right here, and right now, I present to all of you a fully documented bonafide miracle guaranteed to amaze and astound—that began with virtually unknown **[Democrat Party US Congressman Frank Pallone](https://en.wikipedia.org/wiki/Frank_Pallone)**—who just eight days after his **[31 October 2019](https://en.wikipedia.org/wiki/Impeachment_of_Donald_Trump)** vote to approve the resolution that formally authorized the impeachment inquiry against **President Donald Trump**, on **[8 November 2019](https://www.congress.gov/bill/116th-congress/house-bill/4998)** to be exact, introduced for the first time a bill titled **[H.R.4998 - Secure and Trusted Communications Networks Act of 2019](https://www.congress.gov/bill/116th-congress/house-bill/4998)**—that rocketed through the **US House of Representatives** in relative light-speed fashion, and where, on **[16 December 2019](https://www.congress.gov/bill/116th-congress/house-bill/4998/all-actions?overview=closed&KWICView=false)**, it was approved by a unanimous voice vote of all **Democrat** and **Republican** members of the **US House**—and yesterday, on **[27 February 2020](https://www.congress.gov/bill/116th-congress/house-bill/4998/all-actions?overview=closed&KWICView=false)**, was likewise approved by a unanimous voice vote of all **Democrat** and **Republican** members in the **US Senate**—and today sits on the desk of **President Trump** awaiting his signature to become a final law.

Since **President Trump** was sworn into office, you should know, this is the first time he’s been presented with a law rushed to his desk unanimously approved by every single “**_at war to the death_**” **Democrat** and **Republican** member of the **US Congress**—who even in the calmest times can’t agree on anything—but were united in a fear of something so terrifying to them all, they were left no choice but to act—a fear shown in this new law that **[immediately bans the purchase in America of telecom equipment from Chinese manufacturers like Huawei and ZTE](https://techcrunch.com/2020/02/27/senate-passes-rip-and-replace-bill-to-remove-old-huawei-and-zte-equipment-from-networks/?guccounter=1&renderMode=ie11)**—and that further staggeringly **[gives $1 billion in emergency funding to help smaller rural telecoms “_rip and replace_” from their telecom systems every single Chinese made piece of equipment they have](https://techcrunch.com/2020/02/27/senate-passes-rip-and-replace-bill-to-remove-old-huawei-and-zte-equipment-from-networks/?guccounter=1&renderMode=ie11)**. 

If you’re wondering why this miracle bill was rushed to the desk of **President Trump**, you should really take a good look at the **[CT scans of patients having Radiation-Induced Lung Injury](https://www.pulmonologyadvisor.com/home/decision-support-in-medicine/pulmonary-medicine/radiation-induced-lung-injury/)** and compare them with the **[CT scans of patients infected with the coronavirus COVID-19 disease](http://www.cidrap.umn.edu/news-perspective/2020/02/studies-profile-lung-changes-asymptomatic-covid-19-viral-loads-patient)**—which will explain to you why the **[Radiological Society of North America has just issued an emergency alert declaring that CT scans should be used as the primary screening tool for COVID-19](https://www.sciencedaily.com/releases/2020/02/200226151951.htm)**.

![](cod21.jpg)

**CT scans of patients having Radiation-Induced Lung Injury (_above_)…**

![](cod22.gif)

**…are near exact matches to CT scans taken of patients infected with the coronavirus COVID-19 disease (_above_).**

In want of better words, all of the evidence is now pointing towards **COVID-19** being a “**_Telephone Disease_**” directly caused and/or greatly accelerated by the fifth generation wireless technology for digital cellular networks that began wide deployment in **2019** known as **[5G](https://en.wikipedia.org/wiki/5G)**—a wireless technology that, on **[13 September 2017](https://ehtrust.org/wp-content/uploads/Scientist-5G-appeal-2017.pdf)**, over **230** of the top scientists and doctors in the world **[sounded a grave alarm about warning](https://www.gaia.com/article/5g-health-risks-the-war-between-technology-and-human-beings)**:

**_We, the undersigned scientists, recommend a moratorium on the roll-out of the fifth generation, 5G, until potential hazards for human health and the environment have been fully investigated by scientists independent from industry._**

**_5G will substantially increase exposure to radio frequency electromagnetic fields (RF-EMF)… and_** **_has been proven to be harmful for humans and the environment_****_._**

![](cod23.jpg)

The importance of viewing the coronavirus **COVID-19** as a “**_Telephone Disease_**” is that by doing so it explains some perplexing mysteries about the spread of this disease—such as why this disease has struck the **Gulf** nations and monarchies in the **Persian Gulf** region, but becomes explainable when one notices **[their ongoing 5G revolution](https://www.mei.edu/publications/huawei-wars-and-5g-revolution-gulf)**—most particularly in **Iran**, where this country is completely blanketed to its smallest village with **4G** technology coverage—but who are now **[putting the finishing touches on rolling out 5G technology throughout their entire nation in the coming weeks](http://french.presstv.com/Detail/2020/02/13/618603/Iran-5G-internet-network-minister-announcement)**—finishing touches that included **Iran** activating their **Chinese** bought **5G** technology for testing—that was immediately met by **[Iran having more coronavirus cases and deaths of any nation outside of China](https://www.theatlantic.com/ideas/archive/2020/02/iran-cannot-handle-coronavirus/607150/)**—and whose **[Vice President is one of seven of their top government officials now infected](https://www.nytimes.com/2020/02/27/world/middleeast/coronavirus-iran-vice-president.html)**.  

![](cod24.jpg)

**Coronavirus COVID-19 disease outbreak begins to spread in Persian Gulf nations and monarchies activating 5G technology.**

Another perplexing mystery solved when viewing the **COVID-19** coronavirus as a “**_Telephone Disease_**” sheds new light on the current situation of the world’s cruise ships, too—as these massive ships carrying thousands of passengers are nearly all equipped with **5G** technology for their passengers’ communications benefit—and are now being turned away from countries living in dread of them—such as the nations of **[Jamaica and Cayman Islands turning away the MSC Meraviglia cruise ship and its 6,000 passengers](https://news.yahoo.com/rejected-mexico-caymans-over-virus-fears-cruise-ship-012843818.html)**—but that **[Mexico did allow to come into port because of humanitarian concerns](https://news.yahoo.com/rejected-mexico-caymans-over-virus-fears-cruise-ship-012843818.html)**.

![](cod25.jpg)

As this **COVID-19** coronavirus “**_Telephone Disease_**” continues its global spread, I’d like to further direct your attention to the **[hourly updated global map maintained by the medical scientists at John Hopkins University](https://gisanddata.maps.arcgis.com/apps/opsdashboard/index.html#/bda7594740fd40299423467b48e9ecf6)**—where it’s very interesting to notice that the spread of this disease is entirely centered in those nations having **5G** technology—as opposed to the world’s countries having no **5G** technology whatsoever, and whose only cases are from those who entered their nations from other more advanced parts of the world.

And here’s something else I think it’s important for you to know—what the exact symptoms for **COVID-19** are—which according to the **World Health Organization** are “**_[fever, tiredness, and dry cough](https://www.who.int/news-room/q-a-detail/q-a-coronaviruses)_**”—according to the **United States Centers for Disease Control** are “**_[fever, cough and shortness of breath](https://www.cdc.gov/coronavirus/2019-ncov/about/symptoms.html)_**”—and according to the scientists at **John Hopkins University**, **[are symptoms exactly one would have if infected with a flu virus](https://www.hopkinsmedicine.org/health/conditions-and-diseases/coronavirus/coronavirus-disease-2019-vs-the-flu)**.

The problem with these **COVID-19** symptom descriptions given by these top scientific experts, aside from them describing just about every single illness and/or disease a human can get from **Allergies** to the **Zika** **Virus**, are that they come nowhere close to the **COVID-19** symptoms being described coming from **China** via their **[GreatFire](https://en.greatfire.org/)** group of censorship-busting websites—where tens-of-thousands of posts describe the first symptom of **COVID-19** being a dry cough that makes those infected tired—that normal cough medicines and herbal cures cure rather fast—but for those who are already ill or aged, sees them having to take stronger cough medicines prescribed by doctors—which cures the vast majority of them—and if not, sees these ill and aged **COVID-19** infected people admitted to hospital to receive oxygen treatments, where about **2%** of them die—statistics which **[exactly matches the age, sex, existing conditions of COVID-19 cases and deaths compiled by Western scientists](https://www.worldometers.info/coronavirus/coronavirus-age-sex-demographics/)**—but even more concerning, are symptoms exactly matching those having a **Radiation-Induced Lung Injury**, **[which are](https://www.pulmonologyadvisor.com/home/decision-support-in-medicine/pulmonary-medicine/radiation-induced-lung-injury/)**:  

**Grade 1:** **Mild symptoms of dry cough on exertion**

**Grade 2:** **Persistent cough requiring narcotic anti-tussive agents and/or dyspnea with minimal exertion, but not at rest**

**Grade 3****: Severe cough that is nonresponsive to narcotic agents, and/or dyspnea at rest or radiographic evidence of acute pneumonitis**

**Grade 4:** **Severe respiratory insufficiency that requires continuous oxygen or assisted ventilation**

**Grade 5:** **Death**

![](cod26.jpg)

At this point I’d normally be railing against the monsters who unleashed this “**_Telephone Disease_**” on the world, but I honestly can’t right now—and the reason is because of the warning I told you about issued by the world’s top scientists in this field in **2017**—but whose **[first warning about the grave health dangers posed by 5G technology came in 2015](http://www.5gappeal.eu/scientists-and-doctors-warn-of-potential-serious-health-effects-of-5g/)**—that was immediately followed by the greatest scientific undertaking in all of human history when the **United States** began pouring billions-of-dollars into a company named **[Space X](https://en.wikipedia.org/wiki/SpaceX_Starlink)** to produce as many as **42,000** small satellites that will remove all internet transmission technology from our planet’s surface and put it into space where its radiation can’t harm anyone—the latest **[60 which were launched into space on 6 January, that brings the number of these Starlink satellites in orbit now to 180](https://www.newscientist.com/article/2229643-spacex-starlink-satellites-could-be-existential-threat-to-astronomy/)**.

Now I’ve got to get a little technical here, but it’s important for you to understand this—the **United States** is the only nation on **Earth** capable of accomplishing the historic feat of placing **42,000** of these satellites in orbit to protect humanity from **5G** radiation—and for those of us closely following these events, it made perfect sense when **President Trump** created his **Space Force** to protect these tens-of-thousands of satellites—because they are a part of the war between the **[Ku](https://en.wikipedia.org/wiki/Ku_band)** and **[Ka](https://en.wikipedia.org/wiki/Ka_band)** frequency bands these satellites operate on and **Chinese** **5G** technology—the standards of which for global internet communications will decide who rules the remainder of the **21st Century**—and is why **Trump** is **[threatening every nation in the world](https://www.cnbc.com/2020/02/25/trump-official-calls-huawei-mafia-as-white-house-works-on-5g-battle-plan.html)** if they buy and deploy **Chinese** **5G** technology, and the **US Congress** has outlawed its usage in all of **America**.

![](cod27.jpg)

In a normal world, as you know, everything I’ve told you about here should have been made known to you years ago—and even as I write these words, those like us trying to tell the truth about this “**_Telephone Disease_**” are **[now being targeted for destruction by those seeking to keep the truth from you](https://thenextweb.com/socialmedia/2020/02/26/social-media-conspiracies-blame-coronavirus-on-5g-internet/)**—a destruction only **YOU** can prevent by supporting those few of us left who keep telling you true things.

In **Sister Ciara’s** letter to you yesterday—**[They Died For The Crime Of What They Knew—Where Is Your Name On The Death List?](https://www.whatdoesitmean.com/index3141.htm)**—she pled for your support to keep the **Sisters’** mission alive so they can keep the truth flowing to you before all is lost—a plea I now join in making to **YOU**, too—but that I’ll add to by letting you know that what you’ve seen so far these past few years, is **NOTHING** compared to what’s going to unfold in the coming months!

So, and least for those of you fearless few who know these truths, give what you can **TODAY** so you can be among the first to read the final chapters of this historic saga as only the **Sisters** can write it—and in knowing of what is to come, be able to protect yourselves and your families from the storm that’s gathering strength on the horizon. 

Thank you for listening and aiding us in our hour of desperate need by going below and giving what you can, and, as always, please feel free to write me at [sorchafaal@fastmail.fm](mailto:sorchafaal@fastmail.fm) with any comments/questions/suggestions, remembering to put **ATTN: BRIAN** in the subject line.

All the best folks,

Brian

Webmaster

Paris

Fr.

[![](do37.jpg)](https://fundrazr.com/21bKL5?ref=ab_48h7S4_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

**[Return To Main Page](https://www.whatdoesitmean.com/)**