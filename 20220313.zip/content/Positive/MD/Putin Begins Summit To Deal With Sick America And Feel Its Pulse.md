        Putin Begins Summit To Deal With Sick America And Feel Its Pulse  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

**[What You Aren’t Being Told About The World You Live In](https://www.whatdoesitmean.com/)**

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](https://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

June 16, 2021

**Putin Begins Summit To Deal With Sick America And Feel Its Pulse**

By: Sorcha Faal, and as reported to her Western Subscribers

An abbreviated new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today first noting that **President Putin** **[arrived safely with the world watching](https://www.rt.com/russia/526691-putin-arrives-summit-geneva/)** in **Geneva-Switzerland**, **[traveled without incident to the summit location](https://sputniknews.com/world/202106161083158629-live-updates-putin-biden-geneva-summit/)** and began his **[first sit-down meeting](https://www.rt.com/russia/526711-biden-putin-summit-discussion-meeting/)** with **Supreme Socialist Leader Joe Biden**, says the official **Russian Federation** stance towards this event was revealed when **Deputy Foreign Minister Sergey Ryabkov** firmly stated: “**_[The Americans should not make a mistake thinking that through some kind of pressure or some verbal techniques they can change our principled position on well-known subjects](https://tass.com/politics/1303183)_**”.

A firm stance needing to be crystal clear to the **Americans**, as in the hours prior to this summit beginning, socialist leader **Biden** went into full war mode and threatened: “**_[I will tell you this: I’m going to make clear to President Putin that there are areas where we can cooperate, if he chooses…And if he chooses not to cooperate and acts in a way that he has in the past, relative to cybersecurity and some other activities, then we will respond…We will respond in kind](https://www.zerohedge.com/geopolitical/bidens-nato-warning-putin-if-you-dont-cooperate-we-will-respond)_**”.

Is a war threat coming **24-hours** after **[the latest NATO summit showed that enabling never-ending American dominance is the REAL reason it exists](https://www.rt.com/op-ed/526610-nato-china-us-cold-war/)**—specifically because **[Biden achieved his goal of expanding NATO to confront China](https://www.washingtonpost.com/politics/disagreements-flare-among-nato-allies-despite-relief-at-bidens-arrival/2021/06/14/3b7b0f6c-cd09-11eb-a7f1-52b8870bef7c_story.html)**—an expansion of **NATO** to confront **China** defense experts have branded as an “**_[Empire Of Clowns Versus The Yellow Peril](https://www.zerohedge.com/geopolitical/escobar-empire-clowns-versus-yellow-peril)_**”—a threat **China** immediately responded to by **[sending a record armada of 28 warplanes towards Taiwan](https://www.zerohedge.com/geopolitical/china-sends-record-28-fighter-jets-toward-taiwan-after-telling-nato-we-wont-sit-back)** while warning **NATO** “**_[We Won’t Sit Back!](https://www.zerohedge.com/geopolitical/china-sends-record-28-fighter-jets-toward-taiwan-after-telling-nato-we-wont-sit-back)_**”—that was quickly followed by **[the USS Ronald Reagan nuclear weapons armed strike group entering the disputed South China Sea](https://www.zerohedge.com/geopolitical/uss-regan-strike-group-enters-heavily-disputed-south-china-sea)**—all of which was joined by **China Foreign Ministry** spokesman **Zhao Lijian** strongly advising: “**_[The United States is sick…The G7 should feel its pulse and prescribe medicine for it](https://goachronicle.com/united-states-is-sick-g7-should-feel-its-pulse-and-prescribe-medicine-for-it-china/)_**”.

In knowing how truly sick the **United States** is, this report explains, it caused **President Putin** to **[call out socialist leader Biden’s inhumane treatment of Trump supporters involved in the 6 January protest at the US Capitol](https://www.thegatewaypundit.com/2021/06/order-assassination-woman-walked-congress-russian-president-putin/)**, and then directly ask **Biden**: “**_[Did you order the assassination of a woman who walked into Congress?](https://www.thegatewaypundit.com/2021/06/order-assassination-woman-walked-congress-russian-president-putin/)_**”—a troubling question needing an immediate answer after it was beyond shockingly revealed that **[the FBI secretly helped organize and coordinate the 6 January breeching of the US Capitol](https://sputniknews.com/us/202106161083162250-fbi-helped-organize-and-coordinate-capitol-unrest-tucker-carlson-claims-in-bombshell-report/)**—**[a fact of the FBI’s secret involvement proved in multiple court filings](https://www.revolver.news/2021/06/federal-foreknowledge-jan-6-unindicted-co-conspirators-raise-disturbing-questions/)**—and sees this sickness extending to when socialist **Biden** began traveling to this summit by first landing at an **American** air base in **England**, where **[the stunning evidence shows he was greeted by actors pretending to be US soldiers, as not a single one of them had name tags, American flags, rank insignias, or anything else on their uniforms proving who they really were](https://welovetrump.com/2021/06/15/did-biden-just-speak-to-a-fake-audience-of-actor-soldiers/)**. 

Joining these “**_pretend_**” soldiers greeting **Biden**, this report concludes, is the, likewise, “**_pretend_**” **NATO**—whom every defense expert in the world knows **Russian** military forces **[can completely annihilate and crush into oblivion in about a week](https://www.rt.com/op-ed/526642-biden-us-nato-putin/)**—which makes it no surprise former **United Nations** weapons inspector and **US Marine** intelligence officer **Scott Ritter** has just released his dire open letter “**[Biden Wants NATO To Project The Strength It Doesn’t Have](https://www.rt.com/op-ed/526642-biden-us-nato-putin/)**”, wherein he truthfully reveals and warns:   

**_Biden is a veteran American politician who was part of the establishment which squandered the inheritance of wealth, prestige and power America had accumulated in the aftermath of the Second World War._**

**_He is the living embodiment of American political hubris, where words speak louder than results._**

**_Biden has shown no real appreciation for the state of affairs he has inherited, formulating a foreign policy premised on the mantra of “America is back” without having an appreciation of what “back” means._**

**_His rhetoric and posturing suggest that he believes the dominance and prestige America enjoyed in 1991 can be replicated today simply by willing it to be so._**

**_This is irresponsible fantasy_****_, something even Biden seems to realize in the aftermath of his “Putin is a killer” comments to the US media._**

**_The reality check that followed Biden’s impolitic chest thumping, manifested in the withdrawal of Russia’s ambassador and the snap mobilization of 100,000 Russian troops on Russia’s border with Ukraine, drove home the reality that the US and its NATO allies were not in any position to confront Russia militarily._**

**_Moreover, more sober assessments coming out of both Europe and the US held that the rise of an expansionist China represented a greater threat to the geopolitical positioning of the transatlantic partnership than Russia._**

**_The real purpose behind the NATO Summit was to construct a fiction capable of bolstering Biden’s posturing during his meeting with Putin._**

**_The fact that Russia is fully aware of this reality only underscores the theatrics of the entire affair._**

**_That, more than anything, defines the current situation between the US and Russia – theater posing as reality, to cover for weakness in order to project strength, all in an effort to avoid a conflict no one wants._**

**_The United States is facing a perfect storm of crises of its own making._**

**_On the domestic front, the American democratic institution is collapsing under the weight of centuries of unresolved societal inequities that threaten to divide the country into two irreconcilable factions._**

**_In the Pacific, decades of geopolitical neglect fundamentally ceded the strategic advantage to a surging China, allowing the momentum of that country’s economic and military expansion to challenge and, in some areas, surpass what had previously been a region of uncontested American influence and control._**

**_In Europe, the post-9/11 focus on the Middle East and South Asia_** **_left a once dominant American military posture in ruins_** **_and with it the influence 300,000 troops once forward-deployed on European soil used to bring._**

**_Lacking an American military spine, the NATO alliance withered into virtual irrelevance, unable to meaningfully project power or mount a credible defensive deterrence._**

\[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](psb21.jpg)

June 16, 2021 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Mysterious Mock Attack Joins Trump In New Jersey—Putin Notices And Warns: “_We’ll Knock Out Your Teeth_”](https://www.whatdoesitmean.com/index3573pl.htm)**

**[History Knows American Future: “_Bright Light…Loud Noise…Unobstructed View_”](https://www.whatdoesitmean.com/index3573.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/index.htm)**