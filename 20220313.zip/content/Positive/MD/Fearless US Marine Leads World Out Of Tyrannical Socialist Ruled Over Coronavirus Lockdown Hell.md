        Fearless US Marine Leads World Out Of Tyrannical Socialist Ruled Over Coronavirus Lockdown Hell  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Coronavirus Pandemic War Series: Part 1](https://www.whatdoesitmean.com/index3167.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 2](https://www.whatdoesitmean.com/index3181.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 3](https://www.whatdoesitmean.com/index3192.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 4](https://www.whatdoesitmean.com/index3203.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Trump Nears Total War: Calls To Active Duty All US Reserve Forces, Expels China From US Power Grid](https://www.whatdoesitmean.com/index3204.htm)**

May 4, 2020

**Fearless US Marine Leads World Out Of Tyrannical Socialist Ruled Over Coronavirus Lockdown Hell**

By: Sorcha Faal, and as reported to her Western Subscribers

A compelling new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today examining the fallout occurring in global societies due to the still raging “**_[Coronavirus Pandemic War](https://www.whatdoesitmean.com/index3167.htm)_**”, says that even though the **[National Medical Research Center for Phthisiopulmonology and Infectious Disease](https://publons.com/institution/1566192/)** has stated that **Russia** **[may reach the peak of disease spread in the next two weeks](https://tass.com/society/1152819)**, it’s more critical to notice the findings just released by **[Doctor-Scientist Anna Popova](https://www.rospotrebnadzor.ru/en/region/structure/str_central.php)**—who as the **Chief State Sanitary Physician of the Russian Federation** is now declaring: “**_[Today it’s impossible to completely stop the circulation of the coronavirus, no matter how closed the country is](https://tass.com/society/1152855)_**”—an obvious truth most astoundingly first noticed by common sense ordinary peoples, not scientists, and exampled as being true by **[just released scientific data showing people all over the world are rejecting their governments’ shelter in place tyranny](https://www.zerohedge.com/health/data-shows-world-rejecting-governments-shelter-place-tyranny)**—the powerful ripple effects of are now spreading throughout the **United States** where the **[City of Oklahoma backed off its mask mandate after its citizens neared revolt](https://www.washingtonpost.com/nation/2020/05/03/stillwater-oklahoma-mask-order/)**, as did the **State of Ohio**, whose **Governor Mike DeWine** dropped his mandatory mask order saying “**_[it went too far](https://www.politico.com/news/2020/05/03/dewine-ohio-face-masks-coronavirus-231175)_**”, and said: “**_[People were not going to accept the government telling them what to do](https://www.politico.com/news/2020/05/03/dewine-ohio-face-masks-coronavirus-231175)_**”—and who were joined by **[Arizona sheriffs declaring that they won't enforce their governor's stay-at-home order for citizens either](https://www.azcentral.com/story/news/local/arizona-health/2020/05/02/arizona-sheriffs-say-they-wont-enforce-governors-stay-home-order/3070491001/)**—and in a powerful display of how ordinary people must face down socialist tyranny to remain free, **US Marine** combat war veteran **[Dr. Cordie Lee Williams](https://doctor.webmd.com/doctor/cordie-williams-fd9225c4-e5f9-40b1-85c4-158d8b129277-overview)** led the entire world by his example—an example displayed yesterday in the socialist **Democrat Party** tyrannically ruled over **State of California**—where after witnessing jack-booted thug police forces throwing a defenseless **Christian** pastor to the ground and beating him during a peaceful protests against lockdown lunacy—this fearless **US Marine** [grabbed a megaphone and said to these thug police the words that made them back off while hanging their heads in shame](https://www.thegatewaypundit.com/2020/05/watch-california-police-officers-anti-lockdown-protest-appear-stand-marine-vet-megaphone-challenges-integrity/):

**_In the face of tyranny, in the face of freedom, are you going to sit there in your riot gear against peaceful protesters?_** 

**_Or are you going to say, you know what,_** **_it’s time to stand up for my country_****_._** 

**_Because I took an oath of office and it said, I will defend all enemies, foreign and domestic._** 

**_You might lose your job, but I’d rather lose my job than lose my soul._**

**_What are you going to tell your little boy or your little girl tonight?  That you took your baton and you crushed somebody’s skull, who was a mom?_**  **_Is that what a tough guy does?_**

**_That’s not what honor, courage, and commitment means in the Marine Corps._**

\[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](app21.png)

![](app22.png)

**Fearless former US Marine leader Dr. Cordie Lee Williams faces off against socialist tyranny (_above video_) as Apple's Mobility Trends and Foursquare payments scientific data (_two charts above_) show ordinary peoples the world are rejecting tyrannical socialist lockdown orders.**

According to this report, in **1775**, the tyrannically ruled over **British Empire** peoples living in **North American** colonies had reached the end of their patience while watching their overlords in **London** empty prisons in **England** to fill their cities, towns and villages with criminals, while at the same time taxing them into poverty to pay for it—and in knowing these colonialists were reaching the tipping point of rebellion, the **British Empire** decided that was the best time to disarm all of them—a fateful decision that culminated on **19 April 1775** when **British** military forces faced off against an armed group of these colonialists at a bridge in **Lexington-Massachusetts** to take away the guns and ammunition these peoples needed to feed themselves and their families—and where was fired “**_[The Shot Heard Round The World](https://www.history.com/news/what-was-the-shot-heard-round-the-world)_**” that ignited the **American Revolutionary War** and created the **United States of America**.

In a virtual replay of the events that occurred in **1775**, this report details, the **American people** have watched in horror over these few weeks as their socialist **Democrat Party** overlords used the coronavirus pandemic to lockdown all of their law abiding citizens, **[while at same time releasing into their cities, towns and villages criminals from prisons](https://www.breitbart.com/politics/2020/05/03/aclu-sues-free-500-inmates-california/)**—**[criminals who because of deranged socialist zero-bail policies are committing more crimes and being released immediately after being arrested](https://www.breitbart.com/politics/2020/05/03/california-suspect-arrested-3-times-12-hours-thanks-zero-bail-policy/)**—and are violent criminals being joined by the **[thug socialist police forces that are now openly beating anyone they find not bowing to the tyranny these once free peoples are now being subjected to](https://www.zerohedge.com/geopolitical/watch-video-nypd-officer-brutalizing-bystander-during-social-distancing-arrest-sparks)**. 

For the masses of the **American** people watching these horrors who remember their nation’s own history, this report notes, they’ve predictably begun to the feel the same kind of rage and rebellion that once stirred their ancestors to action—best exampled this past week when the free peoples living in the socialist **Democrat Party** stronghold **State of Michigan** created their own “**_Lexington Bridge_**” moment when they descended upon the offices of their tyrannical socialist leader **Governor Gretchen Whitmer** with their firearms as a reminder it is them who are the true leaders of their lives, not her—but to whom socialist tyrant **Governor Whitmer** responded with the maniacal scream that these peaceful armed protesters were displaying “**_[the worst racism and awful parts of US history](https://www.foxnews.com/politics/michigans-whitmer-says-armed-protesters-displayed-worst-racism-and-awful-parts-of-u-s-history)_**”.

As to how the **American** revolutionary heroes who created the **United States** in the first place devolved into the mind of socialist tyrant **Governor Whitmer** as being nothing more than “**_awful parts of US history_**”, this report continues, she didn’t explain—but whose rabid **anti-America** mindset is on full display among other socialist tyrant leaders, too—with this being best exampled today by **[Elizabeth Vaughn](https://www.linkedin.com/in/elizabeth-vaughn-138825188)**—a free **American** writer describing what’s now occurring in the socialist hell-hole **City of Chicago**—who in her just published article titled “**[No, It’s Not Heinrich Himmler; It’s Chicago Mayor Lori Lightfoot Issuing a Warning to Constituents](https://www.redstate.com/elizabeth-vaughn/2020/05/03/no-its-not-heinrich-himmler-its-chicago-mayor-lori-lightfoot/)**” issued a fearful wake up call to all of **America** stating:

**_My husband has always said work camps are not out of the realm of possibility in America if the wrong group were ever to gain power._**

**_And I always thought he was crazy._**

**_However, as I observe the ease with which some of the state and local officials, particularly the Democrats, have slid into their power during the pandemic,_** **_I’ve changed my mind_****_._**

**_Chicago_** **_Mayor Lori Lightfoot is a bit full of herself these days.  On Saturday, her office issued a warning to Chicagoans not to hold parties in their homes. She would like her constituents to know she is not playing.  They are to stay home in their own homes._**

**_It didn’t take long for state and local government leaders to start enjoying their emergency powers, not at all._**

**_From time to time throughout American history, it’s become necessary for us to fight to preserve our freedom._** 

**_This is our time. The warning lights are flashing._**

![](app23.jpg)

With **President Donald Trump** having taken less than **3-years** to drive the **US** unemployment rate down to **[its lowest level in 50-years](https://www.bbc.com/news/business-48145563)**, this report details, it’s now being reported that the **[April-2020 jobs report for the US will show the highest unemployment rate on record](https://www.wsj.com/articles/april-jobs-report-likely-to-show-highest-unemployment-rate-on-record-11588514401)**—an unprecedented and historical event occurring in just **6-weeks** time due to the coronavirus pandemic—that’s now being met by socialist forces in **America** calling anyone who wants to reopen the **US** economy “**_[The Dumbest People](https://www.redstate.com/nick-arama/2020/05/03/nyt-reporter-calls-americans-who-want-to-open-economy-dumbest-people/)_**”—while at the exact same time, actually sane and normal **American** experts are pointing out the obvious fact that: “**_[We Wrecked Our Economy for Nothing](https://www.redstate.com/darth641/2020/05/03/opinion-we-wrecked-our-economy-for-nothing/)_**”.

Agreeing with the **American** experts saying the **US** economy was wrecked for nothing, this report explains, are the most stubborn and unyielding things in the world called facts—such as **[coronavirus death rates being much lower than the estimates used to justify the lockdown of the US in the first place](https://pjmedia.com/news-and-politics/matt-margolis/2020/05/03/at-least-five-studies-have-shown-that-the-coronavirus-fatality-rate-is-under-1-percent-n387776)**—and the **[evidence proving beyond all scientific doubt that these lockdowns to stop the spread of the coronavirus and lower its death toll don’t even work](https://www.zerohedge.com/health/david-stockman-three-nations-covid-windbag-named-fauci)**—evidence abounding throughout the entire world—to include the **United States** where it’s **[now known](https://www.zerohedge.com/health/david-stockman-three-nations-covid-windbag-named-fauci)** that the “**_Heavy Lockdown_**” in **New York** resulted in **143 coronavirus deaths per 100,000**, the “**_Heavy Lockdown_**” in **Massachusetts** resulted in **45.7 coronavirus deaths per 100,000**, the “**_Heavy Lockdown_**” in California resulted in **4.6 coronavirus deaths per 100,000**—while the “**_No Lockdown_**” in **Iowa** resulted in **4.3 coronavirus deaths per 100,000**, the “**_Light Lockdown_**” in **Texas** resulted in **2.4 coronavirus deaths per 100,000**, and the now lifted “**_Late Lockdown_**” in **Georgia** resulted in **10.0 coronavirus deaths per 100,000**—thus causing these experts to **[advise that someone might dare inform these socialist tyrants that the general mortality rate from all causes for US citizens is 900 per 100,000 annually](https://www.zerohedge.com/health/david-stockman-three-nations-covid-windbag-named-fauci)**. 

As to why “**_Heavy Lockdown_**” places in the world have a higher coronavirus death rate than “**_Low or No Lockdown_**” places, this report further explains, is solely attributable to one fact alone—nearly all coronavirus deaths are occurring in elderly people already having serious underlying health conditions like heart disease, diabetes and morbid obesity—and most important to know about, are seriously ill elderly people crammed into nursing homes managed by socialist governments—thus making it no wonder why **American** experts are pointing out such obvious facts as: “**_[So rather than wipe out $4 trillion of GDP via Lockdown Nation they might have started with say $25 billion of incremental money for Medicare/Medicaid and the state public health agencies to zero-in on protecting, isolating and treating the nursing home residents](https://www.zerohedge.com/health/david-stockman-three-nations-covid-windbag-named-fauci)_**”.

But as is becoming more known to the peoples awakening the world over as to what is really happening, this report continues, this coronavirus pandemic has nothing at all to do with death and disease—as what it’s truthfully all about is establishing a new world order to replace the current one that’s spent decades destroying itself—and a crisis such as this one is deliberately engineered to achieve—a **_FACT_** well known to top socialist **Obama-Clinton Regime** official **[Edward Fishman](https://www.cnas.org/people/edward-fishman-1)**—who in his just published strategic socialist-globalist white paper titled “**[The World Order Is Dead. Here’s How to Build a New One for a Post-Coronavirus Era](https://www.politico.com/news/magazine/2020/05/03/the-post-coronavirus-world-order-230042)**”, shows what these godless monsters’ true vision and purpose is with the frightening words:

**_International orders seldom change in noticeable ways._**

**_Just as Rome wasn’t built in a day, the Pax Romana was not a passing phase: it persisted for centuries. The order that arose from the 1815 Congress of Vienna didn’t fully unravel until the outbreak of World War I in 1914._**

**_As the most far-reaching global disruption since World War II, the coronavirus pandemic is such a moment._**

**_The post-1945 world order has ceased to function._**

**_But at rare moments, confidence in the old order collapses and humanity is left with a vacuum._**

**_It is during these times that new orders are born_****_—that new norms, treaties and institutions arise to define how countries interact with each other and how individuals interact with the world._**

**_Whether we like it or not, a new order will emerge as the pandemic recedes_****_._**

**_Five years ago, I represented the State Department in an inter-agency project to evaluate the future of the international order._**

**_We studied past transitions and discussed possible reforms._**

**_We recognized that the order was fragile and needed repair, but we also appreciated the power of inertia—it takes extreme moments for leaders to accept that the old order is broken and summon the will to forge a new one._**

**_Now that extreme moment is here._**

**_The coronavirus will arrest our lives longer than we’d like, but not forever—and when the crisis passes,_** **_the contours of the new order will take shape rapidly_****_._**

**_To ensure that brief window is put to good use and not consumed by squabbling, U.S. and world leaders should begin collaborating now to formulate principles._**

**_It would be foolish to expect President Donald Trump, who is one of the reasons that today’s international order isn’t working, to spearhead planning for a new one._**

**_We might have to wait for a more internationally minded president to form the institutions of the new order._**

![](app24.jpg)

In what future historians may well record as the greatest understatement made of this present world crisis and these momentous times, this report concludes, are these demonic globalist-socialists saying they “**_might have to wait for a more internationally minded president to form the institutions of the new order_**”—a wait that will be long in coming, if ever, because **President Trump** has his own vision of what the new world is going to look like—that includes his “**_vision_**” of smashing these globalist-socialists into oblivion—a wholesale global destruction **President Trump** is now directing towards a **Communist China** that is already facing an “**_[Economic Reckoning](https://www.zerohedge.com/geopolitical/china-faces-economic-reckoning-covid-19-turns-world-against-globalisation)_**” as the world turns away from globalization because of the coronavirus pandemic—is a **Communist China** the **[US is directly blaming for causing the coronavirus pandemic](https://dnyuz.com/2020/05/03/pompeo-ties-coronavirus-to-china-lab-despite-spy-agencies-uncertainty/)**, and which **[US and British intelligence agencies are now accumulating the evidence to prove](https://www.rt.com/news/487661-china-covid-dossier-leaked/)**—is evidence, however, top **Communist China** aligned socialist **Democrat Party** leader **US House Speaker Nancy Pelosi** is now **[furiously trying to block before the American people can see it](https://www.breitbart.com/politics/2020/05/03/congressman-nancy-pelosi-blocking-investigation-chinese-coronavirus-origins/)**—but whose ill fated effort to do so is coming at the same time top experts are warning that **[Communist China’s collapse on the world stage is coming within three years](https://www.thegatewaypundit.com/2020/05/china-expert-peter-zeihan-says-chinas-collapse-world-stage-coming-within-three-years-provide-support/)**—a collapse that will plunge the proverbial stake into the very heart of the planned globalist-socialist new world order, and that **President Trump** is now **[rapidly accelerating with his push to rip all global supply chains out of Communist China](https://www.reuters.com/article/us-health-coronavirus-usa-china/trump-administration-pushing-to-rip-global-supply-chains-from-china-officials-idUSKBN22G0BZ)**—and comes at the same time **President Trump** is **[starting his first negotiations on a new US-British trade agreement](https://www.politico.com/news/2020/05/03/britain-trade-talks-232806)**—a new **US-British** trade agreement **President Trump** is using to put the globalist-socialist **European Union** into the grave it belongs in—and when looking at everything **President Trump** is doing, makes it no surprise that **Warren Buffet**, the world’s acknowledged greatest financial geniuses, and forth richest person, has just declared that he’s confident the **US** economy will bounce back from its pummeling by the coronavirus pandemic because “**_[American Magic Has Always Prevailed](https://www.breitbart.com/news/warren-buffett-american-magic-will-spur-us-economic-recovery/)_**”—and in this go-around is being presided over by the greatest master-magician **America**, indeed the world, has ever seen—**President Donald J. Trump**.  

![](app25.jpg)

May 4, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Coronavirus “_Wisdom_” Lays Waste To America While Prosecutor Durham Goes On Hiring Spree](https://www.whatdoesitmean.com/index3195pl.htm)**

**[Stone Cold Truth Feared By Elites Points To Viking King Trump Saving America](https://www.whatdoesitmean.com/index3195.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**