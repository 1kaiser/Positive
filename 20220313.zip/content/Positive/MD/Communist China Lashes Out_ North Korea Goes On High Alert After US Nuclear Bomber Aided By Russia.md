        Communist China Lashes Out, North Korea Goes On High Alert After US Nuclear Bomber Aided By Russia  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Coronavirus Pandemic War Series: Part 1](https://www.whatdoesitmean.com/index3167.htm)**   **[Coronavirus Pandemic War Series: Part 2](https://www.whatdoesitmean.com/index3181.htm)    [Coronavirus Pandemic War Series: Part 3](https://www.whatdoesitmean.com/index3192.htm)**

**[Coronavirus Pandemic War Series: Part 4](https://www.whatdoesitmean.com/index3203.htm)**    **[Coronavirus Pandemic War Series: Part 5](https://www.whatdoesitmean.com/index3212.htm)**    **[Coronavirus Pandemic War Series: Part 6](https://www.whatdoesitmean.com/index3221.htm)**

**\[Note: For most complete context of this historic event, each of these war series parts should be read from their top report down before moving on to the next one.\]**

**[Trump Accuses Communist China Of “_Mass Worldwide Killing_” Then Issues Documents Of War](https://www.whatdoesitmean.com/index3222.htm)**

**[Communist Chinese Saboteur Identified By Russia Killed In Texas Naval Base Shootout](https://www.whatdoesitmean.com/index3223.htm)**

**[Doomsday Deadline Nears As Communist Chinese Hong Kong Anschluss Turns 2020 Into 1938](https://www.whatdoesitmean.com/index3224.htm)**

May 24, 2020

**Communist China Lashes Out, North Korea Goes On High Alert After US Nuclear Bomber Aided By Russia**

By: Sorcha Faal, and as reported to her Western Subscribers

An intriguing new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today discussing rapidly changing events occurring in the “**_[Coronavirus Pandemic War](https://www.whatdoesitmean.com/index3167.htm)_**”, says most notable to document is **Communist Chinese Foreign Minister Wang Yi** having just stated: “**_[It has come to our attention that some political forces in the US are taking China-US relations hostage and pushing our two countries to the brink of a new Cold War](https://www.capitalfm.co.ke/news/2020/05/china-warns-us-pushing-relations-to-brink-of-new-cold-war/)_**”—and even though **Foreign Minister Wang** did **[not identify what “_forces_” he was referring to](https://www.capitalfm.co.ke/news/2020/05/china-warns-us-pushing-relations-to-brink-of-new-cold-war/)**, his statement provoked **North Korean** leader **Kim Jong-un** to immediately **[urge his army’s top brass to boost the country’s “_strategic forces_” and put them on high alert](https://www.rt.com/news/489603-kim-nuclear-war-deterrent/)**—all of which was caused by an agreement made this past week between the **Ministry of Defense** ([MoD](https://eng.mil.ru/)) and the **United States Indo-Pacific Command** (**[USINDOPACOM](https://www.pacom.mil/)**)—an agreement that permitted a **US Air Force** nuclear weapons and mine laying capable **[B-1 Heavy Bombe](https://en.wikipedia.org/wiki/Rockwell_B-1_Lancer)**r to make a “**_[bold flight](https://www.thedrive.com/the-war-zone/33637/b-1b-bomber-made-bold-flight-into-the-sea-of-okhotsk-that-is-surrounded-by-russian-territory)_**” on **21 May** from **[Anderson Air Base-Guam](https://en.wikipedia.org/wiki/Andersen_Air_Force_Base)** into the of **[Sea Of Okhotsk](https://en.wikipedia.org/wiki/Sea_of_Okhotsk)** that’s surrounded by **Russian Federation** territory—a test flight that saw this **B-1 Heavy Bomber**, designated as “**_[DODGE01](https://www.thedrive.com/the-war-zone/33637/b-1b-bomber-made-bold-flight-into-the-sea-of-okhotsk-that-is-surrounded-by-russian-territory)_**”, being **[advised on open airwaves by Tokyo Radio to change to VFR (_visual flight rules_) due to its not being able to enter Russia by IFR (_instrument flight rules_) flight](https://www.thedrive.com/the-war-zone/33637/b-1b-bomber-made-bold-flight-into-the-sea-of-okhotsk-that-is-surrounded-by-russian-territory)**—critical advice needed as the international airspace this **B-1 Heavy Bomber** was navigating is just **22.1 kilometers** (**13.7 miles**) wide—but even within this small area placed it in range of the **MoD’s** powerful long-range **[S-400 Missile System](https://en.wikipedia.org/wiki/S-400_missile_system)**—the same **S-400 Missile System** the **[MoD completed the delivery of two brigades worth to Communist China in February](https://thediplomat.com/2020/02/russia-completes-delivery-of-second-s-400-regiment-to-china/)**—and whose close range electronic targeting characteristics of this **B-1 Heavy Bomber** has no doubt accumulated valuable information about.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](dtk21.jpg)

**Russian military makes “_agreement_” with American military commanders not to shoot down US Air Force B-1 Heavy Bomber as it threads the needle in international airspace (_flight track above_) to skirt Russian Federation territory on 21 May 2020…**

![](dtk22.jpg)

**…but it was electronically locked on and tracked by powerful S-400 Missile Systems (_above_).** 

According to this report, and though unstated, the “**_political_** **_forces_**” **Communist China** claims are pushing it and the **United States** to the brink of **Cold War** are the **American** leaders supporting a **US** military that’s now making such “**_agreements_**” with **Russia**—as the greatest fear these communists have is a **US-Russia** rapprochement that would see them having to confront the two most powerful nuclear armed nations in the world.

With **Russia** and the **United States** both being **Christian** nations fully supporting the free religious rights of their citizens, this report notes, when **President Donald Trump** won his stunning election victory due to the overwhelming support of his country’s **Christian** citizens, the godless religion hating nation of  **Communist China** faced the greatest existential threat in its history—as did also the demonic socialist **Democrat** **Party** in **America**—both of whom then joined forces to wage an all-out war on **President Trump** to keep him from aligning the **US** with **Russia** against **Communist China**—and while watching all of their efforts fail, as neither **President Trump** nor **President Putin** took the bait to wage war on each other, then saw these vile monsters unleashing on the world their coronavirus pandemic.

Across **Europe** today, however, this report continues, **[fears that lifting their months-long coronavirus lockdowns would lead to a new wave of infections and deaths have so far not materialized](https://www.courthousenews.com/optimism-spreads-in-europe-as-infections-decline/)**—unjustified fears as confirmed by new data showing that **[all of the CDC’s predictions were garbage, and that prove the coronavirus fatality rate could be as low as 0.26%](https://www.redstate.com/michael_thau/2020/05/23/842684/)**\---thus proving beyond any doubt that “**_garbage_**” was the cause of **[the worst spike of unemployment in US history throwing 1-in-4 American workers out of their jobs](https://www.zerohedge.com/personal-finance/worst-unemployment-spike-history-1-4-american-workers-has-filed-unemployment)**—the catastrophic consequence of which has led to an unprecedented suicide wave striking the **United States** so severe its doctors are now declaring “**_[We've Never Seen Numbers Like This Before](https://www.zerohedge.com/health/bay-area-hospital-sees-unprecedented-spike-suicides-during-lockdowns)_**”—and whose soaring suicide wave deaths now occurring in the **US** have **[experts further warning that their numbers will exceed those caused by the coronavirus](https://www.rt.com/op-ed/489584-covid-lockdown-suicide-deaths/)**.

As to the **American** people being allowed to know the truth of what is happening, this report details, **Communist Chinese** and socialist **Democrat Party** aligned **US** tech giants and mainstream media outlets are doing everything in their power to see this doesn’t happen—best exampled over the past few days by **Facebook** **[blacklisting](https://banned.news/2020-05-20-facebook-blacklists-free-speech-video-platform-brighteon.html)** the free speech video platform **[Brighteon.com](https://www.brighteon.com/)** to **[silence humanitarian voices, such as pioneering women like coronavirus expert Dr. Judy Mikovits and Chinese freedom leader Jennifer Zeng](https://banned.news/2020-05-20-facebook-blacklists-free-speech-video-platform-brighteon.html)**—the leftist **Washington Post** **[using its resources to ferret out and find all coronavirus information they don’t agree with on individual people’s private information computer storage places](https://www.washingtonpost.com/technology/2020/05/20/misinformation-coronavirus-plandemic-workaround/)**—information the **Washington Post** then **[handed over to tech giant Google so it could destroy this private information before the public could even be made aware of it](https://reclaimthenet.org/google-drive-takes-down-user-file-plandemic/)**.  

The chilling effect this mass censorship campaign has had against all true information related to the coronavirus, this report notes, has just been displayed in the actions taken by research scientists at the **[Singapore University of Technology and Design](https://www.sutd.edu.sg/)**—who’ve been using their powerful artificial intelligence computers to accurately track and model the coronavirus—and whose **[models now predict that the United States would be coronavirus free by 20 September](https://nypost.com/2020/05/23/us-could-be-coronavirus-free-by-late-september-scientists-say/)**—but in fear of being blacklisted and censored for telling the truth, “**_[walked back this prediction](https://nypost.com/2020/05/23/us-could-be-coronavirus-free-by-late-september-scientists-say/)_**” before they were destroyed, too.

Having absolutely no fear of being blacklisted and censored, though, this report further details, is “**_[the best coronavirus pandemic modeler in the world](https://www.rumormillnews.com/cgi-bin/forum.cgi?read=147344)_**”—an anonymous research scientist no one knows the name of—who posts their findings under the cryptic name **[Ethical Skeptic](https://twitter.com/EthicalSkeptic)**—and a few hours ago wrote to the world: “**_It is getting to the point where 'conspiracy theorist' is the final useless rhetorical argument of the brain dead & lazy…If we flip a coin & the media wants heads to come up,  just because you caution that 'tails might come up' does not make one therefore a conspiracy theorist_**”.

![](dtk24.jpg)

**Ethical Skeptic says about their latest posted graphic model (_above_):** **“_Our early-on testing kit shenanigans served to mislead our decision makers through falsely high R(t) calculations.  This will need to be addressed as a lesson learned.  Changes are in order.  It is clear there was a purposeful attempt to spin data into creating public panic_**_._”

Watching all of this blacklisting and censorship of true coronavirus information taking place, this report continues, is **United States Attorney General William Barr**—who is **[now preparing to address Section 230, which is the outdated legal protection that has emboldened Big Tech’s censorship](https://banned.news/2020-05-18-us-attorney-general-to-address-section-230-big-tech-censorship.html)**—which explains why **Jack Dorsey**, the head of **Twitter** and world’s acknowledged top censor of the truth, has **[just retweeted](https://www.zerohedge.com/technology/did-jack-dorsey-just-issue-mea-culpa-all-twitter-banned-conspiracy-peddlers)** an essay by **Charles Eisenstein** entitled “**_[The Conspiracy Myth](https://charleseisenstein.org/essays/the-conspiracy-myth/?_page=4)_**” which goes against everything **Twitter** has done—and is made most remarkable because **Twitter** head **Dorsey** has sent out to this fellow tech leaders a message that contains the searing truth:

**_What is a conspiracy theory anyway?_**

**_Sometimes the term is deployed against anyone who questions authority, dissents from dominant paradigms, or thinks that hidden interests influence our leading institutions._**

**_As such, it is a way to quash dissent and bully those trying to stand up to abuses of power._**

**_One needn’t abandon critical thinking to believe that powerful institutions sometimes collude, conspire, cover up, and are corrupt._**

**_If that is what is meant by a conspiracy theory, obviously some of those theories are true._**

**_Does anyone remember Enron? Iran-Contra? COINTELPRO? Vioxx? Iraqi weapons of mass destruction?_**

**_During the time of Covid-19, another level of conspiracy theory has risen to prominence that goes way beyond specific stories of collusion and corruption to posit conspiracy as a core explanatory principle for how the world works._**

**_Fuelled by the authoritarian response to the pandemic (_****_justifiable or not, lockdown, quarantine, surveillance and tracking, censorship of misinformation, suspension of freedom of assembly and other civil liberties, and so on are indeed authoritarian_****_), this arch-conspiracy theory holds that an evil, power-hungry cabal of insiders deliberately created the pandemic or is at least ruthlessly exploiting it to frighten the public into accepting a totalitarian world government under permanent medical martial law, a New World Order (NWO)._**

**_Furthermore, this evil group, this illuminati, pulls the strings of all major governments, corporations, the United Nations, the WHO, the CDC, the media, the intelligence services, the banks, and the NGOs. In other words, they say, everything we are told is a lie, and the world is in the grip of evil._**

**_So what do I think about that theory?  I think it is a myth._**

**_And what is a myth?  A myth is not the same thing as a fantasy or a delusion._**

**_Myths are vehicles of truth, and that truth needn’t be literal._**

**_The classical Greek myths, for example, seem like mere amusements until one decodes them by associating each god with psychosocial forces._**

**_In this way,_** **_myths bring light to the shadows and reveal what has been repressed_****_._**

**_They take a truth about the psyche or society and form it into a story._**

**_The truth of a myth does not depend on whether it is objectively verifiable._**

**_That is one reason why, in The Coronation, I said my purpose is neither to advocate nor to debunk the conspiracy narrative, but rather_** **_to look at what it illuminates_****_._**

**_It is, after all, neither provable nor falsifiable._**

**_What is true about the conspiracy myth?_**

**_Underneath its literalism, it conveys important information that we ignore at great peril._**

![](dtk25.png)

Known as true by vast numbers of the **American** people, too, this report concludes, are that the ancient “**_myths_**” of the religions they worship are not “**_conspiracy theories_**” either—a belief that enrages demonic leftists like **Hollywood** elitist **Mia Farrow**, who has just proclaimed her fondest wish that “**_[Trump Is Going to ‘Kill Off All’ His Supporters By Reopening Churches](https://www.breitbart.com/entertainment/2020/05/23/mia-farrow-trump-is-going-to-kill-off-all-his-supporters-by-reopening-churches/)_**”—as it does, also, **Harvard** psychology professor **Steven Pinker**, who’s just declared: “**_[Belief in an afterlife is a malignant delusion, since it devalues actual lives and discourages action that would make them longer, safer, and happier. Exhibit A: What’s really behind Republicans wanting a swift reopening? Evangelicals](https://www.breitbart.com/health/2020/05/23/harvard-prof-blames-christianitys-malignant-belief-in-afterlife-for-lockdown-protests/)_**”—thus making these godless monsters unable to understand or comprehend why **[thousands of churches across America today are openly defying the lockdown orders placed against them by socialist Democrat Party tyrants](https://thefederalist.com/2020/05/22/thousands-of-churches-are-about-to-defy-lockdown-orders-its-about-time/)**—but is understood by a **President Trump** who’s protecting his nation’s citizens and their free rights—and whom a few hours ago, gave them all hope when he proclaimed “**_[I have a chance to break the deep state](https://www.thegatewaypundit.com/2020/05/president-trump-tells-sharyl-attkisson-interview-air-sunday-chance-break-deep-state/)_**”, but warned whom they’re all up against with the words: “**_[It’s a vicious group of people](https://www.thegatewaypundit.com/2020/05/president-trump-tells-sharyl-attkisson-interview-air-sunday-chance-break-deep-state/)_**”—and as one knows godless demons truly are.

![](dtk26.jpg)

May 24, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Coronavirus “_Wisdom_” Lays Waste To America While Prosecutor Durham Goes On Hiring Spree](https://www.whatdoesitmean.com/index3195pl.htm)**

**[Stone Cold Truth Feared By Elites Points To Viking King Trump Saving America](https://www.whatdoesitmean.com/index3195.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**