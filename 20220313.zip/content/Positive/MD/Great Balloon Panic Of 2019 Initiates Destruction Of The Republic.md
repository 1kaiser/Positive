        Great American Balloon Panic Of 2019 Initiates Destruction Of The Republic <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**Great American Balloon Panic Of 2019 Initiates Destruction Of The Republic**

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“In individuals, insanity is rare; but in groups, parties, nations and epochs, it is the rule.”_**

[Friedrich Nietzsche](https://en.wikipedia.org/wiki/Friedrich_Nietzsche) (1844-1900)— German philosopher and cultural critic whose work has exerted a profound influence on modern intellectual history.

**Special Report from Sister Ciara**

**My Dearest Friends:**

When **President Vladimir Putin** banned **Western** food imports in **2014** in a tit-for-tat measure over **Western** sanctions due to the **Ukraine** crisis, it came at the same time **Russians** had developed a taste for **French** and **Italian** cheeses—which afforded **Moscow** an opportunity it seized upon to put in place an “**_import substitution_**” strategy to support local entrepreneurs trying to set up businesses to replace imported goods.

Two such entrepreneurs were long-married high school sweethearts **Elvira and Vyacheslav Kovtun**—whose “**_Peshernyi_**” hard cheese they entered in this year’s **[World Cheese Awards](https://gff.co.uk/awards/world-cheese-awards/)** in **Bergamo-Italy**—a competition similar to the **Oscars** given to films and their stars—where more than **3,800 cheeses** from **42 countries** are awarded supergold, gold, silver or bronze prizes—and at which saw **Elvira** and her husband **Vyacheslav** **[becoming the first Russians to ever win a gold prize](https://www.asianage.com/life/food/271119/russians-now-winning-gold-prize-at-world-cheese-awards.html)**.

After the **Kovtun’s** won the gold medal for their cheese, news of it was posted on the **Twitter** account “**_Good News_**”—which in the **Russian** language is “**_Khoroshiye Novosti_**” and is an information site devoted solely to posting good news and happy things about **Russia**—that is until the story was posted on “**_Good News_**” about high school sweethearts **Elvira** and **Vyacheslav** winning their gold medal—that was followed by **[Twitter shutting down the “_Good News_” site down without any explanation](https://tass.com/society/1092393)**.  

![](van21.jpeg)

**Twitter shuts down Russian “_Good News_” account after it posts story about Elvira Kovtun and her husband Vyacheslav Kovtun (_both_ _above_) who become first Russians to ever win gold medal at World Cheese Awards.**

What brought **Twitter’s** unexplained account suspension of “**_Good News_**” to my mind was a story I read this morning about how truly blessed the **American** people are today as they celebrate their **Thanksgiving Holiday**—all of whom live in a nation whose economic success under **President Donald Trump** is **[the envy of the world](http://eng.the-liberty.com/2019/7508/)**—and where [a record over **55 million** of its citizens are able to travel during this national holiday to see their loved ones because of the new found confidence they’ve been given](https://www.breitbart.com/politics/2019/11/27/good-economy-consumer-confidence-drive-55-million-americans-thanksgiving-travel-plans/). 

Like **Twitter**, though, the entire **American** mainstream media has an absolute hatred of “**_Good News_**”—because at the exact same time their nation’s citizens are celebrating with confidence this **Thanksgiving**—they’ve decided to **[ignore every good economic story in their nation while going into a full blown panic about parade balloons](https://www.newsbusters.org/blogs/nb/nicholas-fondacaro/2019/11/27/nets-prefer-panic-about-parade-balloons-ignore-good-economy)**.

![](van23.png)

**American mainstream media totally ignores soaring economy President Donald Trump has created to instead launch themselves into a full blown panic about parade balloons in New York City.**

Now there are many definitions for the word insanity—**_such as the state of being seriously mentally ill, madness, loss of reason, hysteria, unsoundness of mind and craziness_**—but as it applies to what is now happening in **America**, I find myself remembering this truism stated by **19th Century** philosopher **Friedrich Nietzsche**—“**_[In individuals, insanity is rare; but in groups, parties, nations and epochs, it is the rule.](https://www.brainyquote.com/quotes/friedrich_nietzsche_137291)_**”

As I’m sure everyone of you will agree, we all have family members, friends and acquaintances we’d describe as nutty, batty or eccentric—as well as our knowing that there are those whom we know that feel the same about us—but to meet a real insane person is a rarity reserved near exclusively to those working in the mental hospitals—as insane people are extremely dangerous and a threat to life to themselves and others.

In an **_epoch_**, however—**_which is the beginning of a distinctive period in the history of someone or something_**—insanity is not only the norm, it’s the rule—and in this particular one we’re living through we can rightfully call the **Donald Trump Epoch**, it bears our taking a short journey back in time to see how this epoch began.

A journey to the start of this epoch sees our first and most important stop being in **2016** when **Donald Trump** was elected to be the **President of the United States**—an election win by **Trump** said to have been masterminded by **Russia**—but in the **[conclusions reached about the 2016 election](https://www.pnas.org/content/early/2019/11/20/1906420116)** by the **Proceedings of the National Academy of Sciences of the United States of America** ([PNAS](https://www.pnas.org/)), they found that of all the social media accounts by **Russians** that could have possibly been seen by **American** voters:  “**_[We find no evidence that interacting with these accounts substantially impacted political attitudes and behaviors.](https://www.dailywire.com/news/study-russian-trolls-dont-actually-influence-americans-in-any-meaningful-way)_**”

If it isn’t really true that **Russia** caused the insanity this epoch was begun with, you may ask, what did?

For that answer we journey back to early **2017** and two people—the first one being **[FBI Attorney Kevin Clinesmith](https://www.redstate.com/elizabeth-vaughn/2019/11/27/fbi-lawyer-kevin-clinesmiths-alterations-may-pivotal-media-admits/)**, who created the **FISA** warrant to spy on **President Trump** and then proclaimed “**_[I Have Initiated the Destruction of the Republic!](https://www.thegatewaypundit.com/2019/11/i-have-initiated-the-destruction-of-the-republic-breaking-exclusive-adulterous-attorney-kevin-clinesmith-after-first-carter-page-fisa-app-originated/)_**”—and the second being an attorney named **[Mark Zaid](https://www.foxnews.com/politics/coup-has-started-whistleblowers-attorney-said-in-2017-posts-calling-for-impeachment)**, who **10-days** after **Trump** was sworn into office, posted his prediction declaring “**_[coup has started… first of many steps…rebellion….impeachment will follow ultimately](https://www.foxnews.com/politics/coup-has-started-whistleblowers-attorney-said-in-2017-posts-calling-for-impeachment)_**”—an impeachment prediction **Zaid** made come true as **[he’s the attorney for CIA whistleblower Eric Ciaramella](https://www.thegatewaypundit.com/2019/11/mark-zaid-retweets-claim-he-is-attorney-for-alleged-whistleblower-eric-ciaramella/)** whose **[made up lies](https://www.thegatewaypundit.com/2019/11/breaking-anti-trump-cia-whistleblower-ciaramella-panicked-after-caught-lying-on-icig-complaint-tried-to-revamp-statement-on-oct-8-after-he-was-caught-on-oct-2/)** **Trump** is now facing impeachment for. 

![](van24.jpg)

![](van25.jpg)

It goes without my having to remind you that **FBI Attorney Kevin Clinesmith** and attorney **Mark Zaid** are just two bit players in the attempted overthrow coup of **President Donald Trump** whose cast of characters and their crimes are **[extremely well documented](https://www.amazon.com/Russia-Hoax-Illicit-Hillary-Clinton/dp/0062872745)** for anyone caring to know them—but who both do provide us the knowing of the insane mindset which kicked off this epoch we’re now living in—as no person of sane mind would wish for their own nation to be destroyed, or see its democratically elected leader be overthrown in a coup.

Which brings us on our journey to of all places the **State of New Jersey**—where thanks to the highest property taxes in **America** and an unsustainable cost of living, **[44% of its residents say they plan to leave there in the “_not so distant future_”](https://www.zerohedge.com/economics/nj-become-wasteland-44-residents-plan-flee-state)**—many of whom we can assume live in the small community of **[Whippany-New Jersey](https://en.wikipedia.org/wiki/Whippany,_New_Jersey)** represented by moderate **Democrat** lawmaker **[US Congresswoman Mikie Sherrill](https://en.wikipedia.org/wiki/Mikie_Sherrill)**—a rather safe assumption based on the fact that when **Congresswoman Sherrill** held a town hall meeting of its citizens this past week, it **[blew up in her face when she was confronted by a wave of anger of these citizens outraged by the unjust impeachment coup against Trump](https://www.politico.com/news/magazine/2019/11/27/mikie-sherrill-impeachment-tearing-apart-her-district-074097)**—and where one of its citizens “**_[very disturbed](https://www.politico.com/news/magazine/2019/11/27/mikie-sherrill-impeachment-tearing-apart-her-district-074097)_**” about **Congresswoman Sherrill** stated: “**_[I thought, by now, after the two weeks of hearings, she would have seen, ‘Oh, my God, there’s nothing there.](https://www.politico.com/news/magazine/2019/11/27/mikie-sherrill-impeachment-tearing-apart-her-district-074097)’_**_”_

![](van26.jpg)

**US Congresswoman Mikie Sherrill (_above at Whippany-New Jersey town hall meeting on 25 November 2019_) faces the wrath of her voters angered at how unjustly President Donald Trump is being treated by Democrats.**

**Congresswoman Sherrill** isn’t alone in facing the wrath of her voters enraged over what’s being done to **President Trump**—and is why **[top Democrats have conceded that they’re losing this impeachment battle](https://pjmedia.com/trending/top-democrats-concede-theyre-losing-the-impeachment-battle/)**—a losing overthrow coup effort being met by the campaign manager of newly entered **Democrat** presidential candidate for **Mike Bloomberg** having just dropped a bombshell on **CNN** yesterday with his truthfully saying: “**_[Impeachment Proceedings Are Making President’s Re-election More Likely, Not Less](https://www.thegatewaypundit.com/2019/11/impeachment-proceedings-are-making-presidents-re-election-more-likely-not-less-michael-bloombergs-campaign-manager-drops-a-bomb-on-cnn/)_**”.

Which brings us to the final stop of our journey into learning about this new insane epoch we’re living in—**YOUR DOORSTEP!**

Where if you imaginatively peer towards right now on this most blessed of **Thanksgiving** days—you’ll see me and my **Dear Sisters** huddled with open hands in the hope you find us worthy of dropping a few morsels from your banquet feast table into.

Upon your dropping these few morsels into our hands, our **Lord** magnifies your kind hearted generosity into a magnificent creation that allows your fellow citizens in **Whippany-New Jersey**—**_and indeed throughout your great land_**—to know true things—the proof and evidence of which can be seen in how we, **and others like us**, have taken on the entire corrupt **American** mainstream media and are winning against them—after all, how else can you explain the mainstream media’s total and absolute failure to keep the truth from being known other than with the word **miraculous**!  

Our demonic enemies controlling the insanity of this epoch know this fact too—and is why they harden the hearts of those not wishing to share the bounty of their table with those seeking aid for others—but to defend against, our **Lord** has given us direction with the words I pray your heart can hear today: “**_[Now he who supplies seed to the sower and bread for food will also supply and increase your store of seed and will enlarge the harvest of your righteousness.](https://dailyverses.net/giving)_**”

With God,

Sister Ciara

Dublin, Ireland

28 November 2019

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/21bKL5?ref=ab_48h7S4_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s November, 2019/December, 2019 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 93”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/index.htm)

[](https://www.whatdoesitmean.com/indexnews.htm)