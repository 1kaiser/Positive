        Russia Warns Of Crushing Nuclear Response After Bioweapon Attack On Trump Confirmed  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Coronavirus Pandemic War Series: Part 1](https://www.whatdoesitmean.com/index3167.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 2](https://www.whatdoesitmean.com/index3181.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 3](https://www.whatdoesitmean.com/index3192.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Trump Saves World From Socialist Run “_Death Zones_” In People’s Republic Of Coronastan](https://www.whatdoesitmean.com/index3193.htm)**

**[Looming Coronavirus Famines Of Biblical Proportions Cause American People To Flee And Revolt](https://www.whatdoesitmean.com/index3194.htm)**

**[US Makes Shock Nuclear Bombing Run On China—Bioweapon Labs Warned To Be Targets](https://www.whatdoesitmean.com/index3196.htm)**

**[Trump-Putin Issue Rare Joint Statement On “_Decisive Defeat Of Nazi Regime_”—Then Ponder World War III](https://www.whatdoesitmean.com/index3197.htm)**

**[American People Vacationing In Coronavirus Gulag Fail To Grasp Historic Enormity Of Global Destruction](https://www.whatdoesitmean.com/index3198.htm)**

**[Suicided New York City Doctor Believed Was Witness To Coronavirus Patients Being Murdered](https://www.whatdoesitmean.com/index3199.htm)**

**[China Targets US Warship While UN Calls For Western Destruction And Socialists Demand Families Be Abolished](https://www.whatdoesitmean.com/index3200.htm)**

April 30, 2020

**Russia** **Warns Of Crushing Nuclear Response After Bioweapon Attack On Trump Confirmed**

By: Sorcha Faal, and as reported to her Western Subscribers

A fearfully worded new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today noting the latest grave developments occurring in the “**_[Coronavirus Pandemic War](https://www.whatdoesitmean.com/index3167.htm)_**”, says the just released **Ministry of Defense** ([MoD](https://eng.mil.ru/)) assessment of current **Comprehensive National Power** ([CNP](http://web.isanet.org/Web/Conferences/CEEISA-ISA-LBJ2016/Archive/01043de7-0872-4ec4-ba80-7727c2758e53.pdf)) alignments conducted with the **United Service Institution of India** ([USI](https://usiofindia.org/)), conclusively confirms the findings of **[Major General Shashi Asthana](https://moderndiplomacy.eu/author/shashiasthana/)** that an “**_[Undeclared World War III](https://www.wionews.com/opinions-blogs/coronavirus-outbreak-has-added-a-new-dimension-to-undeclared-world-war-iii-295584)_**” now exists between the **United States** and **Communist China**, and to which “**_[the coronavirus outbreak has added a new dimension](https://www.wionews.com/opinions-blogs/coronavirus-outbreak-has-added-a-new-dimension-to-undeclared-world-war-iii-295584)_**”.

A “**_new dimension_**” being troublingly confirmed with the shock revelation that **[China stole the coronavirus treatment drug Remdesivir from US pharmaceutical giant Gilead this past January and tried to patent it so they could make money off the pandemic](https://www.thegatewaypundit.com/2020/04/china-stole-remdesivir-gilead-tried-patent-drug-january-knowing-months-ago-treat-coronavirus-trying-make-money-off-pandemic/)**—as well as **American** military forces being directly targeted with the coronavirus—that include **[US Marine forces whose bases in the United States are being attacked](https://www.zerohedge.com/health/covid-19-rips-through-marine-boot-camp-dozens-new-infections)**—but even more concerning are the **US Navy** warships being attacked—such as the **[guided-missile destroyer USS Kidd that was inexplicably attacked by the coronavirus a month after it had left port](https://news.usni.org/2020/04/28/uss-kidd-arrives-in-san-diego-to-treat-covid-19-outbreak-first-cases-emerged-more-than-a-month-after-hawaii-port-visit)**—and the **[nuclear armed aircraft carrier USS Theodore Roosevelt that has begun a new investigation as to how it was attacked by the coronavirus](https://www.wsj.com/articles/navy-will-reopen-investigation-of-uss-roosevelt-virus-outbreak-11588171904)**.

While watching **American** military strength being crippled by the coronavirus, **Communist China** has unleashed a withering attack on the **United States**—accusing the **US** of “**_[lying through its teeth](https://pjmedia.com/news-and-politics/rick-moran/2020/04/29/china-accuses-the-u-s-of-lying-through-its-teeth-on-coronavirus-response-n386565)_**” about the coronavirus, saying the **Americans** “**_[should mind their business](https://pjmedia.com/news-and-politics/rick-moran/2020/04/29/china-accuses-the-u-s-of-lying-through-its-teeth-on-coronavirus-response-n386565)_**”, and firing an accusation declaring that “**_[American leaders have failed their own people and the world](https://www.dailymail.co.uk/news/article-8269707/Chinese-state-media-says-government-failed-people-world-pandemic.html)_**”.

All which **President Donald Trump** responded to by **[ordering US intelligence agencies to begin an immediate and massive investigation of both Communist China and the World Health Organization](https://www.thegatewaypundit.com/2020/04/breaking-trump-white-house-orders-intelligence-agencies-comb-communications-china-world-health-organization-collusion-coronavirus/)**—and in acknowledging the reality that he’s under a bioweapon attack, saw **President Trump** stating “**_[China will do anything they can to have me lose this race](https://www.theguardian.com/world/2020/apr/30/trump-claims-china-will-do-anything-to-stop-his-re-election-as-coronavirus-row-escalates)_**”—and in signalling his response to this bioweapon attack designed to throw him from power, saw **President Trump** declaring “**_[I can do a lot](https://www.rt.com/usa/487303-trump-china-reelection-consequences/)_**”.

A declaration of intent **President Trump** is backing up by placing low-yield nuclear weapons on **American** submarines as the **US** prepares for war—and while doing sees **anti-Trump** rogue forces in the **Pentagon** itself pushing “**_[Russia more dangerous than ISIS fear porn](https://www.rt.com/op-ed/487287-africom-libya-russia-isis/)_**”—that, in turn, prompted **[Russia to warn that any US attempt to use a low-yield nuclear weapon against a Russian target would set off a massive and crushing nuclear response](https://www.voanews.com/europe/russia-threatens-massive-response-if-us-deploys-low-yield-nukes-subs)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](hek21.jpg)

According to this report, the strategic global military assessment consultations held between **[Defense Minister General of the Army Sergei Shoigu](http://eng.mil.ru/en/management/minister.htm)** and **Major General Shashi Asthana** focused on the concept of **Comprehensive National Power**—a concept developed by several **Chinese** scholars and academic institutions in an attempt to assess and rank the **Comprehensive National Power** of **China** vis-à-vis other major powers—the findings of which **Major General Asthana** has just released in his white paper titled “**[Coronavirus Outbreak Has Added A New Dimension To Undeclared World War III](https://www.wionews.com/opinions-blogs/coronavirus-outbreak-has-added-a-new-dimension-to-undeclared-world-war-iii-295584)**” that, in part, states and warns:

**_The COVID-19 outbreak has demonstrated the potential of a virus as a weapon of mass destruction._**

**_It has added a new dimension to alter the global strategic balance and triggered another chain of events for global strategic dominance, besides unprecedented human sufferings._**

**_Considering the destructive capability of major world powers, a declared World War between combat forces may not occur as it will be devastating for all.  The ‘Force’ for application potential will be measured in terms of Comprehensive National Power (CNP) of the world powers._**

**_It includes economy, military strength (including nuclear capability), strategic posturing, foreign policy/diplomacy, governance, Human Development Index (HDI), technological capability, knowledge information, geography, natural resources, national will and leadership._**

**_Out of all the components of CNP, economic power is the over-riding component dictating the rest.  The dimensions of war have grown globally from erstwhile conventional wars under nuclear hangover (barring nuclear strike on Japan) to the aggressive trade war, military posturing, arms race (including Chemical, biological, radiological and nuclear arsenal), with political bouts interspersed with few offensive actions involving conventional forces._** 

**_The application of economic power had resulted in an intense trade war between the two largest economies - the US and China._**

 **_In Indo-Pacific, the conventional and nuclear-armed combat forces of the US and China are continuing strategic posturing, deterrence and messaging to all stakeholders.  China used combat forces to occupy and develop features in the South China Sea._**

**_The recent US-Iran confrontation after the killing of Major General Qasem Soleimani saw active use of conventional force and brought both countries close to war._** 

**_If all cases of use of conventional forces are linked, then two opposing alliances covering worldwide conflicts appear on the scene, the first one being US-Israel-Saudi Arabia-South Korea-Japan and the other one being China-Russia-North Korea-Iran-Syria, with other countries seeming to be doing the strategic balancing._**

**_The space warfare has taken a dangerous turn with each side taking preparatory actions to destroy each other’s space assets.  The use of elements like misinformation campaign, election meddling, cyberwar, hacking of economic and crucial military network, perception management, is already in progress._**

**_Diplomatic pressures, economic and technological threats, nuclear blackmailing, proxy wars by nations amount to use of force/CNP to achieve strategic objectives._**

**_The number of casualties suffered in ongoing conflicts surpasses the total casualties and refugees of both the earlier world wars put together._**

**_The global strategic situation has graduated to conflicts, the capture of South China Sea, innumerable deaths and economic destruction; hence calling it cold war will be an understatement._**

**_The global situation even before COVID-19 had every element of a World War, except that the dimension, instruments and modalities have changed, and the war has not been ‘formally declared’; hence it may not be wrong to call it an ‘undeclared World War III’._**

**_The outbreak of COVID-19 has put humanity to one of the biggest risks of this century.  It exposed the vulnerability of strongest nations, triggered by a possible biological weapon (accidentally or otherwise)._**

**_While the global powers were busy strengthening other elements of CNP, it exposed the consequences of any possible biological weapon to the world adding a new dimension in ongoing undeclared World War III._**

**_Wuhan being the initial epicentre, the trends in early 2020 suggested a sheer drop in CNP of China with a combined effect of US-China trade war, failing BRI and COVID-19._**

**_The last week of March 2020 onwards saw the epicentres of COVID-19 shifting westwards with the US, Europe and UK emerging to be worst affected._**

**_China, having declared victory over the pandemic, was quick to put back its manufacturing sector in place, trying to boost a ‘COVID-19 economy’ by creating a ‘Health Silk Road’ and re-activating most needed supply chain of medical equipment and medicines, as an attempt to earn maximum profit out of the pandemic, besides attempting to repair its global image._**

**_COVID-19 has exposed some vulnerabilities of the US and created huge trust deficit for China globally_****_; hence the idea of everyone accepting one/two countries as superpowers or global leader may be outdated in future._**

**_The new paradigm will be unlike earlier World Wars_****_, all countries will not be at war, because all of them may not agree to common narratives of key players._**

**_And hence, some countries would be at hot war, some in military posturing stage, and some using other dimensions and instruments of war, simultaneously._**

![](hek22.jpg)

Being least in the world able to understand the catastrophically dangerous totality of this ongoing “**_Undeclared World War III_**”, this report notes, are the peoples of one of this global conflicts largest combatants, the **United States**—the vast majority of whom still exist in a mental fairytale world believing that their greatest threat is a disease, while they remain oblivious to the real threat of nuclear bombs and missiles raining down upon them—a most peculiar mind set whose insane contradictions abound around these peoples by the score—best exampled by socialist **Democrat Party** leader **Governor Gavin Newsom** **[ordering all parks and beaches in California to be closed](https://www.redstate.com/kiradavis/2020/04/29/828459/)** at the **[exact same time the World Health Organization is hailing lock-down free Sweden as the model the world should be following](https://sputniknews.com/europe/202004301079142062-who-hails-lockdown-free-sweden-as-model-for-new-normal-despite-gloomy-covid-19-predictions/)**—but for anyone trying to understand what **Governor Newsom** is really doing, they need only look at the **[$1 billion secretive contract he just gave a Communist Chinese car company to make masks](https://nypost.com/2020/04/21/gavin-newsom-wont-share-details-on-1b-mask-deal-with-china/)**.  

Likewise, this report concludes, these fairytale believing **American** people fail to see the contradiction in **[former First Lady Michelle Obama giving a public service warning to all residents of Washington D.C. to stay indoors at the exact same time her husband former President Barack Obama went golfing](https://pjmedia.com/news-and-politics/matt-margolis/2020/04/29/barack-obama-goes-golfing-during-coronavirus-quarantine-n386764)**—or have even noticed that **[CNN stopped reporting news and began publishing Communist Chinese propaganda](https://thefederalist.com/2020/04/29/who-wrote-this-pro-communist-china-article-cnn-or-xi-jinping/)**—which makes it understandable why one [top former **US Army** military officer](https://www.redstate.com/streiff/) is now warning his fellow citizens, who still don’t realize they’re in war: “**_[If You Are Still Wondering How Death Camps Happen Just Take a Look Around You](https://www.redstate.com/streiff/2020/04/29/828354/)_**”.

![](hek23.jpg)

April 30, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Coronavirus “_Wisdom_” Lays Waste To America While Prosecutor Durham Goes On Hiring Spree](https://www.whatdoesitmean.com/index3195pl.htm)**

**[Stone Cold Truth Feared By Elites Points To Viking King Trump Saving America](https://www.whatdoesitmean.com/index3195.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**