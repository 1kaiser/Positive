        Biden Spits In The Face Of Jesus—Vengeance With Serious Rebuke Comes Next <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

Note: This is an urgent private letter intended for the sole and exclusive use of the patron/donors to the Sisters of Sorcha Faal.

**Biden Spits In The Face Of Jesus—Vengeance With Serious Rebuke Comes Next**

23 April 2021

Hello Folks,

In my letter to you last month, “**[The Watchers Have Arrived—And America Will Never Be The Same](https://www.whatdoesitmean.com/index3518pl.htm)**”, I built upon **Sister Ciara’s** letter, “**[God Is Playing Games With Biden—History Shows This Won't End Well](https://www.whatdoesitmean.com/index3518.htm)**” to expand your knowledge into the rarified world of **Biblical** research being conducted by ancient language experts whose peer reviewed articles in scholarly journals have titles like “**[Who Gave You a Decree? Anonymity as a Narrative Technique in Ezra5:3, 9 in Light of Persian-Period Decrees and Administrative Sources](https://www.jstor.org/stable/10.15699/jbl.1401.2021.4?refreqid=excelsior%3Ae248c80b8ba0e01ed7b4c089771c990b&seq=1)**” and “**[Enochic Biography and the Manuscript History of 1 Enoch: The CodexPanopolitanus Book of the Watchers](https://www.jstor.org/stable/10.15699/jbl.1401.2021.6?refreqid=excelsior%3A9c8201da1635c14c0a9846ff356ee99d&seq=1)**”.

These two scholarly articles I’ve cited are in the academic digital library **[JSTOR](https://about.jstor.org/)**, and other peer reviewed ones like them can be found at the scholarly journals **[Acta Theologica](http://www.scielo.org.za/scielo.php?script=sci_serial&pid=1015-8758&lng=en&nrm=iso)**, **[Ancient Jew Review](https://www.ancientjewreview.com/)**, **[The Pontifical Biblical Institute's Journal](https://www.bsw.org/project/biblica/)**, **[The Journal of Hebrew Scriptures](http://www.jhsonline.org/)** and **[HTS Teologiese Studies/Theological Studies](https://hts.org.za/index.php/HTS)**, to name just a few—the vast majority of which you have no access to unless you’re a scholar—and unless you’re a **Biblical** scholar with at least one doctorate in ancient languages and multiple master degrees, none of them will make any sense to you.

And here’s why, though scholars generally recognize **Hebrew**, **Aramaic**, and **Koine Greek** as original **Biblical** languages, , the writers of the **Bible** using these languages cited known histories, stories and ancient writings using languages like **Akkadian**, **Arabic**, **Coptic**, **Demotic Egyptian**, **Middle Egyptian**, **Hittite**, **Syriac**, **Old Persian**, **Middle Persian** and **Sumerian**—some of which are “**_agglutinating_**” languages (**_simple words or parts of words without change of form to express compound ideas_**) with no known relatives from as far back as **2000 BC**—and whose **Biblical** outlier is **[The Book of Job](https://www.oldest.org/religion/books-in-the-bible/)**, because it not only is the oldest book in the **Bible** dated to **2,000 BC**, its author is unknown, the events it describes are believed to have taken place before the time of **Moses**, possibly during the era of the **Bible’s Patriarchs**, it makes no reference to any other books or events in the **Bible**, uses **Arabic** words and describes **Arabic** customs, opinions, and manners.

I’ve related this information so you can better understand why in my letter to you last month I told you how the **Sisters** believe that the fulfillment of the prophecy given in **[Daniel 12:4](https://www.biblegateway.com/verse/EN/Daniel%2012%3A4)** (“**_But thou, O Daniel, shut up the words, and seal the book, even to the time of the end: many shall run to and fro, and knowledge shall be increased._**”) is now being witnessed—and is being fulfilled because of the explosion of knowledge about ancient **Biblical** languages that’s been happening over the past two decades, and whose new discoveries aided by lightning fast global digital communications are hitting **Biblical** scholars with a fire hose of previously unknown and now being connected information.

Now at this point, I’m going to be citing to you **Biblical** verses from **The English Standard Version** ([ESV](https://www.biblegateway.com/versions/English-Standard-Version-ESV-Bible)), wherein each word and phrase has been carefully weighed against the original **Hebrew**, **Aramaic**, and **Greek**, to ensure the fullest accuracy and clarity and to avoid under-translating or overlooking any nuance of the original text—and my first two citations are:

**[Genesis 1: 15-15](https://biblehub.com/esv/genesis/1.htm)**: **_And God said, “Let there be lights in the expanse of the heavens to separate the day from the night._** **_And let them be for signs_** **_and for seasons, and for days and years, and let them be lights in the expanse of the heavens to give light upon the earth._**

**[Romans 10: 14-18](https://biblehub.com/romans/10.htm)**: **_How then will they call on him in whom they have not believed? And how are they to believe in him of whom they have never heard? And how are they to hear without someone preaching? And how are they to preach unless they are sent? As it is written, “How beautiful are the feet of those who preach the good news!” But they have not all obeyed the gospel. For Isaiah says, “Lord, who has believed what he has heard from us?” So faith comes from hearing, and hearing through the word of Christ._** **_But I ask, have they not heard? Indeed they have, for “Their voice has gone out to all the earth, and their words to the ends of the world.”_**

In reading these two citations it’s important for you to remember that these ancient **Biblical** writers viewed the skies above us as the domain of **God**—when viewing the movement of celestial bodies they ascribed them to events happening in **God’s** domain they could glean “**_signs_**” from—is why the **Apostle Paul** in the **Book of Romans** exclaimed that “**_indeed_**” everyone knew about **God** because the evidence was right above them in the skies—and if you walked into just about any **Jewish** synagogue in ancient **Israel** at the time of **Jesus**, is why you would see **[embedded in their floors elaborate mosaics of astrological zodiacs](https://www.myjewishlearning.com/article/astrology-in-the-ancient-synagogue/)**.     

![](jzz21.jpg)

A truth you aren’t being told, but is known as fact by every **Biblical** scholar, is that **[astrology underlies all scripture](https://medium.com/belover/astrology-in-the-bible-5d4abecac741)**—proved in the oldest book **[Job 9:9](https://biblehub.com/esv/job/9.htm)** **_“…who made the Bear and Orion, the Pleiades and the chambers of the south…_**”, in **[Jeremiah 10:2](https://biblehub.com/esv/jeremiah/10.htm)** “**_Learn not the way of the nations, nor be dismayed at the signs of the heavens because the nations are dismayed at them…_**”, **Jesus** even says in **[Luke 21:25](https://biblehub.com/esv/luke/21.htm)** “**_And there will be signs in sun and moon and stars…_**”—and these are but a few of the hundreds of other like examples I can cite.

To keep this truth hidden **[Deuteronomy 18:10–14](https://biblehub.com/esv/deuteronomy/18.htm)** is cited, that says: “**_There shall not be found among you anyone who burns his son or his daughter as an offering, anyone who practices divination or tells fortunes or interprets omens, or a sorcerer 11or a charmer or a medium or a necromancer or one who inquires of the dead, for whoever does these things is an abomination to the LORD. And because of these abominations the LORD your God is driving them out before you. 13You shall be blameless before the LORD your God, for these nations, which you are about to dispossess, listen to fortune-tellers and to diviners. But as for you, the LORD your God has not allowed you to do this._**”—but as all **Biblical** scholars know, the words “**_practices divination_**”, “**_tells fortunes_**” and “**_interprets omens_**” have distinct meanings having nothing at all do with astrology.

In **[Isaiah 47:13](https://biblehub.com/esv/isaiah/47.htm)** it does says: “**_You are wearied with your many counsels; let them stand forth and save you, those who divide the heavens, who gaze at the stars, who at the new moons make known what shall come upon you._**”—but this is a very specific condemnation of Babylon and its wickedness, not an attack on astrology.

Now at this point you have to understand that the “**_astrology_**” practiced and talked about in the **Bible** has nothing at all in common with modern day astrology and/or horoscopes—as its sole purpose was to divine the “**_signs_**” seen in **God’s** abode above the earth and scripturally interpret their meaning.

Before continuing, though, you need to know who **Christian** “**_apologetics_**” are—which is a branch of **Christian** theology that defends **Christianity** against objections (**Greek: ἀπολογία, “verbal defense, speech in defense”**)—that started with **Paul the Apostle** in the **Early Church** and **Patristic** writers such as **Origen** (**who said the stars are** “**_[heavenly writings, which the angels and the divine powers are able to read well . . .](https://medium.com/belover/astrology-in-the-bible-5d4abecac741)_**”) , **Augustine of Hippo**, **Justin Martyr** and **Tertullian**, then continued with writers such as **Thomas Aquinas**, **Duns Scotus**, **William of Ockham**, and today includes those like the **Sisters of Sorcha Faal**.

Next you need to know about **Christian** “**_eschatology_**”—which is a major branch of study within **Christian** theology that deals with “**_last things_**” (**Greek: ἔσχατος, “study” and –λογία, “last”**)—involves the study of “**_end things_**”, whether of the end of an individual life, of the end of the age, of the end of the world or of the nature of the **Kingdom of God**—and focuses on the ultimate destiny of individual souls and of the entire created order, based primarily upon **Biblical** texts within the **Old and New Testaments**.

![](jzz22.png)

![](jzz23.jpg)

Among **Biblical** scholars “**_apologetics_**” rarely enter into anything having to do with “**_eschatology_**”—with one of the lone exceptions being **[Matthew 2: 1-12](https://biblehub.com/esv/matthew/2.htm)** and **[Revelation 12: 1-9](https://biblehub.com/esv/revelation/12.htm)**—both of which are found in the **New Testament** and reference **Old Testament** scriptures—and when examining all of the ancient languages used in them, sees both “**_apologetics_**” and “**_eschatology_**” **Biblical** scholars agreeing that both of them describe astrological events that have already happened, not future ones to come—and are:

**Matthew 2: 1-12:**

**_After Jesus was born in Bethlehem in Judea, during the time of King Herod, Magi from the east arrived in Jerusalem, asking, “Where is the One who has been born King of the Jews?_**

**_We saw His star in the east and have come to worship Him.”_**

**_When King Herod heard this, he was disturbed, and all Jerusalem with him._**

**_And when he had assembled all the chief priests and scribes of the people, he asked them where the Christ was to be born._**

**_“In Bethlehem in Judea,” they replied, “for this is what the prophet has written: ‘But you, Bethlehem, in the land of Judah, are by no means least among the rulers of Judah, for out of you will come a ruler who will be the shepherd of My people Israel._**

**_Then Herod called the Magi secretly and learned from them the exact time the star had appeared. And sending them to Bethlehem, he said: “Go and search carefully for the Child, and when you find Him, report to me, so that I too may go and worship Him.”_**

**_After they had heard the king, they went on their way, and the star they had seen in the east went ahead of them until it stood over the place where the Child was._**

**_When they saw the star, they rejoiced with great delight. On coming to the house, they saw the Child with His mother Mary, and they fell down and worshiped Him._**

**_Then they opened their treasures and presented Him with gifts of gold and frankincense and myrrh._**

**_And having been warned in a dream not to return to Herod, they withdrew to their country by another route._**

**Revelation 12: 1-9:**

**_And a great sign appeared in heaven: a woman clothed in the sun, with the moon under her feet and a crown of twelve stars on her head. 2She was pregnant and crying out in the pain and agony of giving birth._**

**_Then another sign appeared in heaven: a huge red dragon with seven heads, ten horns, and seven royal crowns on his heads. 4His tail swept a third of the stars from the sky, tossing them to the earth. And the dragon stood before the woman who was about to give birth, ready to devour her child as soon as she gave birth._**

**_And she gave birth to a son, a male child, who will rule all the nations with an iron scepter._**

**_And her child was caught up to God and to His throne._**

**_And the woman fled into the wilderness, where God had prepared a place for her to be nourished for 1,260 days._**

![](jzz24.jpg)

![](jzz25.jpg)

In combining the scriptures about the **Magi** following the “**_Signs_**” to the birthplace of **Jesus** with the “**_Great Sign In Heaven_**” described in **The Book of Revelation**, noted **Biblical** “**_apologetics_**” scholars like **[Dr. Michael Heiser](https://drmsh.com/wp-content/uploads/2020/06/Cumulative-Resume-2020.pdf)** had no trouble publishing their research papers with titles like “**[September 11: Happy Birthday to Jesus](https://drmsh.com/september-11-happy-birthday-to-jesus/)**”—as to defend **Christianity** means telling the truth that **Our Lord and Savior Jesus Christ** was born on **11 September 3 BC**.

![](jzz26.jpg)

I have no doubt that barely any of you know this truth about the day our **Lord Jesus** was born on—but make no mistake about it, this true date is known to the demonic monsters that killed/sacrificed over **3,000** innocent human beings to their “**_god_**” on **[11 September 2001](https://www.ae911truth.org/)**—and when I heard that **[Biden announced that all US troops in Afghanistan will be withdrawn by 11 September 2021](https://www.cfr.org/in-brief/biden-afghanistan-troop-withdrawal-september-11)** after this war sacrificed another over **500,000** innocent human beings, this actual demonic spitting in the face of **Jesus** brought immediately to my mind **[Ezekiel 25:17](https://biblehub.com/esv/ezekiel/25.htm)**, where **God** warned all of these demons: “**_And I will execute great vengeance upon them with furious rebukes; and they shall know that I am the LORD, when I shall lay my vengeance upon them._**”.

In this letter I’ve only been able to give you the merest glimpse of the true things being kept from you, and in future ones I’ll build on what you’ve learned so far.

However, this won’t be possible unless you support us today by giving what your heart leads you to bless us with—is a blessing **Our Dear Lord** will repay you many times over if you trust in **His** promises—and I fervently pray you will.

Thank you for listening and aiding us in our hour of desperate need by going below and giving what you can, and as always, please feel free to write me at [sorchafaal@fastmail.fm](mailto:sorchafaal@fastmail.fm) with any comments/questions/suggestions, remembering to put **ATTN: BRIAN** in the subject line.

All the best folks,

Brian

Webmaster

Paris

Fr.

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

**[Return To Main Page](https://www.whatdoesitmean.com/)**