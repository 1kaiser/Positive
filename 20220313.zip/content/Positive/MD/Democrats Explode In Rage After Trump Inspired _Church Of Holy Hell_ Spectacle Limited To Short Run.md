        Democrats Explode In Rage After Trump Inspired “Church Of Holy Hell” Spectacle Limited To Short Run  <!-- /\* Font Definitions \*/ @font-face {font-family:Wingdings; panose-1:5 0 0 0 0 0 0 0 0 0; mso-font-charset:2; mso-generic-font-family:auto; mso-font-pitch:variable; mso-font-signature:0 268435456 0 0 -2147483648 0;} @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} /\* List Definitions \*/ @list l0 {mso-list-id:1128429022; mso-list-type:hybrid; mso-list-template-ids:931556244 67698699 67698691 67698693 67698689 67698691 67698693 67698689 67698691 67698693;} @list l0:level1 {mso-level-number-format:bullet; mso-level-text:\\F0D8; mso-level-tab-stop:.75in; mso-level-number-position:left; margin-left:.75in; text-indent:-.25in; font-family:Wingdings;} @list l0:level2 {mso-level-tab-stop:1.0in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level3 {mso-level-tab-stop:1.5in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level4 {mso-level-tab-stop:2.0in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level5 {mso-level-tab-stop:2.5in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level6 {mso-level-tab-stop:3.0in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level7 {mso-level-tab-stop:3.5in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level8 {mso-level-tab-stop:4.0in; mso-level-number-position:left; text-indent:-.25in;} @list l0:level9 {mso-level-tab-stop:4.5in; mso-level-number-position:left; text-indent:-.25in;} ol {margin-bottom:0in;} ul {margin-bottom:0in;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

January 21, 2020

**Democrats Explode In Rage After Trump Inspired “_Church Of Holy Hell_” Spectacle Limited To Short Run**

By: Sorcha Faal, and as reported to her Western Subscribers

A troubling new **Ministry of Foreign Affairs** ([MoFA](http://government.ru/en/department/92/events/)) report circulating in the **Kremlin** today expressing dismay over events in **Libya** **[spiraling out of control at the same world leaders gather in an effort to prevent this crisis from causing a major war](http://www.hurriyetdailynews.com/libyas-haftar-launches-attack-tests-peace-summit-151251)**, the government of **Lebanon** **[nearing collapse as its citizens are in open revolt](https://www.haaretz.com/middle-east-news/iraq/.premium-lebanon-protesters-may-topple-the-government-but-not-the-regime-1.8414876)**, the government of **France** **[facing a popular uprising described as either a frozen conflict or revolution](https://www.zerohedge.com/political/french-popular-uprising-revolution-or-frozen-conflict)**, the **[International Monetary Fund slashing its global GDP forecast as the world’s shipment of goods continues its epic plunge](https://www.zerohedge.com/markets/baltic-dry-continues-epic-plunge-imf-slashes-global-gdp-forecast)**, and worst of all the **[World Health Organization calling an emergency meeting after China confirmed that a mysterious new virus has killed four people and is being spread person-to-person](https://www.rt.com/news/478757-who-emergency-china-coronavirus/)**, states that left absent from aiding in the solving of these growing catastrophes is the **United States**—the most powerful nation in the world top **Republican Party US Senator Lindsey Graham** is now warning has been hijacked by socialist **Democrat Party House Leader Nancy Pelosi** who he says has “**_[orchestrated the church of holy hell](https://www.axios.com/graham-pelosi-orchestrated-holy-hell-trump-0eb8a71f-77ef-4b6e-9c4d-9409323ef177.html)_**” against **President Donald Trump**—a reference to the **Pelosi** initiated hoax impeachment of **Trump** countered a few hours ago by **Republican Party Senate Leader Mitch McConnell** with his filing of a document titled **[Organizing Resolution](https://apps.npr.org/documents/document.html?id=6662609-McConnell-Organizing-Resolution-for-Senate-Trial)**—a **4-page** document that outlines the **US Senate** impeachment trial of **Trump**—which begins today, will allow the **Democrats** to present their case against **Trump** during **two** **12-hour** **days** on **22-23 January**, followed by **Trump’s** defense being given during **two 12-hour days** on **24-25 January** to present their counter case—followed by **US Senators** being able to submit written questions to **US Chief Justice of the United States John Roberts**, who in turn will ask them to either **Democrats** or **Trump’s** attorneys during **two 8-hour days** on **27-28 January**—after which, on **29 January**, **US Senators** will vote on if they want to have witnesses appear before them—is a schedule **McConnell** created that “**_[shows he’s not playing games](https://www.dailywire.com/news/senate-trial-schedule-released-by-mcconnell-shows-hes-not-playing-games)_**” as he moves to extricate his nation and its citizens from this actual travesty of justice—but predictably is a limited schedule that has “**_[sparked a new outcry from socialist Democrats](https://www.yahoo.com/news/mc-connell-releases-impeachment-trial-rules-sparking-new-outcry-from-democrats-004023244.html)_**”—most particularly **Democrat Party Senate Minority Leader Chuck Schumer** who **Tweeted** out: “**_[After reading his resolution, it’s clear Sen. McConnell is hell-bent on making it much more difficult to get witnesses & documents and intent on rushing the trial through  On something as important as impeachment—Sen. McConnell’s resolution is nothing short of a national disgrace](https://twitter.com/SenSchumer/status/1219403162236395521?ref_src=twsrc%5Egoogle%7Ctwcamp%5Enews%7Ctwgr%5Etweet)_**”—that **Schumer** followed by declaring: “**_[It’s clear Senator McConnell is hell-bent on making it much more difficult to get witnesses and documents and intent on rushing the trial through...Any senator that votes for the McConnell resolution will be voting to hide information and evidence from the American people](https://www.yahoo.com/news/mc-connell-releases-impeachment-trial-rules-sparking-new-outcry-from-democrats-004023244.html)_**”—both of which are impossible to understand as just **24-hours earlier**, **US House Judiciary Chairman Jerry Nadler**, the **Democrats’** top impeachment prosecutor of **Trump** in this **US Senate** trial, gave a nationwide television interview and proclaimed: “**_[We have a very rock solid case...The case we have if presented to a jury would be a guilty verdict in about three minutes flat](https://nypost.com/2019/12/08/nadler-says-jury-would-convict-trump-in-three-minutes-flat-on-evidence-gathered-by-the-house/)_**”—and is the same **Nadler** who “**_[has suggested that, if a trade is needed to secure witnesses, the Democrat managers handling this impeachment will not agree to any witnesses if Hunter Biden is part of the deal](https://jonathanturley.org/2020/01/20/nadler-hunter-biden-must-not-be-called/)_**”.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](cry21.jpg)

**US** **Senate confirms compressed President Donald Trump impeachment schedule…**

![](cry22.jpg)

**…but for what exactly the Democrats have yet to produce any evidence for.**

According to this report, the entire socialist **Democrat Party** impeachment rests on the interpretation of the **[25 July 2019 phone call](https://www.whitehouse.gov/wp-content/uploads/2019/09/Unclassified09.2019.pdf)** held between **President Trump** and **Ukrainian President Volodymyr Zelensky**—the central parts of which are in dispute being two separate discussed items:

**The first coming near the beginning of this call:**

**President Zelensky**: **_I would also like to thank you for your great support in the area of defense...We are ready to continue to cooperate for the next steps…specifically we're  almost ready to buy more Javelins from the United States for defense purposes_**

**President Trump**:  **_I would like you to do us a favor though because our country has been through a lot and Ukraine knows a lot about it…I would like you to find out what happened with this whole situation with Ukraine, they say Crowdstrike…_** **_I would like to have the Attorney General call you or your people and I would like you to get to the bottom of it…_**

**And the second coming near when it ended:**

**President Zelensky**: **_I guarantee as the President of Ukraine that all the investigations will be done openly and candidly…That I can assure you_**

**President Trump**:  **_There’s a lot of talk about Biden’s son…that Biden stopped the prosecution and a lot of people want to find out about that so_** **_whatever you can do with the Attorney General would be great…Biden went around bragging that he stopped the prosecution so if you can look into it … It sounds horrible to me…_**

![](cry23.jpg)

As the official transcript of the **President Trump-President Zelensky** phone call unmistakably proves, this report notes, there are two separate and distinct items being discussed—the first being about **[the Democrat Party controlled computer analysis company Crowdstrike and its links to Ukraine](https://www.thepostemail.com/2019/10/17/is-a-dnc-server-in-ukraine-and-if-so-why/)**—and the second being the **[video](https://www.youtube.com/watch?v=UXA--dj2-CY)** showing **Joe Biden** bragging about having the **Ukrainian** prosecutor investigating his son **Hunter Biden** fired with the words: “**_[So they said they had—they were walking out to a press conference. I said, nah, I’m not going to—or, we’re not going to give you the billion dollars. They said, you have no authority. You’re not the president. The president said—I said, call him. (Laughter.) I said, I’m telling you, you’re not getting the billion dollars. I said, you’re not getting the billion. I’m going to be leaving here in, I think it was about six hours. I looked at them and said: I’m leaving in six hours. If the prosecutor is not fired, you’re not getting the money. Well, son of a b\*\*\*\*\* (Laughter.) He got fired. And they put in place someone who was solid at the time](https://www.thepostemail.com/2019/10/17/is-a-dnc-server-in-ukraine-and-if-so-why/)_**”—both of which **Trump** asked **Zelensky** to look into on behalf of the **United States**—and if anything was found, report that information back to **US Attorney General William Barr**—not to **Trump** himself.

![](cry24.png)

In the greatest miscarriages of justice ever witnessed in all of **American** history, this report continues, socialist **Democrat Party US House Intelligence Chairman Adam Schiff** opened the **26 September 2019** impeached proceedings against **President Trump** by outright lying to its nationwide television/internet/radio audience about the **Trump-Zelensky** phone call—with **Schiff’s** **[vile description of it being](https://www.factcheck.org/2019/10/schiffs-parody-and-trumps-response/)**:

**_It reads like a classic organized crime shakedown._**

**_Shorn of its rambling character and in not so many words,_** **_this is the essence of what the president communicates_****_…_**

**_We’ve been very good to your country, very good._**

**_No other country has done as much as we have._**

**_But you know what? I don’t see much reciprocity here. I hear what you want._**

**_I have a favor I want from you though. And I’m going to say this only seven times so you better listen good._**

**_I want you to make up dirt on my political opponent, understand._**

**_Lots of it._**  **_On this and on that.  I’m going to put you in touch with people, not just any people, I am going to put you in touch with the attorney general of the United States, my Attorney General Bill Barr._**

**_He’s got the whole weight of the American law enforcement behind him. And I’m going to put you in touch with Rudy._**

**_You’re going to love him. Trust me._**

**_You know what I’m asking._**

**_And so I’m only going to say this a few more times.  In a few more ways._**

**_And by the way, don’t call me again.  I’ll call you when you’ve done what I asked._**

![](cry25.png)

In the hours following **House Intelligence Chairman Schiff** treasonously lying about **President Trump** before the entire **American** nation and the world, this report notes, he said his official statement was **[meant as some sort of demented parody](https://www.factcheck.org/2019/10/schiffs-parody-and-trumps-response/)**—but whose intended and intentional damage done because of **Schiff’s** deliberate lies, sees today vast numbers of the **American** people having been brainwashed into believing that **Trump** is being rightfully impeached because he extorted and bribed **Ukraine** to dig up dirt on his political opponent **Joe Biden**—an actual indictment of those **American** people who have yet to **[read the transcript of the Trump-Zelensky phone call](https://www.whitehouse.gov/wp-content/uploads/2019/09/Unclassified09.2019.pdf)** so they can see for themselves how mentally deranged **Schiff** really is—but whose greatest blame for **Schiff’s** lies being spread falls on the entire **Trump-hating** leftist **US** mainstream propaganda media establishment—who know the truth, but still refuse to tell it to the **American** people.

![](cry26.jpg)

As to how the socialist **Democrat Party** and their leftist mainstream propaganda media lapdogs ever thought they’d get away with this impeachment hoax, this report concludes, it would take the world’s top psychiatrists to figure out—most particularly because everyone having a sound and rational mind knew that **President Trump** has been lying in wait ready to pounce like a “**_King of the Jungle_**” lion on these liars and devour them all—a fitting metaphor that describes a withering **110-page** legal brief titled **[IN PROCEEDINGS BEFORE THE UNITED STATES SENATE TRIAL--MEMORANDUM OF PRESIDENT DONALD J. TRUMP](https://www.whitehouse.gov/wp-content/uploads/2020/01/Trial-Memorandum-of-President-Donald-J.-Trump.pdf)** filed with the **US Senate** a few hours ago—wherein of the multiple shocking and stunning truths about to be fully revealed to the **American** people during this impeachment trial that have been monstrously been kept hidden from them by the demented **Democrats** and lying leftist media, one of the most devastating is in the section titled “**[It Would Have Been Appropriate for President Trump To Ask President Zelensky About the Biden-Burisma Affair](https://www.whitehouse.gov/wp-content/uploads/2020/01/Trial-Memorandum-of-President-Donald-J.-Trump.pdf)**” that begins on **page-102**—the section **Joe Biden** has just “**_[warned the media not report on, or else](https://www.rt.com/usa/478746-biden-warns-media-ukraine/)_**”—and which reveals why these **Democrats** won’t even dare push for impeachment witnesses because they know that two of them will be **Joe Biden** and **Hunter Biden**—neither of whom have even the slightest hope of surviving what **Trump** has in store for them—to include this document’s systematic recitation of truthful and provable facts that say:

**_House Democrats’ theory that there could not have been any legitimate basis for a President of the United States to raise the Biden-Burisma affair with President Zelensky is also wrong. The following facts have been publicly reported:_**

Ø     **Burisma is a Ukrainian energy company with a reputation for corruption. Lt. Col. Vindman called it a “corrupt entity.”  It was founded by a corrupt oligarch, Mykola Zlochevsky, who has been under several investigations for money laundering.**

Ø     **Deputy Assistant Secretary of State Kent testified that Burisma’s reputation was so poor that he dissuaded the United States Agency for International Development (USAID) from co-sponsoring an event with Burisma.  He testified that he did not think co-sponsorship with a company of Burisma’s reputation was “appropriate for the U.S. Government.”**

Ø     **In April 2014, Hunter Biden was recruited to sit on Burisma’s board.742 At that time, his father had just been made the “public face of the \[Obama\] administration’s handling of Ukraine,” and Britain’s Serious Fraud Office (SFO) had just recently frozen $23 million in accounts linked to Zlochevsky as part of a money-laundering investigation. Zlochesvsky fled Ukraine sometime in 2014.**

Ø     **Hunter Biden had no known qualifications for serving on Burisma’s board of directors, and just two months before joining the board, he had been discharged from the Navy Reserve for testing positive for cocaine on a drug test.  He himself admitted in a televised interview that he would not have gotten the board position “if \[his\] last name wasn’t Biden.”**

Ø     **Nevertheless, Hunter Biden was paid more than board members at energy giants like ConocoPhillips.**

Ø     **Multiple witnesses said it appeared that Burisma hired Hunter Biden for improper reasons.**

Ø     **Hunter’s role on the board raised red flags in several quarters.  Chris Heinz, the stepson of then-Secretary of State John Kerry, severed his business relationship with Hunter, citing Hunter’s “lack of judgment” in joining the Burisma board as “a major catalyst.”**

Ø     **Contemporaneous press reports openly speculated that Hunter’s role with Burisma might undermine U.S. efforts—led by his father—to promote an anti-corruption message in Ukraine.  Indeed, The Washington Post reported that “\[t\]he appointment of the vice president’s son to a Ukrainian oil board looks nepotistic at best, nefarious at worst.”**

Ø     **Within the Obama Administration, Hunter’s position caused the special envoy for energy policy, Amos Hochstein, to “raise” the matter with Biden.”  Deputy Assistant**

Ø     **Secretary of State Kent testified that he, too, voiced concerns with Vice President Biden’s office.**

Ø     **In fact, every witness who was asked agreed that Hunter’s role created at least the appearance of a conflict of interest for his father.**

Ø     **On February 2, 2016, the Ukrainian Prosecutor General obtained a court order to seize Zlochevsky’s property.**

Ø     **According to press reports, Vice President Biden then spoke with Ukraine’s President Poroshenko three times by telephone on February 11, 18, and 19, 2016.**

Ø     **Vice President Biden has openly bragged that, around that time, he threatened President Poroshenko that he would withhold one billion dollars in U.S. loan guarantees unless the Ukrainians fired the Prosecutor General who was investigating Burisma. Deputy Assistant Secretary Kent testified that the Prosecutor General’s removal “became a condition of the loan guarantee.”**

Ø     **On March 29, 2016, Ukraine’s parliament dismissed the Prosecutor General. In September 2016, a Kiev court cancelled an arrest warrant for Zlochevsky.**

Ø     **In January 2017, Burisma announced that all cases against the company and Zlochevsky had been closed.**

**_On these facts, it would have been wholly appropriate for the President to ask President Zelensky about the whole Biden-Burisma affair. The Vice President of the United States, while operating under an apparent conflict of interest, had possibly used a billion dollars in U.S. loan guarantees to force the dismissal of a prosecutor who may have been pursuing a legitimate corruption investigation._**

**_In fact, on July 22, 2019—just days before the July 25 call—The Washington Post reported that the fired prosecutor “said he believes his ouster was because of his interest in \[Burisma\]” and “\[h\]ad he remained in his post . . . he would have questioned Hunter Biden.”  Even if the Vice President’s motives were pure, the possibility that a U.S official used his position to derail a meritorious investigation made the Biden-Burisma affair a legitimate subject to raise._**

**_Indeed, any President would have wanted to make clear both that the United States was not placing any inquiry into the incident off limits and that, in the future, there would be no efforts by U.S. officials do something as “horrible” as strong-arming Ukraine into dropping corruption investigations while operating under an obvious conflict of interest._**

**_As the transcript shows, President Zelensky recognized precisely the point_****_.  He responded to President Trump by noting that “\[t\]he issue of the investigation of the case is actually the issue of making sure to restore the honesty\[.\]”_**

**_It is absurd for House Democrats to argue that any reference to the Biden-Burisma affair had no purpose other than damaging the President’s potential political opponent._**

**_The two participants on the call—the leaders of two sovereign nations—clearly understood the discussion to advance the U.S. foreign policy interest in ensuring that Ukraine’s new President felt free, in President Zelensky’s words, to “restore the honesty” to corruption investigations._**

**_Moreover, House Democrats’ accusations rest on the false and dangerous premise that Vice President Biden somehow immunized his conduct (and his son’s) from any scrutiny by declaring his run for the presidency._**

**_There is no such rule of law._**

**_It certainly was not a rule applied when President Trump was a candidate. His political opponents called for investigations against him and his children almost daily._**

**_Nothing in the law requires the government to turn a blind eye to potential wrongdoing based on a person’s status as a candidate for President of the United States._**

**_If anything, the possibility that Vice President Biden may ascend to the highest office in the country provides a compelling reason for ensuring that, when he forced Ukraine to fire its Prosecutor General, his family was not corruptly benefiting from his actions_****_._** 

![](cry27.jpg)

January 21, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Trump Throws Leftists Into Chaos After Committing Crimestop Thought Offense](https://www.whatdoesitmean.com/index3080pl.htm)**

**[Magical Millennials Chart History Free Star-Path To Their Own Destruction](https://www.whatdoesitmean.com/index3080.htm)**

**[Lincoln Jailed Over 13,000 Journalists—Roosevelt Went Around Them—Now Trump Presides Over Their Destruction](https://www.whatdoesitmean.com/index3055pl.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**