        Nothing Will Ever Be The Same After New Age Of Heroes Arises With Coronavirus <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**Nothing Will Ever Be The Same After New Age Of Heroes Arises With Coronavirus** 

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“The villain has arrived while the hero is evolving.”_**

[Akira Kurosawa](https://en.wikipedia.org/wiki/Akira_Kurosawa) (1910-1998)—Japanese film director and screenwriter regarded as one of the most important and influential filmmakers in the history of cinema.

**Special Report from Sister Ciara**

**My Dearest Friends:**

In the aftermath of **World War II** that saw me being saved by my **Dear Sisters** from the horrors of a ravaged **European Continent**, my journey to taking the simple vows of **Sisterhood** with the **[Sorcha Faal Order](https://www.whatdoesitmean.com/index7381.htm)**, versus the solemn vows taken by **Nuns** in orders such as **[Poor Clares](https://en.wikipedia.org/wiki/Poor_Clares)**, afforded me a blessed lifetime of being able to intellectually straddle the borders of religion and secularism—with my guiding words from **Our Dear Lord** always being “**_For now we see through a glass, darkly; but then face to face: now I know in part; but then shall I know even as also I am known._**” \[**1 Corinthians 13:12**\]

I mention this bit of past about my life because it places into context your understanding my young woman rapture upon seeing, in **1952**, the film **[No Regrets for Our Youth](https://en.wikipedia.org/wiki/No_Regrets_for_Our_Youth)**, that depicted the life of **Empire of Japan** journalist **[Hotsumi Ozaki](https://en.wikipedia.org/wiki/Hotsumi_Ozaki)**—who was the only **Japanese** person to be hanged for treason by the **Japanese** government during **World War II**.

As much as this film told about the life and death of **Hotsumi Ozaki**, it showed to the world even more about its filmmaker **[Akira Kurosawa](https://en.wikipedia.org/wiki/Akira_Kurosawa)**—who today is regarded as one of the most important and influential filmmakers in the history of cinema—and was because of his ability to “**_see through a glass darkly_**” to find the subtle nuances and currents rippling through history—a unique ability lauded by the great **American** filmmaker **[Lawrence Kasdan](https://en.wikipedia.org/wiki/Lawrence_Kasdan)** (**_The Empire Strikes Back, Raiders of the Lost Ark, Return of the Jedi, etc._**), who along with his saying **Kurosawa** [was the greatest director who ever lived](https://stevenpressfield.com/2019/01/kurosawa-on-villains/), said what most distinguished **Kurosawa’s** films was the dynamic: “**_[The villain has arrived while the hero is evolving. That’s what made his films great, the sense of an implacable bad guy encountering a good guy who is alive, capable of changing, who is in fact changing because of and in order to beat back the bad guy and make things safe again.](https://stevenpressfield.com/2019/01/kurosawa-on-villains/)_**”

Now my telling you all of this is so you can better understand why my **Dear Sisters** began writing their “**_see through a glass darkly_**” inspired series best described as a “**_pandemic threat warning_**”—the first of which was reported to you on **18 April 2017** titled **[Reindeer “_Apocalypse_” Prompts Mass Movement Of Russian Troops To Siberia](https://www.whatdoesitmean.com/index2284.htm)**, and continued through to the **18 October 2019** report sent to you titled **[US Prepares After Feared Ancient Virus That Wiped Out Woolly Mammoths Unleashes Global Pandemic](https://www.whatdoesitmean.com/index3016.htm)**—and is a series that runs concurrently with their other one best described as “**_something wicked this way comes_**”—the first of which was reported to you on **23 January 2017** titled **[President Trump Orders FBI To Conduct Massive Raid On CDC Headquarters](https://www.whatdoesitmean.com/index2216.htm)**, and still continues with yesterday’s **25 March 2020** report sent to you titled **[Coronavirus War Leader Trump Throws Afghanistan To Wolves To Protect His Own “_Zero Risk_” Pampered Herd](https://www.whatdoesitmean.com/index3167.htm)**.

For those of you who have diligently followed my **Dear Sisters’** “**_pandemic threat warning_**” and “**_something wicked this way comes_**” series over these past three years, your grateful emails over these past few weeks describing how prepared you were for the coronavirus pandemic are as welcome as they are uplifting—as our sole mission has always been to see you prepared for whatever dangers may face you and your families—no matter how much harm comes to us for telling you the truth.  

For those of you who didn’t follow these series meant to protect you, from either you not knowing about them until too late, or scoffing at them as you’re supposed to do, your world over these past few months was guided by “**_mainstream_**” news sources telling you the exact opposite of what my **Dear Sisters** have been warning you about for the past three years—and makes it no surprise you were taken unaware and unprepared by this coronavirus pandemic because you were believing “**_mainstream_**” media published lies such as:

**[Who Says It’s Not Safe to Travel to China? The Coronavirus Travel Ban Is Unjust And Doesn’t Work Anyway.](https://www.nytimes.com/2020/02/05/opinion/china-travel-coronavirus.html)** **– published by The New York Times**

**[Why We Should Be Wary Of An Aggressive Government Response To Coronavirus](https://www.washingtonpost.com/outlook/2020/02/03/why-we-should-be-wary-an-aggressive-government-response-coronavirus/)** **– published by The Washington Post**

**[In Europe, Fear Spreads Faster Than the Coronavirus Itself](https://www.nytimes.com/2020/02/18/world/europe/coronavirus-stigma-europe.html)** **– published by The** **New York Times**

**[How Our Brains Make Coronavirus Seem Scarier Than It Is](https://www.washingtonpost.com/outlook/2020/01/31/how-our-brains-make-coronavirus-seem-scarier-than-it-is/)** **– published by The** **Washington Post**

**[What's Spreading Faster Than Coronavirus In The US? Racist Assaults And Ignorant Attacks Against Asians](https://www.cnn.com/2020/02/20/us/coronavirus-racist-attacks-against-asian-americans/)** **– published by CNN**

**[Get A Grippe, America. The Flu Is A Much Bigger Threat Than Coronavirus](https://www.washingtonpost.com/health/time-for-a-reality-check-america-the-flu-is-a-much-bigger-threat-than-coronavirus-for-now/2020/01/31/46a15166-4444-11ea-b5fc-eefa848cde99_story.html)** **– published by The** **Washington Post**

**[Is This Going To Be A Deadly Pandemic? No.](https://www.thewrap.com/vox-deletes-january-tweet-coronavirus-not-deadly/)** **– Vox Media Tweet**

**All of which were believed by top New York City Doctor Mark Levine who Tweeted out on 9 February “****_[In powerful show of defiance of #coronavirusscare, huge crowds gathering in NYC's Chinatown for ceremony ahead of annual #lunarnewyear parade. chance of “be strong wuhan!” if you are staying away, you are missing out.](https://www.thegatewaypundit.com/2020/03/nyc-health-commissioner-oxiris-barbot-mocked-coronavirus-fears-in-february-today-nyc-leads-nation-in-most-cases-and-most-deaths/)_****”—and New York City Health Commissioner Oxiris Barbot, who also on 9 February, Tweeted out “****_[Today our city is celebrating the #lunarnewyear parade in chinatown, a beautiful cultural tradition with a rich history in our city. I want to remind everyone to enjoy the parade and not change any plans due to misinformation spreading about #coronavirus](https://www.thegatewaypundit.com/2020/03/nyc-health-commissioner-oxiris-barbot-mocked-coronavirus-fears-in-february-today-nyc-leads-nation-in-most-cases-and-most-deaths/)_****”—and explains to you why** **[New York City is now the epicenter of the coronavirus pandemic in America](https://www.npr.org/2020/03/24/820610818/new-york-city-u-s-epicenter-braces-for-peak)****.**

![](vox21.jpg)

![](vox22.jpg)

In what I’ve just described and factually demonstrated to you, you well know that while my **Dear Sisters** remain under unrelenting attacks for telling you the truth, the “**_mainstream_**” media is still being celebrated for telling its lies—which means **YOU** have to decide whom you’re going to put your trust in and support—a choice everyone must make as the world that existed before the coronavirus pandemic is gone—but what replaces it has yet to be determined.

A determination to be made in a world today where “**_the villain has arrived while the hero is evolving_**”—and with **YOU** hopefully knowing that “**_these villains who have now arrived at what they’re ever going to be, which is their greatest flaw_**”—are opposed to the “**_heroes who evolve and are open to change and growth_**”—and is exactly as the greatest director who ever lived **Akira Kurosawa** masterfully displayed in every film he ever made.

Now I wish I could tell you that it’s easy to “**_see through a glass, darkly_**” in order to discover the nuanced and subtle ripples in history like my **Dear Sisters** do daily in order to truthfully forewarn you about what may be coming to harm you and your families, but I can’t—as it takes years and decades of silent devotion and study for one to even begin to be able to detect these ripples in the maelstrom of world events—though when looked at in the context that even those who can do so are mere grains of sand compared to the all-knowing **God**—shows you why even they lean upon **Him** for greater wisdom—an actual “**_Ladder of True Things_**” that sees **God** being the top rung, and descends in “**_rungs of knowledge_**” of varying abilities to those standing in hopelessness wondering what to do.

So in finishing my words to you today my **Dearest Friends**, and as always when we meet, my most fervent plea is for **YOU** to grab onto the “**_Ladder of True Things_**” and begin aiding those of us who are fighting for you—and as **Our Lord** has commanded everyone in the **Book of Proverbs**, **Chapter 18**, **Verse 16**, this rung can be grabbed on by **YOU** remembering the truth that “**_A gift opens the way and ushers the giver into the presence of the great._**”—that I pray your heart leads you to bless us with right now—as even if you don’t realize it yet, I know that you are a **HERO**!

With God,

Sister Ciara

Dublin, Ireland

26 March 2020

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/21bKL5?ref=ab_48h7S4_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s March, 2020/April, 2020 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 96”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/index032620.htm)

[](https://www.whatdoesitmean.com/indexnews.htm)