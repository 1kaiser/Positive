        President Trump Now Protected By Powerful US Army Force Capable Of Leveling Washington D.C.  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Trump Convenes Emergency Meeting, Mobilizes NATO, After ANTIFA Leftists Confirmed Training In Venezuela](https://www.whatdoesitmean.com/index2361.htm)**

**[Google Backed ANTIFA Attempt To Assassinate President Trump Captured On Video](https://www.whatdoesitmean.com/index2372.htm)**

**[Virginia Prepares To Unleash “_Red Guard Forces_” As Prisons Expanded To Hold Citizens Refusing To Give Up Guns](https://www.whatdoesitmean.com/index3081.htm)**

**[ANTIFA Terrorists Cripple Canadian Rail System As Train Derailment Attacks Begin Striking America](https://www.whatdoesitmean.com/index3136.htm)**

**[Socialists Declare American Revolution As Low-Intensity Conflict Erupts In United States](https://www.whatdoesitmean.com/index3230.htm)**

**[Russia Designates George Floyd “_Incident_” Psyop Operation—Warns CIA Is Main Target](https://www.whatdoesitmean.com/index3231.htm)**

**[NASA Issues Incoming Asteroid Alert As Combat Warplanes Fill Night Skies Of America](https://www.whatdoesitmean.com/index3232.htm)**

**[Feared Zaslon Assassins Deployed To America With Orders To Wipe Out ANTIFA Leadership](https://www.whatdoesitmean.com/index3233.htm)**

**[Communist China Throws Full Support Behind “_Prairie Fire_” Riots Destroying America They Call “_Beautiful_”](https://www.whatdoesitmean.com/index3234.htm)**

June 5, 2020

**President Trump Now Protected By Powerful US Army Force Capable Of Leveling Washington D.C.**

By: Sorcha Faal, and as reported to her Western Subscribers

An astonishing new **Ministry of Defense** ([MoD](https://eng.mil.ru/)) report circulating in the **Kremlin** today noting a **[McClatchy News Service](https://en.wikipedia.org/wiki/McClatchy)** article from **4 June** claiming: “**_[The nation’s capital is bracing for the largest protest yet on Saturday since the death of George Floyd, expanding a massive fenced perimeter around the White House, even as the Pentagon sent home hundreds of active duty troops positioned outside the city](https://www.mcclatchydc.com/news/politics-government/white-house/article243279711.html)_**”, says the blatant lies told in this article about **Pentagon** troop movements in the **Washington D.C.** region strongly suggest military censorship activities have now been put into place in the **United States**—an assessment based on the fact that when **President Donald Trump** [walked from the **White House** to the historic **St. John’s** **Church** during the early evening of **Monday 1 June**](https://www.axios.com/trump-st-johns-white-house-protests-953044b8-fab9-425c-94bf-ebcd81f929c7.html), photographed walking behind him were two supposed **Secret Service** agent snipers, **[one of whom was carrying a unique US Army desert camouflaged sniper rifle based on Accuracy International's bolt-action AX chassis system](https://www.thedrive.com/the-war-zone/33818/about-that-huge-rifle-the-secret-service-sniper-was-carrying-during-trumps-photo-op-walk)**—which was immediately followed by **US** news reports saying: “**_[Completely unmarked officers in riot gear holding protesters blocks away from the White House. No badges. No insignias. No name tags. Nothing. Refused to tell us who they’re with](https://www.rt.com/usa/490776-unmarked-officers-dc-protests-floyd/)_**”—the identification of whom, though, **MoD** intelligence analysts quickly identified as them all belonging to the **Intelligence Production Section** ([IPS](https://fas.org/irp/doddir/army/fm34-35/Ch2.htm)) and **Military Intelligence Company** (**[MI](https://fas.org/irp/doddir/army/fm34-35/Ch2.htm)**) of the **[278th Armored Cavalry Regiment](https://en.wikipedia.org/wiki/278th_Armored_Cavalry_Regiment)**—a **US Army** military regiment known as the “**_[Tennessee Cavalry](https://www.tn.gov/military/who-we-are/army-guard/278th-armored-cavalry-regiment.html)_**”, which is the only armored cavalry regiment in the **Army National Guard** and headquartered in **Knoxville-Tennessee**—whose only other counterpart in the **US Army** is the **[11th Armored Cavalry Regiment](https://en.wikipedia.org/wiki/11th_Armored_Cavalry_Regiment)** garrisoned at **Fort Irwin-California**—and most important to know about is a “**_Tennessee Cavalry_**” armored regiment comprised of **[up to 2,000 combat forces](https://secondworldwar.co.uk/index.php/army-sizes-a-ranks/86-army-units-a-sizes)**, though with logistical support from other **US Army** units (**_medical, transportation, food service, etc._**) its numbers can rapidly rise to over **10,000**—whose combat capability designated by the **MoD** is rated as “**_City Levelers_**” due to them being able to quickly surround and pound into submission the enemy forces they’re deployed against with their fast moving and overwhelming heavy armored tank, combat vehicles and artillery firepower expertise—and though not having any training in civilian crowd control, nevertheless saw **President Trump** **[activating them to full combat status on the afternoon of Monday 1 June and ordering them to immediately deploy to Washington D.C. for reasons still unknown](https://www.wbir.com/article/news/tennessee-army-national-guard-stationed-in-knoxville-has-been-mobilized-to-dc-authorities-say/51-e0193d35-fddb-4809-bff1-40570c8665b7)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](tng25.jpg)

**On 1 June 2020, President Donald Trump (_above_) makes defiant walk from White House to historic St. John’s Church that was attacked the night before by socialist revolutionaries…**

![](tng24.jpg)

**…followed by supposed Secret Service snipers, one of whom was carrying a desert camouflaged US Army sniper rifle (_above, red arrow pointing at_)…**

![](tng23.jpg)

**…that was followed by unmarked military forces (_above_) surrounding the White House…**

![](tng21.jpg)

**…whom Russian military experts identified as being elite intelligence and scout soliders belonging to the 278th Armored Cavalry Regiment (_stock photo above_)…**

![](tng22.jpg)

**…otherwise known as the Tennessee Cavalry (_unit patch above_) that President Trump ordered deployed to Washington D.C. just prior to his making his defiant walk.**

According to this report, based on the widely used “**_[Threat Matrix](https://en.wikipedia.org/wiki/Threat_Matrix_(database))_**” database system developed by **Pakistani** government and military scientists to evaluate perceived external and internal threats, critical information inputs to assess the current conflict environment status currently existing in the **United States** now include **President Trump** having yesterday posted a letter written by his former **White House** attorney **John Dowd** “**_[directly calling protesters terrorists](https://www.politico.com/news/2020/06/04/trump-lawyer-protesters-terrorist-letter-302552)_**”—that was followed by **United States Attorney General William Barr** holding a press conference where he stated “**_[We have evidence that Antifa and other similar extremist groups, as well as actors of a variety of different political persuasions, have been involved in instigating and participating in the violent activity](https://www.redstate.com/nick-arama/2020/06/04/bill-barr-confirms-antifa-involvement-in-instigating-riots-but-he-has-two-other-very-important-words/)_**”, who then ominously elevated this threat by adding the words: “**_[We are also seeing foreign actors playing all sides to exacerbate the violence](https://www.redstate.com/nick-arama/2020/06/04/bill-barr-confirms-antifa-involvement-in-instigating-riots-but-he-has-two-other-very-important-words/)_**”—an elevation of this crisis to that of one taking on international national security war time dimensions, whose immediate preceding events include:

**On 29 May 2020****—[around 7:00 pm local Washington D.C. time](https://www.dailymail.co.uk/news/article-8385895/Trump-rushed-White-House-bunker-Melania-Barron-protesters-crossed-barricade.html)—President Trump, First Lady Melania Trump, and their son Barron [were rushed to a secure bunker after protesters breached barricades near the White House](https://www.businessinsider.com/trump-rushed-to-bunker-after-protesters-breached-barricades-white-house-2020-6).**

**On 31 May 2020-** **[the US Justice Department began deploying members of the US Marshals Service and agents from the Drug Enforcement Administration to supplement National Guard troops outside the White House](https://www.snopes.com/ap/2020/05/31/president-trump-rushed-to-underground-bunker/).**

**On 1 June 2020****—[around 3:30 pm local Washington D.C. time](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)—[the 82nd Airborne Division Immediate Reaction Force leaves Ft. Bragg-North Carolina for Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 1 June 2020—****[around 4:00 pm local Washington D.C. time](https://www.wbir.com/article/news/tennessee-army-national-guard-stationed-in-knoxville-has-been-mobilized-to-dc-authorities-say/51-e0193d35-fddb-4809-bff1-40570c8665b7)—President Trump [ordered the immediate deployment to Washington D.C. of the 278th Armored Cavalry Regiment](https://www.wbir.com/article/news/tennessee-army-national-guard-stationed-in-knoxville-has-been-mobilized-to-dc-authorities-say/51-e0193d35-fddb-4809-bff1-40570c8665b7).**

**On 1 June 2020****—around 5:30 pm local Washington D.C. time—President Trump [makes defiant walk from White House to historic St. John’s Church attacked the previous night by socialist revolutionaries](https://www.axios.com/trump-st-johns-white-house-protests-953044b8-fab9-425c-94bf-ebcd81f929c7.html).**

**On 1 June 2020****—around 11:00 pm local Washington D.C. time—[US military helicopters begin low-level flights over Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 2 June 2020****—early morning hours before dawn local Washington D.C. time—[a US Air Force C-17 cargo warplane from Fort Bragg-North Carolina lands at Joint Base Andrews outside of Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 2 June 2020****—early morning hours before dawn local Washington D.C. time—[five more US Air Force C-17 cargo warplanes from Fort Bragg-North Carolina and McGuire Air Base-New Jersey are inbound to Joint Base Andrews outside Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 2 June 2020****—early morning house before dawn local Washington D.C. time—[multiple US Air Force C-130J and C-17A cargo warplanes from Fort Riley-Kansas, Fort Drum-New York and Fort Bragg-North Carolina begin arriving at Joint Base Andrews outside Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 2 June 2020—****early morning hours after dawn local Washington D.C. time—[Nuclear Detection Helicopter designed to map radiation levels after an accident, disaster, or dirty bomb attack begins flying missions over Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**

**On 2 June 2020****—throughout the day—[other assets involved in overwatch missions over Washington D.C., to include US Customs and Border Protection Dash-8 turboprops, which are heavily modified with advanced sensors, begin flying missions out of Reagan National Airport—with a Cessna Citation registered to the National Aircraft Leasing Corporation, but linked to the FBI, also begins orbiting over the D.C. area](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)—[with other fixed-wing aircraft seen flying high overhead, as well, some of which did not have their transponders on](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force).**

![](tng26.jpg)

Not being aware of these grave preparations being made for war, this report notes, are the **American** people—none of whom know the significance of the **Executive Order** signed by **President Trump** just days before this crisis accelerated, on **28 May 2020**, titled “**[Executive Order on Preventing Online Censorship](https://www.whitehouse.gov/presidential-actions/executive-order-preventing-online-censorship/)**”—the most significant part of which stated:

**_At the same time online platforms are invoking inconsistent, irrational, and groundless justifications to censor or otherwise restrict Americans’ speech here at home,_** **_several online platforms are profiting from and promoting the aggression and disinformation spread by foreign governments like China_****_._** 

**_One United States company, for example, created a search engine for the Chinese Communist Party that would have blacklisted searches for “human rights,” hid data unfavorable to the Chinese Communist Party, and tracked users determined appropriate for surveillance._**

 **_It also established research partnerships in China that provide direct benefits to the Chinese military_****_._** 

**_Other companies have accepted advertisements paid for by the Chinese government that spread false information about China’s mass imprisonment of religious minorities, thereby enabling these abuses of human rights._** 

**_They have also amplified China’s propaganda abroad_****_, including by allowing Chinese government officials to use their platforms to spread misinformation regarding the origins of the COVID-19 pandemic, and to undermine pro-democracy protests in Hong Kong._**

![](tng27.png)

For one to grasp the full significance of this **Executive Order**, this report explains, they should known that “**_online platforms_**” include every mainstream media outlet in the **United States**, not just those run by social media tech giants—and by asserting that they “**_are profiting from and promoting the aggression and disinformation spread by foreign governments_**”, specifically to “**_provide direct benefits to the Chinese military_**”—and when joined by **Attorney General Barr** now asserting that “**_We are also seeing foreign actors playing all sides to exacerbate the violence_**”—places this extraordinary action made by **President Trump** firmly within the confines of the **[Department of Defense Law of War Manual](https://dod.defense.gov/Portals/1/Documents/pubs/DoD%20Law%20of%20War%20Manual%20-%20June%202015%20Updated%20Dec%202016.pdf?ver=2016-12-13-172036-190)**—an over **1,200-page** legal document that says “**_journalists may not directly participate in hostilities without also losing civilian status_**”—states: “**_A person may only be considered a spy when, (1) acting clandestinely or under false pretenses, (2) in the zone of operations of a belligerent, (3) he or she obtains, or endeavors to obtain, information, (4) with the intention of communicating it to the hostile party_**”—and strictly forbids under penalty of treason anyone from “**_providing or relaying information of immediate use in combat operations_**”.

With “**_combat operations_**” currently underway in the **United States** itself, this report details, any **American** journalist deciding to “**_participate in hostilities_**” by reporting on **US** military troop movements and/or actions risks “**_losing civilian status_**”—and who would further be considered as spies whose treasonous crime would be “**_communicating it to the hostile party_**”—most particularly because “**_the zone of operations of a belligerent_**” is in **America** itself, where socialist revolutionaries are attempting to overthrow the government—with the truth and reality of this being known to many top former **US** military leaders, who are now crying out alarms of what they know is about to happen, though being very circumspect in what they say, lest they be branded as traitors, too—and whom include:

**_Former Obama-Clinton Regime top military official Joint Chiefs Chairman Admiral Mike Mullins—who in his just published screed titled “_****_[I Cannot Remain Silent](https://www.theatlantic.com/ideas/archive/2020/06/american-cities-are-not-battlespaces/612553/)_****_” says: “_****_[Our fellow citizens are not the enemy, and must never become so](https://www.theatlantic.com/ideas/archive/2020/06/american-cities-are-not-battlespaces/612553/)_****_”._**

**_Former Defense Secretary of President Trump, and top Obama Clinton Regime endless war military leader General James Mattis_** **_[openly denouncing Trump and describing him as a threat to the constitution](https://www.theatlantic.com/politics/archive/2020/06/james-mattis-denounces-trump-protests-militarization/612640/)_****_._**

**_Former White House chief of staff for President Trump, and another top Obama Clinton Regime endless war military leader, General John Kelly_** **_[calling Trump “nasty” and “confused”](https://www.dailymail.co.uk/news/article-8389855/Former-chief-staff-John-Kelly-calls-Trump-nasty-confused-attack-Jim-Mattis.html)_****_._**

![](tng28.png)

To fully evaluate the worthiness of the attacks being made on **President Trump** by **Obama-Clinton Regime** endless war leaders **Admiral Mullins**, **General Mattis** and **General Kelly**, this report concludes, all one needs to know is that all three of them willingly took their marching orders to wage war on the world’s **Muslim** peoples from top **[Obama-Clinton Regime Department of Defense intelligence official Salmah Rizvi](https://islamicscholarshipfund.org/recipients/salmah-rizvi/)**—**[the same Salmah Rizvi that this week posted the $250,000 bail for her “_best friend_” Urooj Rahman, who was arrested for throwing a lit Molotov cocktail through the window of a New York City police vehicle](https://freebeacon.com/latest-news/former-obama-intelligence-official-helps-secure-bail-for-molotov-cocktail-throwing-nyc-lawyer/)**—**[with further evidence presented by prosecutors including images of Rahman holding a Molotov cocktail in the passenger seat of a van that was later found to be full of the necessary materials for making the explosive devices](https://freebeacon.com/latest-news/former-obama-intelligence-official-helps-secure-bail-for-molotov-cocktail-throwing-nyc-lawyer/)**—making it no wonder why top **Republican Party US Senator Tom Cotton** exploded in righteous anger against all of these socialist elites in an article he wrote for the **New York Times** titled “**_[Send In the Troops](https://www.nytimes.com/2020/06/03/opinion/tom-cotton-protests-military.html)_**” begging **President Trump** to use the military to restore order in **America**—and also makes it no wonder why the **New York Times**, after publishing this article, then caved in and bowed down to these elite socialists while crying “**_[it did not meet our standards](https://www.rt.com/usa/490838-times-caves-cotton-oped/)_**”—but are “**_standards_**” no one in the world knows, because the only places in **America** needing to be saved from chaos and rioting are the **Democrat Party** stronghold **States** and cities these socialists have ruled over for decades—where when one **_really_** notices the thousands of protestors marching through them, none of them are carrying protest signs saying anything bad about **President Trump**—which makes perfect sense when noticing a few hours ago that **[Trump’s amazing economy, that refuses to die, just posted the largest jobs gain ever seen in American history](https://www.reuters.com/article/us-usa-economy/u-s-labor-market-unexpectedly-improves-but-recovery-expected-to-be-a-slog-idUSKBN23C0E9)**.

![](tng29.jpg)

![](tng30.jpg)

![](tng31.jpg)

June 5, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Global Battlefields Littered With Coronavirus Dead—But Who’s Winning War?](https://www.whatdoesitmean.com/index3229pl.htm)**

**[All That's Left Now Is War—What Kind And How Long Are The Questions To Ask](https://www.whatdoesitmean.com/index3229.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**