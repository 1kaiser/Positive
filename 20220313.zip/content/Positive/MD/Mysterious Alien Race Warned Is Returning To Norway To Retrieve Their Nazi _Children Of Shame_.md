        Mysterious Alien Race Warned Is Returning To Norway To Retrieve Their Nazi “Children Of Shame”  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

September 8, 2019

**Mysterious Alien Race Warned Is Returning To Norway To Retrieve Their Nazi “_Children Of Shame_”** 

By: Sorcha Faal, and as reported to her Western Subscribers

An absolutely mind-bending new **Ministry of Defense** ([MoD](http://eng.mil.ru/)) report circulating in the **Kremlin** today discussing findings determined by **System of Forward-looking Military Research and Development** ([SFLMRD](http://eng.mil.ru/en/science/sflmrd/about.htm)) astrophysicists regarding this **[past week’s massive geomagnetic storm that struck our planet](https://www.swpc.noaa.gov/news/g1-watch-31-aug-g2-watch-1-sep-2019-utc-days)**, states that the place most adversely affected by this event was the **Nordic** country **[Kingdom of Norway](https://en.wikipedia.org/wiki/Norway)**—where following this space blast, **[its ancient and iconic “_Little Man_” mountain top collapsed and fell into ruin](https://www.nytimes.com/2019/09/07/world/europe/norway-mountain-little-man.html)**—while at the same a **[mysterious disease has begun killing its nation’s dogs](https://www.independent.co.uk/news/world/europe/dog-disease-norway-death-toll-vomiting-diarrhoea-sweden-a9095846.html)**—both of which were followed by the global energy giant **[Exxon suddenly ending its over a century long partnership with Norway and selling off all of its assets there](https://finance.yahoo.com/news/exclusive-exxon-agrees-sell-norway-154857552.html)**—and whose fears of remaining there accelerated this past **April-2019** when “**_[alien lights exploded across the skies of Norway](https://bgr.com/2019/04/09/alien-lights-norway-nasa-sounding-rockets/)_**”—an event which **NASA** said they were to blame for—but that mirrored the “**_[Norwegian Spiral](https://rationalwiki.org/wiki/Norwegian_Spiral)_**” event in **December-2009** that shocked the world, and **NASA** falsely blamed on **Russia**—all of which, however, has its truest mystery about centering around the “**_[Lebensborn](https://en.wikipedia.org/wiki/Lebensborn)_**”—who are the “**_[Children Of Shame](https://www.dw.com/en/children-of-shame-norways-dark-secret/a-336916-0)_**” bred by the **Nazi Germans** who remain today “**_[Norway’s Dark Secret](https://www.dw.com/en/children-of-shame-norways-dark-secret/a-336916-0)_**”—and whom **Nazi** occult writings said would one day be retrieved by their true “**_[Nordic Alien](https://en.wikipedia.org/wiki/Nordic_aliens)_**” spacefaring “**_parents_**”.  \[**Note:** Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](leben1.jpg)

**Elite ancient occult-trained Nazi Germany officers held mass marriage ceremonies with young Norwegian women (_above_) to breed _“Star Children_” whose spacefaring Nordic Alien true “_parents_” would then come to retrieve…**

![](leben2.jpg)

**…by their opening a “_hidden portal_” over Norway such as appeared in April-2019 (_above_)…**

![](leben3.jpg)

**…that was shown to them in December-2009 when a massive spiral (_above_) was beamed from Earth into the skies of Norway.**

According to this report, the greatest deception in history foisted upon the **Western** peoples by their leaders about **[World War II](https://en.wikipedia.org/wiki/World_War_II)** was that it was conflict only involving the nations of our world—a provable lie as this global war was, in fact, an **extraterrestrial-interdimensional** conflict—and by its ending in **1945**, saw our planet’s skies being filled with alien spacecraft that military pilots from all nations began calling “**_[Foo Fighters](https://en.wikipedia.org/wiki/Foo_fighter)_**”—a term which since has evolved into these alien crafts being called “**_[unidentified flying objects](https://en.wikipedia.org/wiki/Unidentified_flying_object)_**”—or more simply, **UFO’s**—which even today **[the fastest US Navy military jets are unable to keep up with](https://www.nytimes.com/2019/05/26/us/politics/ufo-sightings-navy-pilots.html)**—and explains why **[top US Congressman Mark Walker reported this past week that the US Navy is now hiding all of its UFO evidence](https://www.politico.com/story/2019/09/06/navy-withholding-ufo-sightings-1698396)**.  

![](leben4.jpg)

**World War II military pilots began photographing alien spacecraft (_above_) they called “_Foo Fighters_” that were flooding into our world’s skies…**

![](leben5.jpg)

**…and continues today with US Navy pilots continuing to capture them on video (_above_).**

Though **Western** history books continue to falsely claim that the extraterrestrial-interdimensional **World War II** was begun in **1939** when **Nazi Germany** invaded **Poland**, this report continues, the fearful truth is that it was begun in **1912** even before **[World War I](https://en.wikipedia.org/wiki/World_War_I)** started two years later in **1914**—and was when one of the most consequential books in human history was published titled “**_[Welteislehre](https://en.wikipedia.org/wiki/Welteislehre)_**”—alternatively known as “**_World Ice Theory_**”—“**_World Ice Doctrine_**”—“**_Glazial-Kosmogonie_**”—and “**_Glacial Cosmogony_**”—and referred to by one of its most devoted followers **Adolph Hitler** as simply “**_[WEL](https://en.wikipedia.org/wiki/Welteislehre#In_the_Third_Reich)_**”.

Based on a “**_vision_**” received by its author **[Hanns Hörbiger](https://en.wikipedia.org/wiki/Hanns_H%C3%B6rbiger)**, this report details, the book “**_Welteislehre_**” created the entire “**_[mystical occult foundation](https://www.spectator.co.uk/2017/06/did-hitlers-obsession-with-the-occult-lose-him-the-war/)_**” on which **Nazi Germany** was built upon—and some of whose beliefs were:

**_The white “Aryan” man was not descended from the apes, as were other inferior races, but rather came from “divine sperma” brought to earth by meteors._**

**_These developed into the godlike Supermen of the ancient civilization of Atlantis-Thule which employed parapsychology and mystical electricity “like Thor’s hammer”._**

**_Atlantis was destroyed by “icy moons” crashing into earth, and_** **_refugee Supermen established Buddhism and Hinduism in Tibet and the Himalayas and Shintoism in Japan_****_._**

**_Jesus Christ was a White “Aryan” of Atlantean descent, as were the Knights Templar and the Cathars, who held the mysteries of ancient Thule in the Holy Grail._**

**_The white Supermen were locked in a struggle for mastery with the ape-like “Tschandala” or “monstrous humanoids” — Jews, Slavs, blacks and “mongrel breeds”._**

![](leben7.jpg)

Following the “**_Welteislehre_**” declaring that one of our world’s most ancient symbols called the “**_[Swastika](https://en.wikipedia.org/wiki/Swastika)_**” was the symbol used by these “**_Supermen_**” hiding in **Tibet**, this report notes, **Nazi German** leader **Adolph Hitler** adopted it as the sole national flag of his nation on **[15 September 1935](https://en.wikipedia.org/wiki/Swastika#Use_in_Nazism)**—an action one might think would be bizarre for a **Western Northern European** nation to do in making its national symbol one rooted in ancient **Eastern** mysticism—but became understandable **[in 1938 when elite Nazi German officers and troops penetrated the tallest mountains in the world to enter Tibet](https://tricycle.org/magazine/hitler-and-himalayas-ss-mission-tibet-1938-39/)**—and whose “**_discoveries_**” there about these “**_Supermen_**” were **[shared with the Empire of Japan by German Count Karlfried Dürckheim](https://apjjf.org/2014/12/3/Brian-Victoria/4063/article.html)**.

Deemed by these **Nazi Germans** as their nation’s “**_to be protected at all costs secrets_**” about what they discovered in **Tibet**, this report further details, during the closing days of **World War II** it saw their nation **[undergoing one of the largest mass suicides ever recorded in human history](https://en.wikipedia.org/wiki/Mass_suicides_in_1945_Nazi_Germany)**—with the **Nazi** occult training town of **[Demmin-Germany seeing 1,000 of its people committing suicide in just 72-hours](https://timeline.com/demmin-nazi-mass-suicide-44c6caf76727)**—and included **[hundreds of Tibetan Buddhist monks in Nazi German SS uniforms who committed mass suicide in Berlin](http://www.chinabuddhismencyclopedia.com/en/index.php/Tibet_Nazi_Connection)**—just blocks away from **Adolf Hitler’s** bunker where he, too, was [reported to have committed suicide](https://en.wikipedia.org/wiki/Conspiracy_theories_about_Adolf_Hitler%27s_death).

![](leben10.jpg)

**Members of the German SS expedition crossed the Tibet border in December of 1938 and arrived in Lhasa approximately one month later.  In this photograph, members of the expedition gather at a makeshift camp during the journey. Inner circle, from left to right: Nazi German occult experts Krause, Wienert, Beger, Geer and Schaefer.**

Critical to note about the **Nazi German** ancient occult discoveries in **Tibet**, this report continues, were that they were also being frantically sought after by the **United States**—an effort begun in **1934** by **President Franklin Roosevelt’s** newly appointed **Secretary of Agriculture [Henry Wallace](https://en.wikipedia.org/wiki/Henry_A._Wallace)**—who secretly funded with **American** taxpayer money the exiled **Russian** “**_[mystic](https://www.americanheritage.com/new-deal-and-guru)_**” **[Nicholas Roerich](https://en.wikipedia.org/wiki/Nicholas_Roerich)** who began numerous expeditions into **Tibet**—the true facts of which remain some of the closest guarded secrets the **Americans** have—but are believed to have failed as after the outbreak of **World War II**, the mystic **[Roerich fled to India to live with its spiritual leader Gandhi](https://en.wikipedia.org/wiki/Nicholas_Roerich#Later_life_and_World_War_II)**—near the end of the war saw **Roosevelt** throwing his then **Vice President Wallace** off the ticket for re-election—and even more mysteriously, saw **Roosevelt** declaring war on **Nazi Germany**—followed by his a few months later creating for himself a secret mountain fortress outside of **Washington D.C.** he named “**_[Shangri-La](https://en.wikipedia.org/wiki/Shangri-La)_**”—which is the name of a fictional **Himalayan** paradise in **Tibet**—but today is known as “**_[Camp David](https://en.wikipedia.org/wiki/Camp_David)_**”.      

![](leben9.jpg)

**President Franklin Roosevelt declares war on Nazi Germany, then creates secret mountain fortress he named Shangri-La (_above_).**

With both **Nazi Germany** and the **United States** having followed “**_Welteislehre_**” vision book guidance to discover the ancient occult “**_Superman_**” secrets hidden in the world’s highest and most mysterious mountains in **Tibet**, this report concludes, neither of them ever shared these secrets with the **Slavic Russian** peoples whom they labeled as “**_monstrous humanoids_**” along with black and **Jewish** peoples—a labeling that continues today as evidenced by **America’s** outright hatred of **Russia** and its **Christian** peoples—but all of whom should be watching what happens next in **Norway**—as its **[HAARP Facility EISCAT obviously sent the “_spiral message_” in 2009](https://redice.tv/news/was-norway-s-haarp-facility-eiscat-responsible-for-the-norway-spiral)** to identify a “**_[hidden portal in Earth’s magnetic field](https://www.nasa.gov/mission_pages/sunearth/news/mag-portals.html)_**”—this past **April-2019**, saw **[this “_hidden portal_” being opened from the “_other side_”](https://bgr.com/2019/04/09/alien-lights-norway-nasa-sounding-rockets/)**—**[in 2014 saw it being shockingly revealed that the US has been cooperating with the same Nordic Aliens the Nazis once did](https://en.farsnews.com/newstext.aspx?nn=13921021000393)**—and whose true propose behind is to return to these **Nordic Aliens** the “**_Lebensborn_**” children whom the **Nazis** bred using the ancient occult knowledge they discovered in **Tibet**—as well as all of their offspring. 

[![](leben11.jpg)](https://www.youtube.com/watch?v=Pg6VTzacb9I)

September 8, 2019 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[“_Ghost Warrior_” Wants Trump Assassinated—Hints It’s Coming Soon](http://whatdoesitmean.com/index2968pl.htm)**

**[America Gets Mad Dog Warning—But Is Anyone Listening?](https://www.whatdoesitmean.com/index2968.htm)**

**[Truth Makes Last Stand In America—Looks For Allies To Defend It](https://www.whatdoesitmean.com/index2941.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**