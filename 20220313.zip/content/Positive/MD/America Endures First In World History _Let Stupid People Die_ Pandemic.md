        America Endures First In World History “Let Stupid People Die” Pandemic <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

Note: This is an urgent private letter intended for the sole and exclusive use of the patron/donors to the Sisters of Sorcha Faal.

**America** **Endures First In World History “_Let Stupid People Die_” Pandemic**

27 March 2020

Hello Folks,

For those of you haven’t yet read **[Sister Ciara’s monthly letter](https://www.whatdoesitmean.com/index3168.htm)** yet, I strongly suggest you do—and in my letter to you today, I’m going to focus on these words she wrote: “**_the ability to see through a glass darkly to find the subtle nuances and currents rippling through history_**”—but before I can, and in order for you to really understand what’s going on in your world, I’ve got to tell you about a place in **America** called the **[Groton School](https://www.groton.org/)**.

And I’m not picking on the **Groton School**, rather I’m using it as an example of the hundreds of elite boarding schools throughout **America**, where unless you’re, at least, a multi-millionaire, your children and grandchildren will never pass through the gilded gates of.

Now specifically, the **Groton School** is a private **Episcopal** college preparatory boarding school located in **Groton**, **Massachusetts**, **United States**, that enrolls about **380** boys and girls, from the eighth through twelfth grades—who are children ranging in ages from about **13** to **18**—and I direct your attention to the curriculum they’re taught:

**[Classics](https://www.groton.org/curriculum-detail?fromId=250870&LevelNum=951&DepartmentId=16957)**—_Groton encourages the study of Latin and Greek because of particular benefits it offers in the development of language skills and the perspective it offers into our culture in a broad sense. Latin and Greek are the basis for several World Languages and can be useful aids in learning them._

**[English](https://www.groton.org/curriculum-detail?fromId=250870&LevelNum=951&DepartmentId=16964)**—_The_ _English Department seeks to immerse students in the world of writing, the students’ own as well as that of great literature._

**[Religious Studies and Philosophy](https://www.groton.org/curriculum-detail?fromId=250870&LevelNum=951&DepartmentId=16972)**—_Religious literacy is a central component of preparatory education in an increasingly connected global society._

**[History and Social Science](https://www.groton.org/curriculum-detail?fromId=250870&LevelNum=951&DepartmentId=16966)**—_The_ _History and Social Science Department strives to provide students with an understanding of past events and the differing viewpoints of those who participated in them._

**[Mathematics and Computer Science](https://www.groton.org/curriculum-detail?fromId=250870&LevelNum=951&DepartmentId=16967)**—_The_ _goal of the Groton School math and computer science program is to provide students with quantitative information, problem solving techniques, and the analytical skills required by the changing landscape of the twenty-first century._

![](grt21.jpg)

I’d like to now acquaint you with **Stephen Guise**, a product of the **American** public school system who, in **2010**, graduated from college with a **Bachelor of Science/Bachelor of Arts** (B.S.B.A.) degree in finance, and after graduating began a year long search for employment, and in his own words, “**_[finally landed a sales floor job at Lowe’s for $10 an hour](https://medium.com/the-mission/how-school-trains-us-to-fail-in-the-real-world-a67f6ed69be5)_**”.

I first learned about **Mr. Guise** in **October-2017** after reading his damning article **[How School Trains Us To Fail In The Real World](https://medium.com/the-mission/how-school-trains-us-to-fail-in-the-real-world-a67f6ed69be5)** indictment about his lifetime of education in the **American** public school system—wherein what got my attention the most was his simple analysis of what had failed him:

**School (noun)** — **_A place where students suck on an information teat instead of learning how to feed themselves._**

_You can get straight A’s in school, but nobody, no matter how successful, gets straight A’s in life._ 

_No, in life, you tend to get A’s by getting F’s first._

_Lots and lots of F’s._

![](grt22.jpg)

What I’d like for you all to do right now—**_while your minds have in them the different educational realities of students at elite places of learning like the Groton School, versus those from the American public school system_**—is answer these questions:

**_Of the_** **_[over 1,300 top CEOs in America who suddenly resigned from their companies throughout all of last year](https://www.nbcnews.com/business/business-news/why-have-more-1-000-ceos-left-their-post-past-n1076201https:/www.nbcnews.com/business/business-news/why-have-more-1-000-ceos-left-their-post-past-n1076201)_****_, where do you believe nearly all of them were educated?_**

**_Of the_** **_[American super-rich elites who jetted off to their disaster bunkers upon the outbreak of the coronavirus pandemic](https://www.theguardian.com/world/2020/mar/11/disease-dodging-worried-wealthy-jet-off-to-disaster-bunkers)_****_, where do you believe nearly all of them were educated?_**

**_Of the_** **_[American elites who pulled all of their money out of the stock market before the coronavirus pandemic crashed it](https://www.wsj.com/articles/bezos-other-corporate-executives-sold-shares-just-in-time-11585042204)_****_, where do you believe nearly all of them were educated?_**

![](grt23.jpg)

![](grt24.jpg)

![](grt25.jpg)

Now I’d like to tell you a “**_secret_**” about these words **Sister Ciara** wrote—“**_ability to “see through a glass darkly” to find the subtle nuances and currents rippling through history_**”—they really aren’t a mystery!

Anyone, even **YOU**, who spends years, if not decades, learning the classic languages of **Latin** and **Greek**, reads the world’s greatest literature, becomes fully knowledgeable of every religion in human history, studies all sides of historical events and historical personages, and becomes an expert in mathematical theories and equations—and while knowing beyond any doubt whatsoever the **Biblical** truth: “**_[To every thing there is a season, and a time to every purpose under the heaven](https://www.biblegateway.com/passage/?search=Ecclesiastes+3&version=KJV)_**”—will have the ability of being able to foretell events to the extent they can seem actually miraculous.

But to the average **American** citizen, all of these seeming miraculous abilities have been deliberately denied to them—and to fully grasp the utter and complete disdain **American** elites have towards their own people, just remember what one of **Hillary Clinton’s** top aides, **Bill Ivey**, [wrote to her in an email as they were gearing up for the **US** presidential election in **2016**](https://wikileaks.org/podesta-emails/emailid/3599): 

**_And as I've mentioned,_** **_we've all been quite content to demean government, drop civics and in general conspire to produce an unaware and compliant citizenry_****_._**

**_The unawareness remains strong but compliance is obviously fading rapidly._**

**_This problem demands some serious, serious thinking - and not just poll driven, demographically-inspired messaging._**

![](grt26.jpg)

Please allow me to reveal to you another “**_secret_**”—**_which is actually the most important one for you to know right now_**—**Sister Ciara** and her **Dear Sisters** aren’t the only ones who do what they do—far from it—as in every state-backed and private intelligence agency in the world, as well as in every major financial institution and publication, untold numbers of highly-educated experts having the “**_ability to “see through a glass darkly” to find the subtle nuances and currents rippling through history_**” never cease their work to uncover what is to come—all of whom daily scour through the “**_ripples_**” and “**_currents_**” of current events picking out “**_puzzle pieces_**” of information—all of which are filed and categorized, sometimes for years—and as time goes by, and as more “**_puzzle pieces_**” are discovered fitting a particular pattern, are then assembled together to form a complete “**_picture_**”. 

State sanctioned experts who use these abilities have various titles such as “**_intelligence analysts_**” and “**_financial forecasters_**”—while non-state sanctioned experts are called such things as “**_conspiracy theorists_**”, at best, and “**_nut job crackpots_**”, at worst—but whose common link is that **ALL OF THEM** use their abilities while reading the same private intelligence reports and the same financial publications—none of which are available to average persons—with the exception being those able to spend tens-of-thousands of dollars a year for their subscriptions.

With every passing week it seems nowadays, the “**_blockade_**” of information able to been seen by average people sees more and more “**_paywalls_**” being erected around every single major publication—most particularly those containing raw financial data and analysis—and in **America** itself for one to view even the most modest of them (**New York Times, Washington Post, Bloomberg, Financial Times, etc.**), sees the cost being to leap over their “**_paywalls_**” accelerating into the hundreds-of-dollars a year.

![](grt27.png)

![](grt28.jpg)

![](grt29.png)

So here’s where we’re at folks, if you want to know what the future holds based on sound expert intelligence analysis, your only options are to drop everything you’re doing and spend, at least, the next few decades getting, refining and expanding on a **Groton School-like** education—**OR**—support those who have already mastered these skills over decades of training and experience—that’s it, these are the only two options available for anyone not wishing to keep walking through the propaganda minefield of this world waiting to be blown apart.

Which brings me to the last question I’d like to ask all of you—if an “**_Ignorant_**” person is someone who just lacks knowledge, and a “**_Stupid_**” person is someone who has a great lack of intelligence or common sense—which one of them is better prepared to face the trials of our world still to come?

As evidenced by the fact that you’re reading these words, though, you are most certainly not “**_stupid_**”—in fact you’re an “**_Intelligent_**” person showing intelligence, especially of a high level—and is why I’m very confident that you’ll go below and aid **Sister Ciara** and her **Dear Sisters** so they can keep telling you the true things being kept from you—and are very expensive true things because of the hundreds of “**_paywalls_**” they have to leap over on your behalf to find the “**_puzzle pieces_**” needed to form the “**_picture_**” you’ll be able to use to stay informed and protect yourselves and families from whatever is coming next.

Thank you for listening and aiding us in our hour of desperate need by going below and giving what you can, and as always, please feel free to write me at [sorchafaal@fastmail.fm](mailto:sorchafaal@fastmail.fm) with any comments/questions/suggestions, remembering to put **ATTN: BRIAN** in the subject line.

All the best folks,

Brian

Webmaster

Paris

Fr.

[![](do37.jpg)](https://fundrazr.com/21bKL5?ref=ab_48h7S4_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

**[Return To Main Page](https://www.whatdoesitmean.com/)**