        Republican COVID-19 Bill Becomes War Document As Democrats Prepare To Murder School Children  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

July 29, 2020

**Republican COVID-19 Bill Becomes War Document As Democrats Prepare To Murder School Children**

By: Sorcha Faal, and as reported to her Western Subscribers

An intriguing new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today sees this transcript showing its **[Members](http://en.kremlin.ru/structure/security-council/members)** trying to understand what exactly is happening in the **United States**, and why—an undertaking not easily accomplished because of the many perplexing absurdities abounding in **America**—the latest occurring yesterday when **United States Attorney General William Barr** testified at a hearing in the **US House of Representatives** that’s in control of the socialist **Democrat Party**—a hearing that **[brutally opened with Republican Party leader US Congressman Jim Jordon playing a video showing the socialist mob violence decimating America that the socialist Democrats and their leftist mainstream media lapdogs denied was occurring](https://www.thegatewaypundit.com/2020/07/brutal-jim-jordan-opens-ag-barr-hearing-devastating-video-leftist-violence-looting-rioting-streets-america-video/)**, and **Fox News** most accurately described the substance of with the words: “**_[He came, he saw, he ate their lunch. Bill Barr, denied a meal break, feasted instead on a gaggle of Democratic amateurs](https://www.foxnews.com/opinion/michael-goodwin-barr-eats-nadlers-lunch-during-testimony)_**”—and while occurring, saw the **Republican Party** leaders in the **US Senate** pushing forward their **[COVID-19 bill to send a second wave of stimulus checks of up to $1,200 to Americans, plus an additional $500 for dependents](https://money.yahoo.com/coronavirus-stimulus-checks-many-americans-would-get-more-in-go-ps-second-round-of-payments-154353648.html)**—though in reality, **[this COVID-19 bill is an actual war document providing the US military with tens-of-billions of dollars in additional funding on top of the already astronomical $705-billion they’ve already received this year](https://www.thedrive.com/the-war-zone/35168/heres-all-the-ridiculous-military-pork-baked-into-this-proposed-covid-19-bill)**—a perplexity matched by the **[socialist Democrat Party school teachers in Washington D.C. that lined up body bags they say they’ll need for themselves if they’re made to start teaching children again](https://www.dailywire.com/news/dc-teachers-line-up-body-bags-outside-school-offices-after-being-warned-they-may-have-to-return-to-classrooms)**—but factually would be body bags needed for the school children these socialist **Democrat Party** school teachers seem intent on murdering—a grim fact explained by both the **United Nations** and **World Health Organization**, **[both of whom are now warning that school closures and lockdowns are killing more children than the COVID-19 virus](https://www.rt.com/news/496482-study-covid-hunger-children-lancet/)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](ac21.jpg)

According to this report, little noticed by the **American** people this week was the article titled “**[This Is Bigger Than COVID But Few People Are Paying Attention](https://www.zerohedge.com/geopolitical/bigger-covid-few-people-are-paying-attention)**”—wherein it stated “**_[most people realize that 2020 has thrust two game-changing trends upon us that will change the world for years to come](https://www.zerohedge.com/geopolitical/bigger-covid-few-people-are-paying-attention)_**”—said about these two game-changing trends: “**_[The first is Covid...In less than six months, this virus has created extreme global hysteria and economic devastation](https://www.zerohedge.com/geopolitical/bigger-covid-few-people-are-paying-attention)_**”—and—“**_[Then there’s the social justice movement… which tore onto the world stage two months ago with a desire to make important cultural changes...history is being rewritten... vocabulary is being replaced...and any civil discourse results in persecution](https://www.zerohedge.com/geopolitical/bigger-covid-few-people-are-paying-attention)_**”—but then warned: “**_[There is a THIRD, major trend brewing right now...And it could prove to be even bigger than Covid, bigger than the social justice movement...It’s not one that evokes the same emotion...So you won’t see too many people marching in the streets or cowering in fear in their homes...There’s no hysteria...This third major trend is rational...And that’s why it’s largely been ignored...But its impact could be far bigger and longer lasting...I’m talking about conflict with China](https://www.zerohedge.com/geopolitical/bigger-covid-few-people-are-paying-attention)_**”.

While it’s true that this looming war between the **United States** and **Communist China** has “**_largely been ignored_**” by the **American people**, this report notes, this most certainly can’t said about the **Republican Party** leaders in the **US Senate**—who in their just released **COVID-19** bill said designed to give financial relief to suffering peoples, **[included in it war preparation expenditures such as](https://www.thedrive.com/the-war-zone/35168/heres-all-the-ridiculous-military-pork-baked-into-this-proposed-covid-19-bill)**:

**_•$283,000,000 to the Army for new-build AH-64E Block IIIB attack helicopters._**

**_•$375,000,000, to the Army for upgrades for its Double V-Hull (DVH) Stryker 8x8 armored wheeled vehicles._**

**_•$1,068,000,000 to the Navy for P-8A Poseidon maritime patrol aircraft._**

**_•$41,400,000 to the Navy for RGM-184A Naval Strike Missiles (NSM) and launchers specifically for the service's Littoral Combat Ships (LCS)._**

**_•$2,210,000,000 to the Navy, $1,450,000,000 for four "expeditionary medical ships" and $260,000,000 for a single Spearhead class Expeditionary Fast Transport._**

**_•$49,100,000 to the Navy for sonobuoys._**

**_•$686,000,000 to the Air Force for F-35A Joint Strike Fighters._**

**_•$720,000,000 to the Air Force for C-130J Hercules airlifters._**

**_•$650,000,000 to the Air Force for wing replacement kits for A-10 Warthog ground-attack aircraft._**

**_•$76,325,000 to "defense-wide" spending to establish an eighth Terminal High Altitude Area Defense (THAAD) battery._**

**_•$243,270,000 to "defense-wide" spending for an AN/TPY-2 missile defense radar to go with the eighth THAAD battery._**

**_•$40,100,000 to "defense-wide" spending to replace a modified de Havilland DHC-8 intelligence, surveillance, and reconnaissance (ISR) aircraft belonging to U.S. Special Operations Command (SOCOM) that was destroyed during a terrorist attack in Kenya in January 2020._**

**_•$20,000,000 to the Air Force to support the integration of the AGM-158 Joint Air-Surface Standoff Missile (JASSM) onto variants of the F-35 Joint Strike Fighter._**

**_•$65,800,000 to the Missile Defense Agency for hypersonic weapon defense._**

**_•$39,200,000 to the Missile Defense Agency for cruise missile defense._**

**_•$200,000,000 to the Missile Defense Agency for a Ground-based Mid-course Defense (GMD) Service Life Extension Program (SLEP)._**

**_•$290,000,000 to the Missile Defense Agency for the Hypersonic and Ballistic Tracking Space Sensor._**

**_•$153,000,000 to the Navy for depot-level ship maintenance work._**

**_•$800,000,000 for the "National Guard and Reserve  Equipment  Account."_**

**_•$20,000,000 to the Navy for "United States Marine Corps Force Design unfunded requirements."_**

**_•$19,500,000 to the Army for "Force Protection Upgrades."_**

**_•$882,068,000 to the Army for general operation and maintenance._**

**_•$458,237,000 to the Navy for general operation and maintenance._**

**_•$135,542,000 to the Marine Corps for general operation and maintenance._**

**_•$969,357,000 to the Air Force for general operation and maintenance._**

**_•$112,071,000 for "defense-wide" general operation and maintenance._**

**_•$8,000,000 to the Army Reserve for general operation and maintenance._**

**_•$30,000,000 to the Army National Guard for general operation and maintenance._**

**_•$12,000,000 to the Air National Guard for general operation and maintenance._**

**_•$48,500,000, to the Army for "other procurement."_**

**_•$34,823,000 to the Navy for "other procurement."_**

**_•$484,000 for "defense-wide" "other procurement."_**

**_•$5,300,000,000 for Defense Production Act purchases related to the COVID-19 pandemic._**

**_•$1,494,000 to the Air Force for research, development, test, and evaluation work._**

**_•$20,931,000 for "defense-wide" research, development, test, and evaluation work._**

**_•$1,783,500,000 for Defense Working Capital Funds._**

**_•$705,000,000 for the Defense Health Program._**

**_•$1,128,000,000 to the Army for a "Defense Industrial Base Resiliency Fund-Army."_**

**_•$4,664,000,000 to the Navy for a "Defense Industrial Base Resiliency Fund-Navy and Marine Corps."_**

**_•$4,273,400,000 to the Air Force for a "Defense Industrial Base Resiliency Fund-Air Force and Space Force."_**

**_•$783,100,000 for a "Defense Industrial Base Resiliency Fund-Defense: Special Operations Command and Missile Defense Agency."_**

![](ac22.jpg)

While observing all of the chaos now occurring in **America**, this report continues, [retired **US Army** combat war hero **Lieutenant-Colonel Michael For**](https://abdg.com/our-staff/michael-r-ford/)**d** found it necessary today to post his warning letter titled “**[Xi, Putin And Others Are Watching Our China Virus Response; We’ve Already Told Them Too Much](https://www.redstate.com/darth641/2020/07/29/882837/)**”—wherein this combat veteran of **37-years** stated: “**_[There are three types of information…There is interesting information…There is important information…Finally, there is critical information…Each of those can be broken down into: what we want to know about ourselves; what we want to know about the bad guys; and what we don’t want the enemy to know about us](https://www.redstate.com/darth641/2020/07/29/882837/)_**”—and after stating warned: “**_[It’s not just the details of our response to this particular COVID-19  issue, but most critically, what level of harm we would be willing to do to our own economy in a like future event](https://www.redstate.com/darth641/2020/07/29/882837/)_**”.

Complementing this warning being issued by **Lieutenant-Colonel Ford**, this report details, is the just published article titled “**[The COVID-Hysteria Campaign - The Ultimate Divide And Conquer Strategy](https://www.zerohedge.com/political/covid-hysteria-campaign-ultimate-divide-and-conquer-strategy)**”—that not only states: “**_[It has frequently been observed that terror can rule absolutely only over people who are isolated against each other](https://www.zerohedge.com/political/covid-hysteria-campaign-ultimate-divide-and-conquer-strategy)_**”—it grimly warns: “**_[Western civilization, led by the US government and media, has embarked upon a campaign of mass psychological terrorism designed to cover for the collapsing economy, set up a new pretext for Wall Street’s ongoing plunder expedition, radically escalate the police state, deeply traumatize people into submission to total social conformity, and radically aggravate the anti-social, anti-human atomization of the people](https://www.zerohedge.com/political/covid-hysteria-campaign-ultimate-divide-and-conquer-strategy)_**”.

![](ac23.jpg)

With the **United States** being the anchor nation that’s been holding **Western Civilization** together since the end of **World War II**, this report further details, important to note is that **America** has only been able to hold everything together due to the unequaled power of the **US Dollar**—but today is a **United States** being hammered with headlines such as “**[U.S. Is About to Unveil the Ugliest GDP Report Ever Recorded](https://www.iqstockmarket.com/2020/07/29/u-s-is-about-to-unveil-the-ugliest-gdp-report-ever-recorded/?utm_source=Google_News&utm_medium=SitemapNews&utm_campaign=Investing.com&short=t)**”, “**[Almost Half Of All Jobs Lost During Pandemic May Be Gone Permanently](https://www.usatoday.com/story/money/2020/07/29/almost-half-of-all-jobs-lost-during-coronavirus-may-be-gone-permanently/112446072/)**” and “**[Spike In Gold Puts Dollar's Reserve Status In Question](https://thehill.com/policy/finance/509368-spike-in-gold-shows-dollars-reserve-status-in-question-goldman-sachs)**”—headlines most critical to note about must be included in the context of **[leftist American tech giants accelerating their interference in the 2020 presidential election to silence all support for President Trump](https://www.breitbart.com/tech/2020/07/28/election-interference-google-purges-breitbart-from-search-results/)**—that includes **[Twitter censoring President Trump for the first time yesterday and removing one of his Tweets](https://www.newswars.com/twitter-censors-trump-by-completely-removing-his-tweet-for-first-time/)**—a **Tweet** sent out by **President Trump** showing a video of the press conference given by doctors **[exposing the truth about the COVID-19 virus](https://www.breitbart.com/tech/2020/07/27/facebook-censors-viral-video-of-doctors-capitol-hill-coronavirus-press-conference/)**—and after **[every single leftist American tech giant banned this video from being seen by the American people](https://www.breitbart.com/tech/2020/07/27/facebook-censors-viral-video-of-doctors-capitol-hill-coronavirus-press-conference/)**, then saw them **[removing these doctors’ website](https://www.thegatewaypundit.com/2020/07/stunning-twitter-google-youtube-facebook-remove-videos-covid-19-white-coat-summit-now-squarespace-removes-website/)**.

By viewing all of these things in the proper context of them all being a part of the assault on **Western Civilization** being driven by demonic socialist-globalist forces, this report explains, one can understand why **[thousands of Christians in the socialist Democrat Party controlled State of California have now begun to openly defy their godless overlords](https://www.redstate.com/alexparker/2020/07/28/barry-sappington-christians-protest-cardiff-state-beach-protest-baptism/)**—**Christian** peoples now shockingly watching as the **National Football League** **[surrenders to the socialist forces tearing America apart](https://thefederalist.com/2020/07/28/nfl-to-transform-fields-player-helmets-into-black-lives-matter-billboards/)**—a total surrender that now includes the **National Football League** having **[just banned its players from even attending church](https://thefederalist.com/2020/07/28/the-nfl-just-declared-war-on-church/)**—and to be noticed is a **National Football League** dependent on a **Hollywood** that **[has already sold its soul to godless Communist China](https://thefederalist.com/2020/07/28/hollywood-executive-chris-fenton-on-the-relationship-between-china-and-hollywood/)**—and explains why **[top Hollywood actor Seth Rogan is now openly attacking Israel](https://www.rt.com/usa/496485-seth-rogen-israel-lies/)**—and further explains why **[top Hollywood actor Tom Hanks and his wife Rita Wilson celebrated themselves becoming citizens of the only country in the world that’s declared pedophilia a normal disability](https://www.rumormillnews.com/cgi-bin/forum.cgi?read=151496)**—though none of these godless socialist demons seem aware of the reality that **Western Civilization** wasn’t built by man, **[it was built by Jesus](https://www.str.org/w/jesus-built-western-civilization)**—a fact known by **[thousands of American police officers from at least 100 law enforcement agencies around Wisconsin that are now canceling their agreements to help provide security at next month's socialist Democratic National Convention in Milwaukee](https://www.rt.com/usa/496484-dnc-convention-police-withdraw/)**.    

![](ac24.jpg)

Most critically having gone unnoticed by the **American** people as they watch their nation be consumed with violence and chaos, this report continues, was a **3 June 2020** article published by the **American** financial news site **[Business Insider](https://en.wikipedia.org/wiki/Business_Insider)**—a financial news site actually owned by the powerful **German** publishing house **[Axel Springer](https://en.wikipedia.org/wiki/Axel_Springer_SE)**—that’s important to know as this international publisher having tens-of-millions of readers the world over is not known for superfluous articles—thus meaning that when it published its article titled “**[A Book Published Nearly 25 years Ago Predicted America Would Hit A Great Crisis Climaxing In 2020 — And That Up Next Is A Millennial vs. Boomer Standoff That Will Usher In A New World Order](https://www.businessinsider.com/protests-coronavirus-crisis-fourth-turning-theory-millennials-boomers-2020-6)**” it knew exactly what it was doing—is an article directly referencing one of the most feared books ever written titled “**[The Fourth Turning](https://www.fourthturning.com/)**”—and is feared because it exactly documents every “**_[Fourth Turning Event](https://www.lifecourse.com/about/method/the-four-turnings.html)_**” in human history, to include the last one called **World War II**, and the present one now taking place—that are paradigm shifting times in human history destroying what was and creating an entirely new world—and are marked by events that shatter human minds—that makes explainable why a week ago, on **23 July 2020**, the **New York Times** published its stunning article titled “**[No Longer in Shadows, Pentagon’s U.F.O. Unit Will Make Some Findings Public](https://www.nytimes.com/2020/07/23/us/politics/pentagon-ufo-harry-reid-navy.html)**” wherein it revealed:

**_Eric W. Davis, an astrophysicist who worked as a subcontractor and then a consultant for the Pentagon U.F.O. program since 2007, said that, in some cases, examination of the materials had so far failed to determine their source and led him to conclude, “_****_We couldn’t make it ourselves._****_”_**

**_Mr. Davis, who now works for Aerospace Corporation, a defense contractor, said he gave a classified briefing to a Defense Department agency as recently as March about retrievals from “_****_off-world vehicles not made on this earth._****_”_**

**_Mr. Davis said he also_** **_gave classified briefings on retrievals of unexplained objects_** **_to staff members of the Senate Armed Services Committee on Oct. 21, 2019, and to staff members of the Senate Intelligence Committee two days later._**

**_Committee staff members did not respond to requests for comment on the issue_****_._**

Making what the **New York Times** revealed most remarkable and notable, this report concludes, was that absolutely no one in the entire **US** government pushed back and said any of it was untrue—and during the past **24-hours**, was followed by the **New York Times** publishing another article titled “**[Do We Believe in U.F.O.s? That’s the Wrong Question](https://www.nytimes.com/2020/07/28/insider/UFO-reporting.html)**” wherein it stated “**_[Reporting on the Pentagon program that’s investigating unidentified flying objects is not about belief…It’s about a vigilant search for facts](https://www.nytimes.com/2020/07/28/insider/UFO-reporting.html)_**”—and when viewed in the light of the now expanding “**_Fourth Turning Event_**” now overtaking the entire world, could very well mean that **President Trump** is preparing to reveal to the world the existence of alien life—a revelation that would overturn everything we thought we knew—and beyond all doubt, would create an entirely new world. 

![](ac25.jpg)

July 29, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[America Falls Into Rabbit Hole—Cheshire Cat Reminds Them “_We're All Mad Here_”](https://www.whatdoesitmean.com/index3282pl.htm)**

**[“_Eyes Wide Shut_” Transformation Of America Being Led By “_Rulers Of The Darkness Of This Age_”](https://www.whatdoesitmean.com/index3282.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**