        CIA Assassins Attack US Air Force Plane Carrying ANTIFA Terrorist Leaders  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Trump Convenes Emergency Meeting, Mobilizes NATO, After ANTIFA Leftists Confirmed Training In Venezuela](https://www.whatdoesitmean.com/index2361.htm)**

**[Google Backed ANTIFA Attempt To Assassinate President Trump Captured On Video](https://www.whatdoesitmean.com/index2372.htm)**

**[Virginia Prepares To Unleash “_Red Guard Forces_” As Prisons Expanded To Hold Citizens Refusing To Give Up Guns](https://www.whatdoesitmean.com/index3081.htm)**

**[ANTIFA Terrorists Cripple Canadian Rail System As Train Derailment Attacks Begin Striking America](https://www.whatdoesitmean.com/index3136.htm)**

**[Socialists Declare American Revolution As Low-Intensity Conflict Erupts In United States](https://www.whatdoesitmean.com/index3230.htm)**

**[Russia Designates George Floyd “_Incident_” Psyop Operation—Warns CIA Is Main Target](https://www.whatdoesitmean.com/index3231.htm)**

**[NASA Issues Incoming Asteroid Alert As Combat Warplanes Fill Night Skies Of America](https://www.whatdoesitmean.com/index3232.htm)**

**[Feared Zaslon Assassins Deployed To America With Orders To Wipe Out ANTIFA Leadership](https://www.whatdoesitmean.com/index3233.htm)**

**[Communist China Throws Full Support Behind “_Prairie Fire_” Riots Destroying America They Call “_Beautiful_”](https://www.whatdoesitmean.com/index3234.htm)**

**[President Trump Now Protected By Powerful US Army Force Capable Of Leveling Washington D.C.](https://www.whatdoesitmean.com/index3235.htm)**

**[United Nations Calls Out Democrat Party Plantation Masters For Black Uprising In America](https://www.whatdoesitmean.com/index3236.htm)**

**[Socialists Throw 2020 Back To 1960's And 1980's—But Outcome Favoring Trump Remains The Same](https://www.whatdoesitmean.com/index3237.htm)**

**[“_You Reap What You Sow_” Drama Sees Elmer Fudd Disarmed And Prince Andrew Nearing Arrest](https://www.whatdoesitmean.com/index3238.htm)**

June 9, 2020

**CIA Assassins Attack US Air Force Plane Carrying ANTIFA Terrorist Leaders**

By: Sorcha Faal, and as reported to her Western Subscribers

A mind-blowing highly-classified “**_[Of Special Importance](https://fas.org/irp/world/russia/class.htm)_**” new **Foreign Intelligence Service** ([SVR](http://government.ru/en/department/112/)) report circulating in the **Kremlin** today, and appearing to provide a reason why riot and looting activities suddenly ceased in the **United States** this past week, says that at approximately **18:20 GMT +3** on **8 June** in **Baghdad-Iraq** (**_6:20 pm local time_**), a team of **Special Activities Center** ([SAC](https://en.wikipedia.org/wiki/Special_Activities_Center)) commando-assassins from the **Central Intelligence Agency** ([CIA](https://www.cia.gov/index.html)) attacked and caused to crash a **[C-130 Hercules](https://www.af.mil/About-Us/Fact-Sheets/Display/Article/1555054/c-130-hercules/)** cargo plane belonging to the **US Air Force** as it was landing with **7** crew members and **26** passengers—a fiery crash the “**_[official cover story](https://www.thedrive.com/the-war-zone/33942/air-force-c-130h-smacks-into-wall-bursts-into-flames-after-overshooting-runway-in-iraq)_**” claims was caused when this plane crashed into a wall while landing—an official cover story disputed by the **SVR** that tracked this plane after it departed from the **Joint Base San Antonio** ([JBSA](https://www.jbsa.mil/)) military facility located in **San Antonio-Texas**, traveled to **Kuwait** and then attempted land in **Baghdad**—an **SVR** that was also tracking the movement of these **CIA** commando-assassins, who arrived at **Joint Base San Antonio** a few hours after this **C-130** Hercules departed from there—and shortly after arriving, saw **US Army** intelligence operative **Jared Esquibel Harless** from the **[470th Military Intelligence Brigade](https://www.inscom.army.mil/msc/470mib/contact.html)** at **Joint Base San Antonio** being **[discovered dead along with his wife and four children](https://news4sanantonio.com/news/local/family-of-six-identified-after-bodies-found-inside-suv-from-apparent-murder-suicide)** at their home that **[was rigged to explode](https://www.usatoday.com/story/news/nation/2020/06/05/san-antonio-family-6-found-dead-garage/3161409001/)**—an unmistakable “**_message massacre_**” that after which saw these **CIA** commando-assassins breaking into two teams—the one that flew to attack the **C-130** cargo plane the SVR believes was carrying escaping **ANTIFA** terrorist leaders, and the other flying to **California**—where they tracked down, wounded in a gun battle and captured **US Air Force Staff Sergeant Steven Carrillo**, who is a member of the elite **[US Air Force Phoenix Raven Security Unit](https://www.thebalancecareers.com/air-force-security-forces-phoenix-raven-4054147)** (aka “**_[The Murder Crew](https://www.thebalancecareers.com/air-force-security-forces-phoenix-raven-4054147)_**”), of which **[there are only 150  members](https://airman.dodlive.mil/2016/05/02/house-of-pain/#:~:text=When%20fully%20trained%2C%20Ravens%20are,is%20either%20unknown%20or%20inadequate.)**—was a **[gun battle that saw Sergeant Carrillo killing a California police officer and wounding two others while using explosives](https://sanfrancisco.cbslocal.com/2020/06/08/alleged-santa-cruz-gunman-steven-carrillo-trained-to-be-member-of-elite-air-force-raven-security-unit/)**—with **[Sergeant Carrillo further being linked to the assassination of US federal officer David Underwood, who died in a hail of bullets fired at him on 25 May when ANTIFA rioting broke out in Oakland-California](https://sanfrancisco.cbslocal.com/2020/06/07/steven-carrillo-alleged-santa-cruz-mountain-gunman-may-be-connected-to-oakland-federal-officer-slaying/)**—and when captured, **Sergeant Carrillo** was caught on police radio broadcasts saying: “**_[This is what I came to fight...I'm sick of these goddamn police](https://www.indybay.org/newsitems/2020/06/06/18833874.php)_**”.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](rav26.jpg)

**CIA commando-assassins deliver “_massacre message_” to ANTIFA leaders and their US military backers by exterminating US Army intelligence operative Jared Esquibel Harless (_above_) and his entire family for aiding in their escape…**

![](rav24.jpg)

**…then travel to Baghdad-Iraq and attack landing US Air Force plane (_above_)…**

![](rav25.jpg)

**…and go to California to capture elite “_Murder Crew_” operative US Air Force Sergeant Steven Carrillo (_above_).**

According to the very limited portions of this highly-classified report permitted to be commented on by various **Ministries**, going unnoticed by the **American** people was a “**_Deep State_**” intelligence leak in **March-2018** warning that “**_[Trump’s CIA is sending small teams of commandos downrange to kill selected bad guys](https://news.clearancejobs.com/2018/03/20/leak-week-cia-commandos-job/)_**”—a warning coming during the gravest hours of the **[coup being attempted against President Trump](https://www.amazon.com/Coup-d%C3%89tat-Exposing-Re-Elect-President/dp/1642934372)**—and alerted these coup plotters that the **CIA’s** feared **[Special Activity Center](https://en.wikipedia.org/wiki/Special_Activities_Center)** had been activated—an elite unit responsible for covert operations, paramilitary operations and assassinations—one of whose most recent assassination missions was the killing of **Iranian Quds Force General Soleimani**—and for which, a few hours ago, **[Iran sentenced the CIA agent they had captured to death for](https://www.rt.com/news/491266-iran-execute-cia-agent-soleimani/)**—but most critical to know about, are commando assassins having just **[three commanders](https://en.wikipedia.org/wiki/Special_Activities_Center)**—**President Donald Trump**, **CIA Director Gina Haspel** and **Deputy Director of CIA Operations Elizabeth Kimber**—with both **Haspel** and **Kimber** being the most feared female “**_[honey pot](https://en.wikipedia.org/wiki/Honey_trapping)_**” assassins the **CIA** has ever produced—and everyone knowing that **President Trump** “**_[is now out for revenge](https://www.politico.com/news/2020/05/14/trump-robert-mueller-revenge-259318)_**”.  

![](rav27.jpg)

![](rav28.jpg)

Following the “**_massacre message_**” delivered by these **CIA** commando-assassins in wiping out **US Army** intelligence operative **Jared Esquibel Harless** and his entire family because he aided in the escape of **ANTIFA** terror leaders from **America**, this report continues, former top **US** military officials aligned with this “**_Deep State_**” coup plot have **[begun openly attacking President Trump this past week](https://www.nbcnews.com/politics/meet-the-press/mattis-other-military-leaders-close-ranks-against-trump-n1224661)**—attacks based on their fears of whom is going to be targeted for death next—one of whom most assuredly near the top of this death list being the former top **Obama-Clinton** regime **Defense Department** and **State Department** intelligence analyst **[Salmah Rizvi](https://www.ropesgray.com/en/biographies/r/salmah-rizvi)**—who along with other “**_Deep State_**” operatives **[guaranteed bail for bomb-throwing radical socialist lawyer Urooj Rahman](https://nypost.com/2020/06/04/ex-analyst-under-obama-guarantees-bail-for-alleged-bomb-throwing-lawyer/)**—that **[along with her fellow radical socialist lawyer friend Colinford Mattis threw arson bombs at police cars, both of whom had their bail quickly revoked and were thrown back in prison](https://www.thegatewaypundit.com/2020/06/new-york-appeals-court-orders-molotov-cocktail-lawyers-domestic-terrorists-back-jail/)**.

![](rav21.jpg)

**“_Deep_ _State_” operatives bail out from prison radical socialist lawyer Urooj Rahman (_above_) after she firebombed police cars…**

![](rav29.png)

**…but along with fellow radical socialist lawyer Colinford Mattis (_above left_) was quickly put back in prison.**

In just one grim example as to the further complicity of “**_Deep State_**” operatives and rogue **US** military factions aiding **ANTIFA** terrorist activities taking place in **America**, this report details, the **SVR** notes the recent actions of retired **US Air Force Master Sergeant Matthew Michanowicz**—an instructor in “**_The Murder Crew_**” elite unit that trained the now captured killer and bomb maker **US Air Force Sergeant Steven Carrillo**—who **[this past Sunday was discovered placing a bomb at the PNC Plaza in Pittsburg-Pennsylvania](https://triblive.com/local/pittsburgh-allegheny/authorities-re-apprehend-pittsburgh-bomb-suspect-after-apartment-search/)**—**[in whose home was discovered supplies to make weapons of mass destruction](https://triblive.com/local/pittsburgh-allegheny/authorities-re-apprehend-pittsburgh-bomb-suspect-after-apartment-search/)**—and who **[now faces US federal criminal charges](https://triblive.com/local/pittsburgh-allegheny/feds-charge-pittsburgh-man-52-with-placing-bag-full-of-homemade-bombs-downtown-having-supplies-at-home/)**. 

![](rav23.jpg)

**Retired US Air Force Master Sergeant Matthew Michanowicz (_above_), who was captured after planting bombs…**

![](rav30.JPG)

**…was instructor at “_The Murder Crew_” elite unit that trained US Air Force Sergeant Steven Carrillo (_[left in US Air Force photo above](https://www.travis.af.mil/News/Photos/igphoto/2002053988/)_)…**

![](rav22.jpg)

**…and whose bombs (_above_) matches those made and used by Sergeant Steven Carrillo to kill California police officer.**

On **30 May**, this report concludes, **Russia** designated what was occurring in **America** as being a “**_[Low-Intensity Conflict](https://www.oxfordreference.com/view/10.1093/oi/authority.20110803100116990)_**”—a designation most particularly noted because it unleashed the unmatched drone and spy satellite surveillance and tracking capability available to the **CIA**, the **FBI** and the **US** military—surveillance abilities that are **[able to track individuals by their unique electrical brain wave signatures able to be read and identified by satellites flying hundreds-of-miles above the surface of the earth](https://www.whatdoesitmean.com/index3230.htm)**—which makes it no surprise that **[the killer of retired St. Louis police captain David Dorn was captured and arrested so quickly](https://www.stltoday.com/news/local/crime-and-courts/charges-filed-in-murder-of-retired-st-louis-police-captain-david-dorn/article_3e95441e-4126-520b-9c41-fbbcbf889e6c.html)**—but most concerning about, are surveillance capabilities that over the past week have further identified numerous known to be **US** military operatives participating in **ANTIFA** terrorist actions—some of whom include **36-year-old Aaron Evanshine** and **24-year-old Brian Contreras**, **[both of whom were captured while  driving a car full of knives, bricks and gas canisters heading to New York City from Ohio](https://www.rumormillnews.com/cgi-bin/forum.cgi?read=148248)**—**20-year-old Dakota Gifford**, **[who was captured while driving a car loaded with guns in Tennessee](https://www.wvlt.tv/content/news/20-year-old-charged-with-possession-of-firearms-narcotics-identified-570909811.html#:~:text=Source%3A%20(KPD)&text=Police%20stopped%20Gifford%20around%201,two%20shotguns%2C%20and%20two%20rifles.)**—**23-year-old Branden Michael Wolfe**, **[who was captured and arrested by the FBI for burning down a police station in Minneapolis](https://www.foxnews.com/us/minnesota-man-arson-charge-police-precinct)**—**31-year-old Gregory Wong**, **[who was captured with his massive arsenal of weapons while wearing a US military uniform](https://www.zerohedge.com/political/la-man-arrested-massive-arsenal-while-impersonating-national-guardsman)**—and **28-year-old Matthew Rupert**, **[who was captured while bringing bombs to Minneapolis while on a mission to destroy parts of the city](https://www.rumormillnews.com/cgi-bin/forum.cgi?read=147966)**—all of whose captures come at the same exact same time **[the FBI is saying it’s found no evidence of ANTIFA involvement in riots or protests](https://www.ajc.com/news/fbi-finds-evidence-antifa-involvement-national-unrest/qVI3U9wb8Q6u1QEvVsJ7AJ/)**—but could find if they changed the name of **ANTIFA** to any of the rogue **US** military units causing this chaos like the **CIA** has done.

![](rav31.jpg)

June 9, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Global Battlefields Littered With Coronavirus Dead—But Who’s Winning War?](https://www.whatdoesitmean.com/index3229pl.htm)**

**[All That's Left Now Is War—What Kind And How Long Are The Questions To Ask](https://www.whatdoesitmean.com/index3229.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**