        Trump Accuses Communist China Of “Mass Worldwide Killing” Then Issues Documents Of War  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Coronavirus Pandemic War Series: Part 1](https://www.whatdoesitmean.com/index3167.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 2](https://www.whatdoesitmean.com/index3181.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 3](https://www.whatdoesitmean.com/index3192.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 4](https://www.whatdoesitmean.com/index3203.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 5](https://www.whatdoesitmean.com/index3212.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

**[Coronavirus Pandemic War Series: Part 6](https://www.whatdoesitmean.com/index3221.htm)** **\[Note: Read from top report down for most complete context of this historic event.\]**

May 21, 2020

**Trump Accuses Communist China Of “_Mass Worldwide Killing_” Then Issues Documents Of War**

By: Sorcha Faal, and as reported to her Western Subscribers

A grimly foreboding new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today contemplating the grave significance of the largest escalation to date in the now raging out of control “**_[Coronavirus Pandemic War](https://www.whatdoesitmean.com/index3167.htm)_**”, reveals its **[Members](http://en.kremlin.ru/structure/security-council/members)** met with unanimous acclaim **President Putin’s** declaration that “**_[Russia is now fully self-sufficient in basic food products](https://tass.com/economy/1158537)_**”—a declaration that now insulates the **Motherland** from the soon to come ravages visited upon the world by **Communist China** and the **United States** as the battle against each for global supremacy—with the most dangerous moves in this conflict coming yesterday after **United States Secretary of State Mike Pompeo** issued a statement saying: “**_[I would like to congratulate Dr. Tsai Ing-wen on the commencement of her second term as Taiwan’s President…Her re-election by a huge margin shows that she has earned the respect, admiration, and trust of the people on Taiwan… Her courage and vision in leading Taiwan’s vibrant democracy is an inspiration to the region and the world](https://www.state.gov/taiwans-inauguration-of-president-tsai-ing-wen/)_**”—a statement immediately followed by the **[US approving the $180-million sale of advanced torpedoes to Taiwan](https://www.aljazeera.com/news/2020/05/approves-180m-sale-advanced-torpedoes-taiwan-200520235339185.html)**—not just any torpedo, but one of the most feared in the world knows as the **[MK-48 Mod 6 Advanced Technology Heavy Weight Torpedo](https://www.raytheon.com/capabilities/products/mk48)** that’s able to destroy any **Communist Chinese** warship it’s fired against.

Which **Communist** **China** responded to with a threat warning vowing that it “**_[will take necessary countermeasures, and the consequences will be borne by the US side](https://www.newsweek.com/china-threatens-countermeasures-says-us-will-bear-consequences-after-pompeo-congratulates-1505480)_**”—which itself was quickly responded to by **President Donald Trump** posting his own threat warning saying: “**_[Some wacko in China just released a statement blaming everybody other than China for the Virus which has now killed hundreds of thousands of people…Please explain to this dope that it was the “incompetence of China”, and nothing else, that did this mass Worldwide killing!](https://twitter.com/realDonaldTrump/status/1263085979491016708)_**”—a threat warning issued by **President Trump** against **Communist China** containing the “**_Noise_**” portion of his “**_[Signal and Noise](https://conceptually.org/concepts/signal-and-noise)_**” true intent claims and declaration—**_with the signal being the meaningful information that you're actually trying to detect, while the noise is the random, unwanted variation or fluctuation that interferes with the signal_**.

And whose “**_Signal_**” coming through the “**_Noise_**” issued by **President Trump** against **Communist China** is contained in two chilling documents of war released during the past **48-hours**—the first being a **4-page** document titled the “**[White House Letter To World Health Organization](https://www.whitehouse.gov/wp-content/uploads/2020/05/Tedros-Letter.pdf)**”, and the second being a **20-page** document titled “**[United States Strategic Approach to The People’s Republic of China](https://www.whitehouse.gov/wp-content/uploads/2020/05/U.S.-Strategic-Approach-to-The-Peoples-Republic-of-China-Report-5.20.20.pdf)**”—both of which combined are an internationally legally binding and recognized criminal indictment of **Communist China** accusing it of crimes against humanity—whose legal precedent is based on the **October-1943** **Moscow Conference** “**[Declaration on German Atrocities in Occupied Europe](https://avalon.law.yale.edu/wwii/moscow.asp)**”—which even before **World War II** had ended, saw **United States President Franklin Roosevelt**, **British Prime Minister Winston Churchill** and **Soviet Premier Joseph Stalin** joining with each other on **1 November 1943** to declare: “**_[Let those who have hitherto not imbued their hands with innocent blood beware lest they join the ranks of the guilty, for most assuredly the three Allied powers will pursue them to the uttermost ends of the earth and will deliver them to their accusors in order that justice may be done](https://avalon.law.yale.edu/wwii/moscow.asp)_**”.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](wkt21.jpg)

According to this report, with war having been interwoven into the entire history of mankind, in **May-1921** the face of it was changed forever—and occurred in the aftermath of **World War I** when the **German Supreme Court** began the **[Leipzig War Crimes Trials](https://en.wikipedia.org/wiki/Leipzig_War_Crimes_Trials)**—that brought to trial twelve individuals accused of crimes against humanity—whose trials were seen as a travesty of justice because of the small number of cases tried and the perceived leniency of the court—and whose proceedings at the time were widely regarded as a failure.

Far from being a failure, though, this report details, this first in human history trial for those accused of crimes against humanity formed the entire basis of what occurred next in **World War II**—and was when the **Allied Powers** followed the **German Supreme Court’s** war crimes procedures to first issue a declaration of intent to prosecute war criminals—which resulted in the **[Nuremberg Trials](https://en.wikipedia.org/wiki/Nuremberg_trials)** that brought **Nazi Germany** war criminals to their final justice.

![](wkt22.jpg)

Most important to know about both the **Leipzig War Crimes Trials** and **Nuremberg Trials**, this report notes, are that they established the international procedures for criminally prosecuting nation states, the political and military leaders of these nation states, as well as the allies and/or supporters of these nation states being accused of crimes against humanity—with the first procedure to be followed being the issuing of an international legally recognized charging indictment of the crimes against humanity being alleged, and whom they’re being alleged against—and the second procedure being the accusing party putting forth an internationally recognized legal argument as to why the accused nation state is a threat to all of humanity.

On **18 May 2020**, this report continues, the **United States** released to the world its **4-page** document titled “**[White House Letter To World Health Organization](https://www.whitehouse.gov/wp-content/uploads/2020/05/Tedros-Letter.pdf)**”—a document signed by **President Donald J. Trump** signaling its binding authority—but was written by **White House** legal authorities steeped in the international procedures needed to compile a war crimes charging indictment—as evidenced by this document laying out point-by-point, and date-by-date indisputable facts of how **Communist China** conspired with the **World Health Organization** to spread the **COVID-19** coronavirus around the world and kill hundreds of thousands of innocent human beings—which makes this document an internationally recognized charging indictment of **Communist China** alleging it’s committed crimes against humanity.

On **20 May 2020**, this report further details, the United States followed their charging indictment of **Communist China** with a **20-page** document titled “**[United States Strategic Approach to The People’s Republic of China](https://www.whitehouse.gov/wp-content/uploads/2020/05/U.S.-Strategic-Approach-to-The-Peoples-Republic-of-China-Report-5.20.20.pdf)**” that describes the grave threat the **Chinese Communist Party** (CCP) poses to both the world and all of humanity—wherein it grimly lays out facts proving that **Communist China** can only be compared to the nation state killing machines of the past known as **Nazi Germany** and the **Soviet Union**—and includes its factually stating:  

**_The CCP promotes globally a value proposition that challenges the bedrock American belief in the unalienable right of every person to life, liberty, and the pursuit of happiness._**

**_Under the current generation of leadership, the CCP has accelerated its efforts to portray its governance system as functioning better than those of what it refers to as “developed, western countries.”_**

**_Beijing_** **_is clear that it sees itself as engaged in an ideological competition with the West._**

**_The CCP aims to make China a “_****_global leader in terms of comprehensive national power and international influence_****_,” as General Secretary Xi expressed in 2017, by strengthening what it refers to as “_****_the system of socialism with Chinese characteristics_****_.”_**

**_This system is rooted in Beijing’s interpretation of Marxist-Leninist ideology and combines a nationalistic, single party dictatorship; a state-directed economy; deployment of science and technology in the service of the state; and the subordination of individual rights to serve CCP ends._**

**_This runs counter to principles shared by the United States and many likeminded countries of representative government, free enterprise, and the inherent dignity and worth of every individual._**

**_One disastrous outgrowth of such an approach to governance is Beijing’s policies in Xinjiang, where since 2017, authorities have detained more than a million Uighurs and members of other ethnic and religious minority groups in indoctrination camps, where many endure forced labor, ideological indoctrination, and physical and psychological abuse._**

**_Outside these camps, the regime has instituted a police state employing emerging technologies such as artificial intelligence and biogenetics to monitor ethnic minorities’ activities to ensure allegiance to the CCP. Widespread religious persecution – of Christians, Tibetan Buddhists, Muslims, and members of Falun Gong – includes the demolition and desecration of places of worship, arrests of peaceful believers, forced renunciations of faith, and prohibitions on raising children in traditions of faith._**

**_The CCP’s campaign to compel ideological conformity does not stop at China’s borders._**

**_In recent years, Beijing has intervened in sovereign nations’ internal affairs to engineer consent for its policies._**

**_PRC authorities have attempted to extend CCP influence over discourse and behavior around the world, with recent examples including companies and sports teams in the United States and the United Kingdom and politicians in Australia and Europe._**

**_PRC actors are exporting the tools of the CCP’s techno-authoritarian model to countries around the world, enabling authoritarian states to exert control over their citizens and surveil opposition, training foreign partners in propaganda._**

![](wkt23.jpg)

Barely noticed by the **American** people after **President Trump** issued his war documents laying out the case to prove **Communist China** is a mass murder nation state, and his moving to protect **Taiwan** from these godless monsters, this report concludes, yesterday his **White House** press secretary **Kayleigh McEnany** sat down in the midst of this global crisis for a remarkable interview with the **Christian Broadcasting Network** ([CBN](https://www1.cbn.com/))—wherein she revealed that when she asked **President Trump’s** daughter-in-law **Lara Trump** what made the difference in the **2016** election, her one word answer was “**_[prayer](https://twitter.com/DavidBrodyCBN/status/1263130485682774018)_**”—with **McEnany** further stating “**_[I do believe that President Trump is the person meant for this moment](https://twitter.com/DavidBrodyCBN/status/1263130485682774018)_**”—and one hopes is true, because if **God** is standing beside **President Trump** as he battles to save the whole world, victory is not only possible, it’s assured.

![](wkt24.jpg)

**_“So do not fear, for I am with you; do not be dismayed, for I am your God. I will strengthen you and help you; I will uphold you with my righteous right hand.”_**

**Book of Isaiah— Chapter 41 Verse 10**

May 21, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Coronavirus “_Wisdom_” Lays Waste To America While Prosecutor Durham Goes On Hiring Spree](https://www.whatdoesitmean.com/index3195pl.htm)**

**[Stone Cold Truth Feared By Elites Points To Viking King Trump Saving America](https://www.whatdoesitmean.com/index3195.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**