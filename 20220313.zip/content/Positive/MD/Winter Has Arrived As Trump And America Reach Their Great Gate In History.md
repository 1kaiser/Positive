        Winter Has Arrived As Trump And America Reach Their Great Gate In History <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**Winter Has Arrived As Trump And America Reach Their Great Gate In History**

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“History is seasonal, and winter is coming.”_**

[William Strauss](https://en.wikipedia.org/wiki/William_Strauss) (1947-2007)—co-author of [The Fourth Turning: An American Prophecy - What the Cycles of History Tell Us About America's Next Rendezvous with Destiny](https://www.amazon.com/Fourth-Turning-American-Prophecy-Rendezvous/dp/0767900464)

**Special Report from Sister Ciara**

**My Dearest Friends:**

The definition of “**_[You can take it to the bank](https://idioms.thefreedictionary.com/can+take+it+to+the+bank)_**” means one can believe a particular statement or piece of information because it is definitely true—two examples of which are the words in the **Book of Ecclesiastes** that say “**_[For everything there is a season, and a time for every purpose under heaven…](https://www.biblegateway.com/passage/?search=Ecclesiastes%203%3A1-8&version=ASV)_**” and the old saying “**_[What goes around comes around](https://www.merriam-webster.com/dictionary/what%20goes%20around%20comes%20around#:~:text=Definition%20of%20what%20goes%20around%20comes%20around,-informal&text=%E2%80%94used%20to%20say%20that%20if,You%20should%20not%20mistreat%20them.)_**”—both of which explain our world as being a place where everything is cyclical, what was before will be again, and if you wait around for awhile and really notice things, you’ll see countless examples of how very true this is.

For example, yesterday, on **21 October**, the internet took center place on the presidential election stage when **US** intelligence officials held a hurried press conference to **[accuse Iran of targeting American voters with faked but menacing emails](https://www.washingtonpost.com/technology/2020/10/20/proud-boys-emails-florida/)**—an accusation added to by the leftist media saying “**_[Other U.S. officials, speaking privately, stressed that Russia still remained the major threat to the 2020 election](https://www.washingtonpost.com/technology/2020/10/20/proud-boys-emails-florida/)_**”.

A near exact repeat of what occurred exactly four years ago, on **21 October 2016**—which was when the internet took center place on the presidential election stage because **[supporters of WikiLeaks leader Julian Assange had to be begged to stop taking the internet down in America](https://thehill.com/blogs/blog-briefing-room/news/302278-wikileaks-calls-on-its-supporters-to-stop-taking-down-the-us)**. 

And in my knowing of what was really going on, spurred me to send to you exactly four years ago today, on **22 October 2016**, my letter “**[Donald Trump Landslide Victory Races World War III To Finish Line](https://www.whatdoesitmean.com/index2146.htm)**”—wherein, unlike everyone else who’d been lying to you, I told you the truth that “**_[Donald Trump is on the cusp of achieving a landslide victory, let me assure you this is based on fact, not supposition](https://www.whatdoesitmean.com/index2146.htm)_**”.

![](tx21.jpg)

Now one would logically think that since my **Dear Sisters** and I out predicted every major polling firm and mainstream media company in the world we’d be celebrated, or at the very least acknowledged—but instead of that happening, we’ve been attacked and vilified worse than ever, and whose reasons for is because **we told you the truth**—a truth that **Trump** would win that most important for you to know about was also known by these same polling firms and mainstream media companies—none of whom are idiots unable to have looked at the same facts and data we did, far from it—as what they were really doing while lying to you was conducting a mass manipulation operation specifically designed to incite fear, anger and rage.

And whose reasons for them conducting this mass manipulation operation against you was their knowing of the unassailable truths contained in historical research described in the **1997** book “**[The Fourth Turning: An American Prophecy - What the Cycles of History Tell Us About America's Next Rendezvous with Destiny](https://www.amazon.com/Fourth-Turning-American-Prophecy-Rendezvous/dp/0767900464)**”—the most important information about you should sear into your mind today is:

**_The next Fourth Turning is due to begin shortly after the new millennium, midway through the Oh-Oh decade._**

**_Around the year 2005, a sudden spark will catalyze a Crisis mood._**

**_Remnants of the old social order will disintegrate._**

**_Political and economic trust will implode._**

**_Real hardship will beset the land, with_** **_severe distress that could involve questions of class, race, nation, and empire._** **_. .The very survival of the nation will feel at stake._**

**_Sometime before the year 2025,_** **_America_** **_will pass through a great gate in history_****_, commensurate with the American Revolution, Civil War, and twin emergencies of the Great Depression and World War II._**

**_The risk of catastrophe will be very high._**

**_The nation could erupt into insurrection or civil violence, crack up geographically, or succumb to authoritarian rule._**

**_If there is a war, it is likely to be one of maximum risk and effort — in other words, a total war._**

**_Every Fourth Turning has registered an upward ratchet in the technology of destruction, and in mankind’s willingness to use it._**

![](tx22.jpg)

![](tx23.png)

What you’ve just read that’s playing out exactly as predicted **23-years-ago** saw this **Fourth Turning’s** “**_sudden spark_**” being the **[2008 Financial Crisis](https://www.thebalance.com/2008-financial-crisis-3305679)**—and in knowing what was being planned to occur, was why we warned you beforehand of what was to come in our **28 June 2007** report “**[US Banking Collapse ‘Imminent’ Warns French Banking Giant](https://www.whatdoesitmean.com/index1019.htm)**”—a warning we sounded out to you **9-months** before the **[16 March 2008 collapse of American banking giant Bear Stearns](https://www.history.com/this-day-in-history/bear-stearns-sold-to-j-p-morgan-chase)** and **15-months** before the **[15 September 2008 collapse of banking giant Lehman Brothers](https://www.investopedia.com/articles/economics/09/lehman-brothers-collapse.asp)**—and for those who heeded our warning by taking their money out of banks and buying gold at **[around $850 an ounce in June-2007](https://www.macrotrends.net/1333/historical-gold-prices-100-year-chart)**, today sees it being worth **[$1,900 an ounce](https://www.kitco.com/gold-price-today-usa/)**.  

Gold today, however, that’s priced out of the range of great numbers of **Americans**—who **[between October-2019 and August-2020 alone have chosen to protect themselves by buying over 15.5-million new guns](https://www.statista.com/statistics/1107651/monthly-unit-sales-of-firearms-by-type-us/)**—that have been added to the **[estimated over 393-million guns owned by an estimated 72-million Americans](https://wamu.org/story/20/09/18/how-many-people-in-the-u-s-own-guns/)**—that makes these gun owning **Americans** the largest armed military force in all of recorded human history—and in a **Fourth Turning** crisis like what is occurring now is otherwise known as a powder keg just waiting to explode.

![](tx24.jpg)

As many of you no doubt know, a powder keg is a dangerous or volatile situation that’s likened to a barrel of gunpowder—but before it can explode, it has to be ignited—and you most certainly don’t need me to tell you the forces trying to do this, or why they want this explosion to occur—but for those of you not knowing, just remember that in this **Fourth Turning** crisis “**_The nation could erupt into insurrection or civil violence, crack up geographically, or succumb to authoritarian rule_**”—a fact that should lead you to ask what forces most benefit when this occurs—whose only answer are those attempting to establish authoritarian rule over **America**.

An answer that most certainly doesn’t fit **President Donald Trump** in any way whatsoever as **America** prepares to pass through yet another great gate in history to decide its fate during this **Fourth Turning**—and is why distinguished historians like **[Professor Emeritus Fred Siegel](https://cooper.edu/academics/people/fred-siegel)** are voting for **Trump** even though they don’t personally like him—and in explaining this week why he has turned away from his lifelong support of **Democrats** and liberal causes to support **Trump**, saw the **Wall Street Journal** **[writing](https://www.wsj.com/articles/an-ex-liberal-reluctantly-supports-trump-11602875814)**:

**_In Mr. Siegel’s view, “_****_hard work, faith, family and autonomy_****_” have enabled America to thrive, and Mr. Trump stands for these values, even if he doesn’t always exemplify them._**

**_“_****_The elite is largely detached from the middle class_****_,” Mr. Siegel says._**

**_“_****_The two major sources of wealth in the last 20 years have been finance and Silicon Valley. Neither of them has much connection to middle-class America, or Middle America_****_.” Mr. Trump is “_****_in favor of manufacturing jobs, which are often middle-class_****_.” The president also “_****_recognizes the ways in which China is a threat to the survival of middle-class life in America, directly and indirectly_****_.”_**

**_Mr. Siegel takes heart from Mr. Trump’s hostility to political correctness. “_****_Wokeness is a force that undermines the middle class_****_,” he says, “_****_and you couldn’t have had wokeness without an elite contempt for the values of the middle class_****_.”_**

**_Middle Americans see political correctness “_****_as a threat to the democratic republic they grew up in, where people could speak their mind_****_.”_**

**_I ask Mr. Siegel to define political correctness: “_****_The inability to speak the truth about the obvious_****_.”_**

![](tx25.jpg)

This elite contempt for the values of the middle class was best displayed by **Hillary Clinton** during the **2016** election when she said: “**_[You could put half of Trump's supporters into what I call the basket of deplorables...they are irredeemable](https://www.npr.org/2016/09/10/493427601/hillary-clintons-basket-of-deplorables-in-full-context-of-this-ugly-campaign)_**”—and best displayed during the current **2020** election when high-tech executive **[Pam Stevenson](https://www.breitbart.com/politics/2020/10/20/bio-tech-company-exec-blasts-retarded-midwesterners-after-michigan-trump-rally/)** wrote the other day about a **Trump** rally in **Norton Shores**\-**Michigan** saying: “**_[I see your city hosted a Trump-COVID super spreader rally, brilliant since the pandemic is spiking in your state!!!...The rest of the country has finally given up on trying to educate you midwest morons and now we think it is the fastest way to thin the herd of ignorant trumpanzees, so keep it up...The cherry on top was listening to those maskless douchebags chant to their fat orange God ‘lock her up,’ as a result of retardo trump suggesting your Governor needs to open things back up...Are you midwesterners really this retarded...I suppose this is what happens when you have sex with your own family and drink too much moonshine](https://www.breitbart.com/politics/2020/10/20/bio-tech-company-exec-blasts-retarded-midwesterners-after-michigan-trump-rally/)_**”.

You should know that the definition of contempt is one feeling that a person is worthless and beneath consideration—and when displayed against you by two women like **Hillary Clinton** and **Pam Stevenson** who were both educated in elite universities, should alert you to what you’re really facing—because with **Clinton** you’re seeing someone wanting to light the powder keg fuse, and with **Stevenson** you’re seeing someone about to explode.

And make no mistake about it, this fuse is being lit and this powder keg will explode on **3 November**—because that is the day **President Donald Trump** will be re-elected—and if you thought the left’s reaction to him being elected in **2016** was one level of horror, in less than two weeks time you’re going to see what a true catastrophe looks like when he’s reelected—and will be the real life **Fourth Turning** crisis you’ve been warned about with the words: “**_The nation could erupt into insurrection or civil violence, crack up geographically, or succumb to authoritarian rule....If there is a war, it is likely to be one of maximum risk and effort — in other words, a total war_**”.

Now in this “**_Rendezvous with Destiny_**” neither you nor the ones you love can run away from or avoid, you should know that my **Dear Sisters**, and others like us, have been preparing to guide **America** through this **Great Gate** in history as quickly and peacefully as possible—a preparation that has kept us behind and on the front lines of this **Fourth Turning** crisis working ceaselessly to protect you with truth and knowledge—but whose casualties now numbering in the tens-of-thousands of once truthful information sources are now buried in leftist social media giant and mainstream media graveyards because no one like you stood up to protect them—and that I plead to you with tears and mercy not to also bury us in. 

And with this plea, I humbly remind you of the words of guidance given to us by our **Dear Lord** for exactly such times of crisis as these: “**_[One gives freely, yet grows all the richer; another withholds what he should give, and only suffers want. Whoever brings blessing will be enriched, and one who waters will himself be watered.](https://www.biblegateway.com/passage/?search=Proverbs+11%3A24-25&version=ESV)_**”—and if heeded and lived by, puts you under the protection of our **Lord Jesus** who promised you: “**_[Look at the birds of the air: they neither sow nor reap nor gather into barns, and yet your heavenly Father feeds them. Are you not of more value than they?](https://www.biblegateway.com/passage/?search=Matthew+6%3A26&version=ESV)_**”—and whom I pray you believe.

With God,

Sister Ciara

Dublin, Ireland

22 October 2020

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s October, 2020/November, 2020 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 103”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/)

[](https://www.whatdoesitmean.com/indexnews.htm)