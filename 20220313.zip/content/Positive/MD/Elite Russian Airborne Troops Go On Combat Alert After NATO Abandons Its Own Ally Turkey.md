        Elite Russian Airborne Troops Go On Combat Alert After NATO Abandons Its Own Ally Turkey  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

October 11, 2019

**Elite Russian Airborne Troops Go On Combat Alert After NATO Abandons Its Own Ally Turkey**

By: Sorcha Faal, and as reported to her Western Subscribers

A tersely worded new **Ministry of Defense** ([MoD](http://eng.mil.ru/)) report circulating in the **Kremlin** today states that an elite parachute battalion from the **[137th Guards Airborne Regiment](https://en.wikipedia.org/wiki/137th_Guards_Airborne_Regiment)** under the command of **Russian Airborne Forces** ([VDV](https://en.wikipedia.org/wiki/Russian_Airborne_Forces)) has been **[ordered to full combat alert status and given 24-hours to begin inter-operability training](https://tass.com/defense/1082648)** with special commando forces from the **[38th Guards Air Assault Brigade](https://en.wikipedia.org/wiki/38th_Guards_Air_Assault_Brigade)** of the **[Armed Forces of Belarus](https://en.wikipedia.org/wiki/Armed_Forces_of_Belarus)**—all of whom will conduct their combat operations with long-range heavy-lift **[Il-76MD](https://en.wikipedia.org/wiki/Ilyushin_Il-76)** aircraft and **[Yak-130](https://en.wikipedia.org/wiki/Yakovlev_Yak-130)** fighter protection aircraft designed to insert into combat **[Mi-8](https://en.wikipedia.org/wiki/Mil_Mi-8)** troop transport and **[Mi-24](https://en.wikipedia.org/wiki/Mil_Mi-24)** gunship helicopters in wartime conditions—a combat order issued by **President Putin** under his **[Article 87](http://www.constitution.ru/en/10003000-05.htm)** authority as **Commander-In-Chief**—and whose statement of fact in asserting this wartime authority warns “**_[Turkey may not be able to contain militants from the Islamic State terror group (outlawed in Russia) active in northern Syria while conducting a military operation in the region](https://tass.com/politics/1082667)_**”—a grave situation **Turkey** has been placed in by its own **North Atlantic Treaty Organization** ([NATO](https://www.nato.int/)) who are not only refusing to come to the aid of their ally, **[calls are now shockingly being made to kick Turkey out of this Western military alliance all together](https://www.express.co.uk/news/world/1189166/turkey-news-syria-attack-kurds-isis-nato-francois-hollande)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](esse1.jpg)

According to this report, the **North Atlantic Treaty Organization** is an international alliance that consists of **29** member states from **North America** and **Europe**—whose most powerful member is the **United States** and its **[2,206,350](https://en.wikipedia.org/wiki/Member_states_of_NATO#Military_personnel)** troops—and sees its second most powerful member **Turkey** having **[890,700](https://en.wikipedia.org/wiki/Member_states_of_NATO#Military_personnel)**—all of whom are bound to the collective defense of one another under their treaty’s **[Article 5](https://www.nato.int/cps/en/natohq/topics_110496.htm)** provisions—which has [only been invoked once in history after the **11 September 2001** terrorists attacks on **America**](https://www.nato.int/cps/en/natohq/topics_110496.htm).

In **[October-2015](https://thehill.com/policy/defense/258657-obama-sending-troops-to-syria)**, this report continues, the **Obama-Clinton Regime** caused the **United States** to became a deliberate, direct combatant against the **Syrian** government without their having been attacked—and though never invoking **Article 5**, dragged with them into this internal civil war conflict many of its **NATO** allies—an invasion of a sovereign nation that **[remains as illegal now as it was when the Americans first invaded](https://www.washingtonpost.com/news/monkey-cage/wp/2018/04/13/attacking-syria-wasnt-legal-a-year-ago-its-still-not/)**.  

![](esse3.jpg)

As to why the **Obama-Clinton Regime** illegally invaded **Syria**, this report details, was actually revealed by **[NATO Supreme Commander US General Wesley Clark](https://en.wikipedia.org/wiki/Wesley_Clark)** shortly after the **9/11** attacks on **America**—and who **[beyond shockingly stated](https://www.globalresearch.ca/we-re-going-to-take-out-7-countries-in-5-years-iraq-syria-lebanon-libya-somalia-sudan-iran/5166)**:

**_About ten days after 9/11_****_, I went through the Pentagon and I saw Secretary Rumsfeld and Deputy Secretary Wolfowitz._**

**_I went downstairs just to say hello to some of the people on the Joint Staff who used to work for me, and one of the generals called me in._**

**_He said, “_****_Sir, you’ve got to come in and talk to me a second._****_”_**

**_I said, “Well, you’re too busy.”_**

**_He said, “_****_No, no._****_”_**

**_He says, “_****_We’ve made the decision we’re going to war with Iraq._****_”  This was on or about the 20th of September._**

**_I said, “_****_We’re going to war with Iraq?  Why?_****_”_**

**_He said, “_****_I don’t know._****_”  He said, “_****_I guess they don’t know what else to do._****_”_**

**_So I said, “_****_Well, did they find some information connecting Saddam to al-Qaeda?_****_”_**

**_He said, “_****_No, no._****_”_**

**_He says, “_****_There’s nothing new that way. They just made the decision to go to war with Iraq._****_”_**

**_He said, “_****_I guess it’s like we don’t know what to do about terrorists, but we’ve got a good military and we can take down governments._****_”_**

**_And he said, “_****_I guess if the only tool you have is a hammer, every problem has to look like a nail._****_”_**

**_So I came back to see him a few weeks later, and by that time we were bombing in Afghanistan._**

**_I said, “_****_Are we still going to war with Iraq?_****_”_**

**_And he said, “_****_Oh, it’s worse than that_****_.”  He reached over on his desk.  He picked up a piece of paper.  And he said, “_****_I just got this down from upstairs_****_” — meaning the Secretary of Defense’s office — “_****_today._****_”_**

**_And he said, “_****_This is a memo that describes how we’re going to take out seven countries in five years, starting with Iraq, and then Syria, Lebanon, Libya, Somalia, Sudan and, finishing off, Iran._****_”_**

**_I said, “_****_Is it classified?_****_”_**

**_He said, “_****_Yes, sir._****_”_**

**_I said, “_****_Well, don’t show it to me._****_”_**

**_And I saw him a year or so ago, and I said, “_****_You remember that?_****_”_**

**_He said, “_****_Sir, I didn’t show you that memo!  I didn’t show it to you!_****_”_**

![](esse2.jpg)

As to why the **United States** planned to start endless wars throughout the entire **Middle East** they could never hope, or even come close to winning, as they would have to mobilize an army of tens-of-millions of soldiers to win such a conflict that rivals **World War II**, this report notes, **MoD** analysts began noticing that at the same time the **United States** was expanding its wars around the **Middle East**, it was at the same time drastically cutting the budget of its military forces fighting in these endless wars—most especially under **[the Obama-Regime who gutted their nation’s entire military](https://www.wsj.com/articles/how-obama-shrank-the-military-1438551147)**—and by the time **President Trump** took power in **January-2017**, saw **[only three of the US Army's 58 brigade combat teams ready to fight](https://www.military.com/daily-news/2017/02/07/most-army-brigades-navy-planes-combat-ready-leaders.html)**—**[53% of the US Navy’s aircraft unable to fly](https://www.military.com/daily-news/2017/02/07/most-army-brigades-navy-planes-combat-ready-leaders.html)**—**[the US Air Force being 723 fighter pilots short](https://www.military.com/daily-news/2017/02/07/most-army-brigades-navy-planes-combat-ready-leaders.html)**—and **[the US Marine Corps needing 3,000 more troops before it could even think of fighting](https://www.military.com/daily-news/2017/02/07/most-army-brigades-navy-planes-combat-ready-leaders.html)**—and worst of all, **[Trump reporting that his generals told him not to start any more wars because they were out of ammunition](https://taskandpurpose.com/trump-mattis-ammunition-shortage)**.

![](esse4.jpg)

**American people kept from knowing that the socialist Obama-Clinton Regime effectively nearly destroyed the entire US military.**

Unbeknownst to the **American** people as to why the **Obama-Clinton Regime** was destroying their own nation’s once all-powerful military, this report explains, was instantly understood by anyone knowing **Russian** history—as once **[Russia’s military forces were destroyed in the needless and foolish World War I](https://en.wikipedia.org/wiki/Russian_entry_into_World_War_I)**—there was no one left to defend the **Motherland** when **[radical socialist-communist forces staged their revolution](https://en.wikipedia.org/wiki/Russian_Revolution)** that enslaved **Russia** and its peoples for the next **74 years**—a grim fate scheduled to repeated in **America** once socialist leader **Hillary Clinton** took power—but who was met by a force called **Donald Trump** who defeated **Clinton** and her socialist forces—and who, on **[12 December 2017](https://militarybenefits.info/2018-defense-budget-overview/)**, signed his first defense budget giving his military forces a staggering **near $700 billion**—on **[10 December 2018](https://militarybenefits.info/2019-defense-budget/)** signed his second defense budget giving his military forces another **$716 billion**—which, in turn, allowed the **US Army** to declare this past **March-2019** that “**_[more than half of the Army’s brigade combat teams have achieved top levels of preparedness](https://www.stripes.com/combat-readiness-of-army-brigades-improving-but-hasn-t-reached-service-s-goal-milley-says-1.574389)_**”—allowed the **[US Navy last month to announce that they had surpassed their 80% aircraft readiness goal](https://news.usni.org/2019/09/25/navy-surpasses-80-aircraft-readiness-goal-reaches-stretch-goal-of-341-up-fighters)**—but does see the **[US Air Force going backwards as they are now in desperate need of over 2,000 pilots](https://federalnewsnetwork.com/dod-personnel-notebook/2019/04/new-study-shows-grim-outlook-for-future-of-air-force-pilot-shortage/)**—thus explaining why **Trump** is **[trying to end his nation’s endless wars](https://buchanan.org/blog/is-trump-at-last-ending-our-endless-wars-137583)** before **America** becomes defenseless—and whose greatest threat is from within—and is why **Trump** vowed to his peoples that “**_[America will never be a socialist country](https://www.theguardian.com/us-news/2019/apr/28/trump-wisconsin-rally-touts-economy)_**”.

![](esse5.jpg)

With both **[Russia and United States refusing to join a United Nations Security Council resolution slamming Turkey for its military operation in Syria](http://www.hurriyetdailynews.com/us-russia-refuse-to-issue-joint-statement-on-turkeys-syria-operation-in-divided-unsc-session-147373)**, this report concludes, **[Turkey’s call for solidarity among its NATO allies](https://sputniknews.com/middleeast/201910111077019983-turkey-to-nato-we-expect-solidarity-from-allies-on-northern-syria-operation/)** has been met with— **[Norway stopping military exports to its NATO ally Turkey](https://sputniknews.com/military/201910111077016946-norway-stops-military-equipment-exports-to-fellow-nato-member-turkey-over-syria-offensive/)**—**[Italy now calling for its NATO ally Turkey to stop its aggression in Syria](https://www.sana.sy/en/?p=175480)**—**[US Congress members preparing to slap sanctions on its NATO ally Turkey](https://www.rt.com/usa/470660-house-republicans-bill-turkey-sanctions/)**—**[the European Union planning to sanction and oust from NATO its ally Turkey](https://www.bloomberg.com/news/articles/2019-10-11/eu-to-discuss-sanctions-turkey-s-nato-memmbership-france-says)**—and **[former French President François Hollande outright calling for Turkey to be kicked out of NATO](https://www.express.co.uk/news/world/1189166/turkey-news-syria-attack-kurds-isis-nato-francois-hollande)**—all of which **Turkey** has justifiably responded to by **[condemning its NATO allies for arming the Kurdish terrorists in Syria to begin with](https://www.newsweek.com/turkey-condemns-nato-allies-arming-kurdish-terrorists-syria-jens-stoltenberg-mevlut-cavusoglu-1464598)**, and their declaring to them “**_[This Is Your Hypocrisy](https://www.newsweek.com/turkey-condemns-nato-allies-arming-kurdish-terrorists-syria-jens-stoltenberg-mevlut-cavusoglu-1464598)_**”—an hypocrisy of the **West** and **NATO** whose heights of insanity are now soaring to the heavens of absurdity as demonstrated by **[the fact the military officer leading Turkey’s attack on Kurdish terrorists in Syria is a US-backed former rebel leader](https://www.zerohedge.com/geopolitical/former-us-backed-rebel-leader-now-leading-invasion-against-us-backed-syrian-kurds)**—a **US-backed** rebel leader who was given funds provided to him and his fighters by the **US Congress** under a bill sponsored by **US Senator Lindsey Graham**—the same **Senator Graham** who, two days ago, attacked **President Trump** for “**_[shamelessly abandoning Kurdish allies](https://www.independent.co.uk/news/world/americas/us-politics/trump-turkey-syria-lindsey-graham-twitter-isis-kurdish-allies-a9149251.html)_**”—but is, also, the same **Senator Graham** who, in a spoof recorded call where he believed he was talking in secret to the **Turkish Defense Minister**, **[expressed sympathy for Turkey’s “_Kurdish problem_” and described the Kurds as a “_threat_”](https://www.politico.com/news/2019/10/10/lindsey-graham-trump-hoax-call-043991)**—thus making it more than understandable why sane people everywhere in the world can’t wait for **Trump** to “**_[Drain The Swamp](https://www.breitbart.com/politics/2019/10/10/peter-schweizer-washington-corrupt-practices-act-needed-to-drain-the-swamp/)_**” before these insane hypocrites kill even more innocent peoples.   

![](esse6.jpg)

October 11, 2019 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Democrat Party “_Burn The Ships!_” Strategy To Destroy Trump Forewarns American Annihilation](https://www.whatdoesitmean.com/index2995pl.htm)**

**[Lucifer Unleashed Against President Trump As Last Stand For America Begins](https://www.whatdoesitmean.com/index2995.htm)**

**[“_Ghost Warrior_” Wants Trump Assassinated—Hints It’s Coming Soon](http://whatdoesitmean.com/index2968pl.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**