        Fear Stalking America Awakens Europe To True Terror <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**Fear Stalking America Awakens Europe To True Terror**

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“Once a government is committed to the principle of silencing the voice of opposition, it has only one way to go, and that is down the path of increasingly repressive measures, until it becomes a source of terror to all its citizens and creates a country where everyone lives in fear”_**

[Harry S. Truman](https://en.wikipedia.org/wiki/Harry_S._Truman) (1884-1972)—33rd President of the United States, serving from 1945 to 1953.  The above [cited quote](https://www.trumanlibrary.gov/library/public-papers/207/special-message-congress-internal-security-united-states) is from his Special Message to the Congress on the Internal Security of the United States, 8 August 1950.

 **Special Report from Sister Ciara**

**My Dearest Friends:**

During just the past week alone, the world watched as **President Joe Biden** **[delivered an angry speech in Atlanta-Georgia essentially declaring war on every American opposing him](https://thehill.com/opinion/white-house/590004-shame-on-biden-for-his-atlanta-remarks-but-are-we-surprised)**—it was revealed that top **Biden** official **Education Secretary Miguel Cardona** **[solicited a National School Boards Association letter comparing American parents to domestic terrorists](https://www.blackenterprise.com/education-secretary-miguel-cardona-allegedly-solicited-letter-comparing-parents-to-domestic-terrorists/)**—saw articles appearing like “**[DirecTV Cancels OAN after Joe Biden Orders Media Outlets and Tech Giants to Banish Voices that Deviate from the Regime’s Official Narrative](https://www.thegatewaypundit.com/2022/01/directv-cancels-oan-joe-biden-orders-media-outlets-tech-giants-banish-voices-deviate-regimes-official-narrative/)**”—all of which occurred barely a fortnight from when a new **[Axios/Momentive poll](https://www.surveymonkey.com/curiosity/axios-2021-year-end/)** of the mood of **Americans** revealed: “**_[More than half of the people in our survey — 54% — said they're more fearful than hopeful about what's in store for the world in 2022](https://www.axios.com/america-fears-rise-2022-poll-e6684bee-e6bf-41be-919a-caf4cf9fb951.html)_**”.

While contemplating this issue, my mind turned back to the “**_[Red Scare](https://millercenter.org/the-presidency/educational-resources/age-of-eisenhower/mcarthyism-red-scare)_**” hysteria over the perceived threat posed by **Communists** in **America** during the **Cold War** between the former **Soviet Union** and the **United States**, which intensified in the late **1940s** and early **1950s**—an hysteria that **[reached a fever pitch](https://millercenter.org/the-presidency/educational-resources/age-of-eisenhower/mcarthyism-red-scare)** when **Senator Joe McCarthy** launched a series of highly publicized probes into alleged **Communist** penetration of the **State Department**, the **White House**, the **Treasury**, and even the **US Army**—an hysteria plunging the **American** people into an abyss of fear so severe they turned against each other—an hysteria so severe it caused mass censorship, blacklisting, mass firings and mass arrests—but before **America** tore itself completely apart, **President Harry S. Truman**, on **8 August 1950**, delivered a **[Special Message](https://www.trumanlibrary.gov/library/public-papers/207/special-message-congress-internal-security-united-states)** to the **American** people, in part, telling them:

**_Police states are not secure; their history is marked by successive purges, and growing concentration camps, as their governments strike out blindly in fear of violent revolt._**

**_Once a government is committed to the principle of silencing the voice of opposition, it has only one way to go, and that is down the path of increasingly repressive measures, until it becomes a source of terror to all its citizens and creates a country where everyone lives in fear_****_._**

![](hst21.png)

![](hst22.jpg)

Two of the **European** nations most alarmed about the fear stalking **America** today are **France** and **Germany**, both of whom recoiled in terror this week when **[Mark Brzezinski](https://en.wikipedia.org/wiki/Mark_Brzezinski)** was sworn in to be the **United States** ambassador to **Poland**, who is the son of former **United States National Security Advisor** **[Zbigniew Brzezinski](https://en.wikipedia.org/wiki/Zbigniew_Brzezinski)** (**1928-2017**)—most important to know about infamous **Cold War** hawk **Zbigniew Brzezinski** is that he was **[the architect of the Grand Chessboard theory of geostrategic power](https://www.rt.com/news/546567-brzezinski-sworn-in-poland/)** that viewed the **[Eurasian Continent](https://en.wikipedia.org/wiki/Eurasia)** as the fulcrum of world power, and he believed it was **[in the best interests of America to control it](https://www.rt.com/news/546567-brzezinski-sworn-in-poland/)**, given its richness in natural resources, physical wealth, and population—today sees **Russia** being the greatest **Eurasian** power, and **America** wanting control over its **[world’s largest natural resource wealth valued at over $75-trillion](https://www.rt.com/business/447815-russia-natural-resources-sanctions/)**—and today sees **Zbigniew Brzezinski’s** daughter **Mika** being a leftist propagandist host on **MSNBC**, whose co-host husband **Joe Scarborough** **[practically pounded his fists into the news desk earlier this month](https://www.rt.com/op-ed/546564-tucker-carlson-ukraine-war/)**, demanding that **President Biden** “**_[move aggressively](https://www.rt.com/op-ed/546564-tucker-carlson-ukraine-war/)_**” against **Russia**.

Now for those you wanting to know how **Russia** will respond to anyone “**_moving aggressively_**” against them, you don’t have to guess, or even listen to anyone explaining to you what will happen—that’s because **Russia** has already told the world what it will do in its **[Nuclear War Doctrine](https://sgp.fas.org/crs/nuke/R45861.pdf)**, wherein it methodically explains how it will first demonstrate its power, then wait to see what happens—next it will launch nuclear strikes against key **American** and **NATO** military targets, then wait to see what happens—and if retaliated against, it will unleash its entire **[world’s largest nuclear weapons arsenal](https://www.armscontrol.org/factsheets/Nuclearweaponswhohaswhat)** against every **American** and **NATO** city—and are facts of war explaining why it’s now being reported: “**_[The U.S. Navy’s Sixth Fleet has offered an unusual public disclosure of the location of USS Georgia (SSGN 729), one of four of the service’s converted Ohio class nuclear-powered guided-missile submarines, or SSGNs, as it conducted a brief stop near the island of Cyprus…These rare disclosures tend to occur at times of heightened international tensions…With the situation in Ukraine quickly approaching an outright crisis, it’s likely that the Navy intended for this glimpse at Georgia to serve as a signal to both allies and Russia that the United States has a highly capable presence in the region that can reach out and strike over long distances with little risk to itself](https://www.thedrive.com/the-war-zone/43943/navy-sends-a-message-by-publicizing-guided-missile-submarines-mediterranean-presence)_**”.

In knowing that the **American** people have been deliberately induced into fear hysteria to such an extent they aren’t even aware of how close their socialist leaders have brought them to the brink of total war, this week it caused newly installed **German Foreign Minister Annalena Baerbock** to rush to **Moscow** for urgent talks with her **Russian** counterpart **Foreign Minister Sergey Lavrov**, after which she declared: “**_[It is important to flesh out the Normandy process again in order to move forward with the implementation of the Minsk agreements…This would contribute to the reinforcement of security in Europe…It is encouraging that all sides to the Normandy Format and Minsk Agreements stated their adherence to the Agreements](https://tass.com/world/1389847)_**”.

Quickly joining **Germany** in breaking with the **United States** to seek peace through diplomacy with **Russia** before the outbreak of war is **French President Emmanuel Macron**, who yesterday “**_[called for a new European order](https://www.rt.com/russia/546568-macron-russia-world-order/)_**” and declared: “**_[The European Union must open its own talks with Russia rather than rely on Washington](https://www.theguardian.com/world/2022/jan/19/macron-says-eu-must-start-own-dialogue-with-russia-over-ukraine)_**”, as he warned of the prospect of “**_[the most tragic thing of all – war](https://www.theguardian.com/world/2022/jan/19/macron-says-eu-must-start-own-dialogue-with-russia-over-ukraine)_**”.

As to how **Germany** and **France** found themselves on the brink of war with **Russia** being masterminded by the **United States**, today it’s best explained by world renowned historian **[Professor Glenn Diesen](https://www.usn.no/om-usn/kontakt-oss/tilsette/glenn-diesen-1)** at the **University of South-Eastern Norway**, who in his just released document “**[How The EU Found Itself Excluded From Talks On Deciding Europe’s Future](https://www.rt.com/russia/546423-america-decide-europe-fate/)**” reveals:

**_The EU has hit out after it was effectively excluded from security talks between Russia and the US._**

**_The fate of the world may have once been decided in Western European capitals, but now it seems to be out of their hands_****_._**

**_However, it seems increasingly clear that the bloc only has itself to blame for the fact its members no longer have a seat at the top table, leaving them the subject of discussions, rather than the driver of them._**

**_In advance of the talks last week, Washington rhetorically agreed that European security cannot be decided over the heads of the EU and Ukraine, before then simply going ahead with the bilateral US-Russia format._**

**_Simply put, Washington cannot do diplomacy with Eurocrats in the room_****_._**

**_The first reason is that the credibility of US security guarantees is juxtaposed with compromise._**

**_In 1962, President Kennedy and the Soviet Union reached an agreement to resolve the Cuban missile crisis, which stipulated that the US would remove its Jupiter missiles from Turkey in return for the Soviet Union removing its missiles from Cuba._**

**_Instead of celebrating the diplomatic efforts that prevented nuclear war,_** **_the US conditioned the agreement on it being kept a secret_****_._**

**_Kennedy lied to the US public and its foreign allies_****_._**

**_For two decades, the US public believed that the crisis had been solved by confronting Moscow in an uncompromising stance, which made the Soviets back down and grant victory to the US._**

**_Jack Matlock, the last US ambassador to the USSR, argues that_** **_the US similarly rewrote history by claiming that the Cold War was “won” by the collapse of the Soviet Union in 1991, when in reality it was negotiated to an end in 1989 through compromise_****_._**

**_According to Matlock_****_, the consequence of US mythmaking is a national narrative in which peace is achieved by staring down and defeating its adversaries, while compromise is denounced as “appeasement.”_**

**_Consequently, actual diplomacy and compromise must be done behind closed doors._**

**_The second reason is that the foundation of “alliance solidarity” is always to stand united against the adversary, Russia, which ensures that the bloc_** **_can only speak in the language of ultimatums and threats_****_._**

![](hst23.jpg)

When looking at the **United States** today and what it’s become, I’m constantly reminded of **19th Century** famed **English** philosopher **[William Hazlitt](https://en.wikipedia.org/wiki/William_Hazlitt)** (**1778-1830**) having observed: “**_[Those who are at war with others are not at peace with themselves](https://www.brainyquote.com/quotes/william_hazlitt_383510)_**”—an observation of truth playing itself out daily in an **American** leftist propaganda media establishment that’s been at constant war against **President Donald Trump** for nearly six full years, and best exampled this past week by the leftist **New York Times** screed “**[We Need To Think The Unthinkable About Our Country](https://www.nytimes.com/2022/01/13/opinion/january-6-civil-war.html)**”, wherein it hysterically warns their entire nation is doomed because of **President Trump**—and I’m bringing to your attention because buried deep within this hysterical fear inducting screed is this golden gem of truth: “**_[In the 20th century, constructive doomsaying helped prevent the Cold War from becoming a shooting war…It was ultimately worst-case thinking that stabilized nuclear deterrence and staved off nuclear Armageddon](https://www.nytimes.com/2022/01/13/opinion/january-6-civil-war.html)_**”.

Now if you want an example of “**_constructive doomsaying_**” specifically created to “**_stave off Armageddon_**”, this past week alone my **Dear Sisters** have given you the “**_ultimately worst-case thinking_**” reports “**[America Trembles After Russian Doomsday Torpedo Explodes Ocean Causing Global Tsunami](https://www.whatdoesitmean.com/index3804.htm)**”—“**[Russian Doomsday Torpedo Causing Global Shockwave Forces Feared American Sub To Surface](https://www.whatdoesitmean.com/index3805.htm)**”—“**[Atomic Thunderstorm Ignited By Russian Doomsday Torpedo Blast Strikes Curvature Of Spacetime](https://www.whatdoesitmean.com/index3806.htm)**”—and—“**[Biden Warns Of “_Strong Response_” For Russian Nukes In Cuba—Putin Gives “_10 Megaton_” Reply](https://www.whatdoesitmean.com/index3807.htm)**”.

![](wdd23.png)

**If it looks like duck, sounds like a duck and flies like a duck…It’s A Duck!**

![](tec21.gif)

Within these four “**_constructive doomsaying_**” reports the full and entire documented truth about what’s happening now, its history, the parties involved and its consequences are revealed—and as you know, **NO ONE ELSE** is bothering to tell you these truths, put them into historical context or even bother to explain them.

Unlike the warmongering propagandists that treat you like stupid children not deserving to know how they’re plotting your future, our mission has always been to treat you like grown intelligent adults able to be presented facts so you can decide the truth of matters for yourself.

And like the grown intelligent adults you truly are, it should come as no surprise that those few of us left telling you the truth are under relentless attack, and our only defense is **YOU**—because without your immediate and generous support for those of us fighting this war behind and on the front lines, the truth will be extinguished.

And is why, as always, I’ll leave you today with the words I’ve left you with before, and are as true right now as they always will be: **_In the coming months, the dimensions of this looming war are going to shift in radical and unforeseen ways—which is why we believe it is your right to know the full truth about what is happening—a truth the demonic enemies of humanity and our_** **_God_** **_are doing everything in their power to suppress—which is why our_** **_Dear Lord_** **_ordered us to band together in such times as these to protect one another—a protection we urgently need at this very moment to keep the truth flowing to you—and in aiding us, our_** **_Dear Lord_** **_has promised you: “_****_[Give, and it will be given to you. A good measure, pressed down, shaken together and running over, will be poured into your lap. For with the measure you use, it will be measured to you.](https://dailyverses.net/giving)_****_”_**

With God,

Sister Ciara

Dublin, Ireland

20 January 2022

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s January, 2022/February, 2022 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 118”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/)

[](https://www.whatdoesitmean.com/indexnews.htm)