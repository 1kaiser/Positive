        West “Will Reap A Whirlwind” As Russia Declares “No Relations” With EU And China Slams America  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

**[What You Aren’t Being Told About The World You Live In](https://www.whatdoesitmean.com/)**

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](https://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

March 23, 2021

**West “_Will Reap A Whirlwind_” As Russia Declares “_No Relations_” With EU And China Slams America**

By: Sorcha Faal, and as reported to her Western Subscribers

A foreshadowing of things to come new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today first noting that **President Putin** **[always has the nuclear briefcase at hand wherever he is](https://tass.com/politics/1268661)**, says this reminder was needed after the **European Union** ignored the warning issued last month by **Foreign Minister Sergey Lavrov** that **Russia** was ready to break off relations with the **EU** if **Navalny** sanctions target the economy, with his stating: “**_[If you want peace, prepare for war!](https://www.rt.com/russia/515345-lavrov-breaking-off-relations-eu-borrell/)_**”—and because the **EU** ignored this warning, **Foreign Minister Lavrov** was forced to declare this morning that **[Moscow now has “_no relations_” with the EU because Brussels has “_destroyed_” once friendly ties](https://www.rt.com/russia/518881-lavrov-brussels-worsened-relations/)**, and in his official statement said: “**_[There are no relations with the EU as an organization…The entire infrastructure of these relations has been destroyed by unilateral decisions made from Brussels](https://www.rt.com/russia/518881-lavrov-brussels-worsened-relations/)_**”.

A breaking off of relations between **Russia** and the **European Union** quickly joined by the **People’s Republic of China** **[throwing retaliatory sanctions on the United States, European Union, United Kingdom and Canada in response to the ones placed on them yesterday by these Western powers](https://www.cnbc.com/2021/03/23/chinas-sanctions-on-eu-preview-how-beijing-will-respond-to-pressure.html)**—that was joined by **Chinese Foreign Ministry** spokeswoman **Hua Chunying** **[questioning the legitimacy of the US, Canada, the EU and the UK proclaiming themselves “_human rights judges_”](https://www.rt.com/news/518895-china-west-sanctions-xinjiang/)**, and her specifically warning **America**: “**_[The era when a few cannons can open the door to China is gone!](https://www.rt.com/news/518895-china-west-sanctions-xinjiang/)_**”.

Near exactly after having issued this warning, however, **Supreme Socialist Leader Joe Biden** (**_or whoever is in control of America_**) ordered a **[US Air Force RC-135U Combat Sent electronic intelligence aircraft to scream its way directly towards the Chinese border in a provocative act of war](https://www.thedrive.com/the-war-zone/39890/did-an-rc-135-spy-plane-really-make-an-unprecedented-run-at-chinese-airspace-near-taiwan)**—and saw this act of war occurring while **Foreign Minister Lavrov** was **[holding meetings](https://tass.com/politics/1269143)** with his counterpart **Foreign Minister Wang Yi** in **Beijing**. 

In describing this meeting with his **Chinese** counterpart **Foreign Minister Lavrov** revealed: “**_[We discussed in detail ways of further promoting practical cooperation against the backdrop of the current epidemiological restrictions and paid special attention to preparations for top-level and high-level Russian-Chinese contacts](https://tass.com/politics/1269143)_**”—in response to **Western** sanctions against **Russia** and **China** saw him further stating: “**_[We must form a maximally wide coalition of countries that would combat this illegal practice](https://tass.com/politics/1268541)_**”—after which the official **Chinese** press office released a statement warning: “**_[The United States seeks regime change in China and Russia through color revolutions…This is why the two countries need to work together to counter US hegemony and reshape the international political system based on the principle of equality](https://tass.com/pressreview/1269137)_**”.

At his joint press conference with **Foreign Minister Wang**, it saw **Foreign Minister Lavrov** stating that “**_[the United States has declared its mission is to limit the technological development opportunities of both the Russian Federation and the People's Republic of China](https://www.rt.com/russia/518818-lavrov-china-dollar-finances/)_**”, his further saying that the two nations can shore up their economies by “**_[switching to settlements in national currencies and in world currencies, alternative to the dollar](https://www.rt.com/russia/518818-lavrov-china-dollar-finances/)_**”, with him adding that “**_[we need to move away from the use of Western-controlled international payment systems](https://www.rt.com/russia/518818-lavrov-china-dollar-finances/)_**”.

With **Deputy Foreign Minister Sergey Ryabkov** having warned last month: “**_[We need to barricade ourselves against the US financial and economic system to eliminate dependence on this toxic source of permanent hostile actions…We need to cut back the role of the dollar in any operations](https://www.rt.com/russia/516555-moscow-chinese-currency-payments/)_**”, these new moves being made by **Foreign Minister Lavrov** and **Foreign Minister Wang** to effectuate this into action by both **Russia** and **China** is sounding alarms throughout the **West**—as best exampled in the just published article “**[Biden’s Dual Assault On China And Russia May Backfire As It Is Pushing Beijing And Moscow Closer Together](https://www.rt.com/op-ed/518837-biden-assault-china-russia/)**”—and even more so in the article “**[The 'Rules-Based International Order' Is Dead & Unless West Finds New Way To Accommodate Russia & China, It Will Reap A Whirlwind](https://www.rt.com/russia/518885-international-order-west-relations/)**”, wherein it factually states:

**_The current international disorder is caused by an interregnum – the world is currently stuck between a unipolar and a multipolar format._**

**_The West is pushing for a return to the unipolar era that existed before sanctions on Russia and the economic war against China._**

**_However, the two Eurasian giants, Russia and China, have spent the past years adjusting to a multipolar system._**

**_The West will insist that on maintaining liberal hegemony due to a commitment and belief in liberal values, among elites (although that is no longer uniform), while Russia and China will reject a value-based system that is instrumental to impose an untenable unipolar order._**

**_There is no going back as the world has moved on, although the West is not yet ready to move forward._**

\[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](ssa22.jpg)

**Grim faced leaders Russian Foreign Minister Sergey Lavrov (_left_) and Chinese Foreign Minister Wang Yi (_right_) hold joint press conference in Beijing on 22 March 2021 as their nations prepare for war against West.**

According to this report, one of the main countries of the **20th Century** seeking to create by military force and economic might a unipolar world it could rule over was the **[Union of Soviet Socialist Republics](https://en.wikipedia.org/wiki/Soviet_Union)** (USSR)—that’s most commonly known today as the **Soviet Union**, but whose deranged global ambitions were thwarted by the **[Cold War](https://en.wikipedia.org/wiki/Cold_War)**—and after its socialist ideological, economic and endless war policies bankrupted the **Soviet Union**, it **[collapsed and ceased to exist on 25 December 1991](https://history.state.gov/milestones/1989-1992/collapse-soviet-union)**.

With the collapse of the **Soviet Union**, however, this report notes, the **United States** stepped right into its shoes to create a unipolar world of its own—a fact now realized by leftist **HBO** host **Bill Maher**, who took to his **Real Time** show **Friday** night **[slamming cancel culture and calling it “_So Soviet_” and “_Stalinist_” while insisting that his nation cannot live this way](https://pjmedia.com/culture/bryan-preston/2021/03/22/bill-maher-slams-stalinist-cancel-culture-n1434283)**—that was followed by famed international journalist **[Dr. Ileana Johnson Paugh](http://ileanajohnson.com/front-page/)** publishing her article “**[The Sovietization of the United States of America](https://canadafreepress.com/article/the-sovietization-of-the-united-states-of-america)**”, wherein she observes: “**_[We are being Sovietized every day in every aspect of our lives and Americans not only seem to be fine with it, they are embracing it with both glee and trepidation…The promise of everything free is too enticing to resist](https://canadafreepress.com/article/the-sovietization-of-the-united-states-of-america)_**”.

Most interesting to notice about the **Sovietization** of **America,** this report details, is that it was warned about by former top **CIA** officer and current geopolitical analyst **[Martin Gurri](https://en.wikipedia.org/wiki/Martin_Gurri)**—who in his **2014** book “**[The Revolt of The Public and the Crisis of Authority in the New Millennium](https://www.amazon.com/Revolt-Public-Crisis-Authority-Millennium/dp/1732265143)**” contended that **Western** elites are experiencing a collapse of authority deriving from a failure to distinguish between legitimate criticism and what he terms “_illegitimate rebellion_”—warned that once control over the justifying myth of **America** was lost, the mask was off—then said the disparity between the myth and public experience of it became only too evident—and warned: "**_[All over the world, elite institutions from governments to media to academia are losing their authority and monopoly control of information to dynamic amateurs and the broader public](https://www.amazon.com/Revolt-Public-Crisis-Authority-Millennium/dp/1732265143)_**”.

The critical importance of understanding **Gurri’s** contentions, this report explains, is due to his accurately describing how, unlike the **Soviet Union**, the socialist unipolar ambitions of the **United States** aren’t able to be kept hidden from view due to 21st Century social media outlets and independent news sources—and is why the **[Strategic Culture Foundation](https://www.strategic-culture.org/)** think tank cited **Gurri** in their just released document “**[Leviathan Mobilizes For Decisive Battle](https://www.zerohedge.com/geopolitical/leviathan-mobilises-decisive-battle)**”, wherein it shows how **Biden** and his socialist-globalist forces are losing their war to impose on humanity their demonic unipolar vision, **[and warns](https://www.zerohedge.com/geopolitical/leviathan-mobilises-decisive-battle)**: 

**_The plan is out of control, and becoming progressively more bizarre._**

**_The American unipolar moment is ‘done’.  It has created oppositions of various kinds, both abroad and at home._**

**_Conservative and traditional impulses have reacted against the radical ideological agenda, and crucially, the 2008 Financial Crisis and near collapse of the system foretold to the élites of the ultimate coming end to the U.S.’ financial hegemony, and concomitantly to America’s primacy. It forced a critical juncture._**

**_Now they are at a crucial impasse._**

**_When they speak about Re-set, this means a forced return to the continuation of the agenda._**

**_But it is not as straight-forward as it seems._**

**_Everything seemed almost primed to fall into place twenty years ago; yet now, the Establishment is having to fight for every element of this strategy because everywhere they encounter a growing resistance._**

 **_And it is no insignificant resistance.  In America alone, some 74 million Americans reject the cultural war being waged on them._**

**_The globalist call to arms is evident.  The world clearly has changed during the last four years._**

**_Globalist forces, therefore, are being mobilised to win a last battle in the ‘long-war’ – looking to break-through everywhere._**

**_Defeating Trump is the first goal.  Discrediting all varieties of European populism is another._**

**_The U.S. thinks to lead the maritime and rim-land powers in imposing a searing psychological, technological and economic defeat on the Russia-China-Iran alliance._**

**_In the past, the outcome might have been predictable._**

**_This time Eurasia may very well stand solid against a weakened Oceana (and a faint-hearted Europe)._**

**_It would shake Leviathan to its foundations.  Who knows what might then emerge from the ruins of post-modernity._**

![](ssa21.jpg)

With it being observed that “**_[nothing has been done since the Iraq invasion to keep the US government from deceiving Americans into war again](https://www.rt.com/op-ed/518835-caitlin-johnstone-iraq-invasion/)_**”, this report concludes, this observation couldn’t be timelier as **[“_woke_” neocon imperialist Bill Kristol is now urging socialist leader Biden to invade Cuba and take it over with military force](https://www.rt.com/usa/518860-bill-kristol-cuba-state/)**—though in reality, this is about the only country **Biden** can take on after the **American** think tank **[Defense Priorities](https://www.defensepriorities.org/)** issued its report “**[US Officials Who Are Ready To Fight China Over Taiwan Don't Understand How Much Is At Stake](https://www.businessinsider.com/us-war-with-china-over-taiwan-would-be-foolish-costly-2021-3)**”, wherein it warns:

**_Many of America's leading military and political figures have issued increasingly alarmist warnings in recent days about the potential for conflict with China, especially related to issues surrounding Taiwan._**

**_But before the US gets into a crisis that brings it to the threshold of war —_** **_or finds itself stumbling into one_** **_— policymakers and military leaders need to address some hard realities._**

**_There is almost no scenario in which the United States can successfully intervene in a war between China and Taiwan that will not leave our country in far worse shape than it is right now; in a worst-case scenario, American territory could be struck by nuclear missiles._**

![](ssa23.jpg)

March 23, 2021 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Americans Need To Remember That Tyranny Is An Illusion—And Qatar Is Helping Them](https://www.whatdoesitmean.com/index3491pl.htm)**

**[American People Are Winning A War They Don't Even Know They're Fighting](https://www.whatdoesitmean.com/index3491.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/index.htm)**