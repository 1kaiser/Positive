        Trump Sanctions “Death Blow” Begins Slow Agonizing Destruction Of NATO Military Alliance  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

December 21, 2019

**Trump Sanctions “_Death Blow_” Begins Slow Agonizing Destruction Of NATO Military Alliance**

By: Sorcha Faal, and as reported to her Western Subscribers

An intriguing new **Ministry of Foreign Affairs** ([MoFA](http://government.ru/en/department/92/events/)) report circulating in the **Kremlin** today states that within a few hours of **Vice-President of the European Commission [Maros Sefcovic](https://ec.europa.eu/commission/commissioners/2019-2024/sefcovic_en)** celebrating the agreement on gas transit reached between **Russia** and **Ukraine** yesterday that he said “**_[assures Russia will remain a reliable gas supplier to European markets](https://tass.com/economy/1101937)_**”, **President Donald Trump** signed into law a **[new $738 billion defense budget](https://tass.com/world/1101947)** that he allowed his socialist **Democrat Party** enemies to insert into crushing sanctions against the **[Nord Stream 2](https://www.nord-stream2.com/project/rationale/)** gas pipeline project—sanctions so severe it caused the **Swiss-Dutch** company **[Allseas](https://allseas.com/)** this morning to **[immediately cease its work](https://www.rt.com/business/476541-nordstream-sanctions-bill-pipeline/)** on this **745-mile-long** twin pipeline that will carry up to **55 billion** cubic meters (**_1.942 trillion cubic feet_**) of gas per year from **Russia** to **Germany** through the territorial waters or exclusive economic zones of **Denmark**, **Finland**, **Germany**, **Russia** and **Sweden**—which, in turn, caused **[Germany to erupt in outrage](https://sputniknews.com/analysis/201912201077687884-us-sanctions-on-nord-stream-2-leave-germany-in-uproar-still-cannot-stop-russian-project/)** and brand these **US** sanctions as an “**_[interference in domestic affairs](https://www.rt.com/news/476549-germany-responds-nordstream-sanctions/)_**”, with Germany’s Chancellor Angela Merkel further vowing that her nation “**_[won’t back down](https://www.rt.com/news/476192-merkel-nord-stream-sanctions/)_**”—but is a pipeline **[these US sanctions can’t stop](https://sputniknews.com/analysis/201912201077687884-us-sanctions-on-nord-stream-2-leave-germany-in-uproar-still-cannot-stop-russian-project/)** as **Nord Stream 2** administrators vowed that “**_[the companies committed to the project will be working to complete it as soon as possible](https://sputniknews.com/world/201912211077699590-nord-stream-2-ag-vows-to-continue-working-with-partners-to-complete-pipeline-as-quickly-as-possible/)_**”—the most important of them being **Russian** gas giant **[Gazprom](https://www.gazprom.com/)**, who is now preparing to lay pipeline for the one last stretch of **Nord Stream 2** near the **Danish** island of **Bornholm** still to be covered that **Allseas** just abandoned—a reality admitted to by retired former **American** diplomat **[Jim Jatras](https://twitter.com/JimJatras?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor)** with his stating” “**_[Nord Stream 2 will be completed...this latest round of sanctions and this cessation of workers is a hiccup...It will be finished and will go into operation](https://www.rt.com/news/476542-nordstream-jatras-sanctions-us/)_**”—all of which appears to make nonsensical what **Trump** is trying to achieve with these sanctions—that is until one notices that this now signed into law **US** defense budget also **[contains crushing sanctions on the Turkish Stream gas pipeline from Russia to Turkey](https://www.euractiv.com/section/energy/news/us-readies-sanctions-against-nord-stream-2-and-turkish-stream/)**, as well as its **[containing further sanctions against Turkey for its purchasing of the Russian S-400 missile defense system](https://ahvalnews.com/us-turkey/trump-signs-defence-spending-bill-imposing-sanctions-turkey)**—sanctions that **Turkish** **President Tayyip Erdogan** has **[vowed to retaliate against](https://www.reuters.com/article/us-turkey-usa-sanctions/erdogan-says-turkey-will-retaliate-against-possible-u-s-sanctions-idUSKBN1YO19F)** exactly like **German** leader **Merkel** has declared she intends on doing, too—with the most important aspect of what **Trump** is doing against both **Germany** and **Turkey** is able to be fully understood by one’s noticing that they are both **[two of the most powerful members of the NATO alliance](https://www.globalfirepower.com/countries-listing-nato-members.asp)**—a **Western** military alliance **[said in 2013 had no actual purpose](https://www.forbes.com/sites/dougbandow/2013/04/22/natos-lack-of-any-serious-purpose-means-it-should-retire/#23f2cca15c8a)** and that **Trump** has railed against, most particularly **German**y whom he branded as “**_[NATO’s biggest freeloader](https://www.washingtonpost.com/)_**”—and by **Trump** having just become the first **American** leader in history to attack two of **NATO’s** most powerful member states with crushing sanctions, surprisingly sees only former **Vice President Joe Biden** sounding the alarm about what **Trump’s** endgame is with his warning “**_[If Trump gets re-elected, there will be no more NATO](https://www.realclearpolitics.com/video/2019/07/05/biden_if_trump_gets_re-eleted_there_will_be_no_nato_in_five_years.html)_**”.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](mer22.jpg)

**President Donald Trump told the American people during his 2016 campaign that NATO was obsolete—they then voted him into power.**

According to this report, still not being understood by large masses of the **American** people is that **President Trump** is a **_realpolitik_** leader—which is a system of politics or principles based on practical rather than moral or ideological considerations, and because of which threw him into the raging “**_[international polarity](https://en.wikipedia.org/wiki/Polarity_(international_relations))_**” battle of what kind of nation the **United States** will be for the remainder of the **21st Century**—the choices of which could see **America** trying to remain a “**_unipolar_**” nation and rule over the rest of the world with brute military and economic force—or its transitioning to a distributed power “**_multipolar_**” nation in which more than two nation-states have nearly equal amounts of military, cultural, and economic influence.

As one would expect from a realpolitik leader, this report notes, **President Trump** first explained his vision of the **United States** transitioning to a “**_multipolar_**” role with an “**_America First_**” agenda before he was elected to power—an agenda that would see **Trump** ending his nation’s endless wars, while at the same time making his military forces near impregnable, and also at the same time, creating a low tax and regulation atmosphere to entice companies that had left **America** to return home—and not really caring what the rest of the world did, as long as they left the **US** alone.

![](mer23.png)

**President Donald Trump gave fair warning before he was elected that he would transition the United States to a multipolar nation.**

Having given fair warning before he was elected that he would begin the transition of the **United States** into a multipolar nation, this report continues, **President Trump** was confronted with an entire government structure embedded with entrenched unipolar policy and decision making bureaucrats continuously shuttling themselves through revolving doors that took them from their **US** government agencies into socialist-globalist institutions such as the **United Nations**, **World Bank** and **International Monetary Fund**—all of which have ceased to function in the multipolar world fast emerging around them—and because of, has seen **Trump** both **[attacking them and eliminating their global power](https://www.washingtonpost.com/)**.

![](mer24.jpg)

The past nearly three years wherein **President Trump** has systematically waged his unrelenting war on unipolar socialist-globalist ideologies to transition the **United States** into a multipolar nation, this report details, has seen countless attacks being launched to overthrow him failing—most occurring at the start of this conflict when he tried to work within the structure of his government—but following, and as it’s been **[most astutely analyzed](https://www.zerohedge.com/political/everything-you-need-know-about-trump-were-afraid-admit-you-wondered)**:

**_That’s when his genius exploded on the world._**

**_He completely changed his strategy and approach, and started taking absurd decisions and tweeting outrageous declarations._**

**_As threatening and dangerous as some of these first looked, Trump didn’t use them for their first degree meaning, but was_** **_aiming at the genuine second degree effects that his moves would have_****_._**

**_And he didn’t care about what people thought of him as he did, for only results count in the end.   He would even play buffoon over Twitter, look naive, lunatic or downright idiotic, perhaps in the hope to impregnate the belief that he didn’t know what he’s doing, and that he couldn’t be that dangerous._**

**_He’s willfully being politically incorrect to show the ugly face that the United States are hiding behind their mask._**

![](mer25.jpg)

As the **American** people settle in for the **Christmas Holiday** season, this report concludes, it would be wise for all of them to spend this time reflecting on the deeper true issues surrounding **President Trump** and what he’s doing instead of having their attentions distracted into leftist political and media trivialities that melt like snow—most particularly because **Trump** is a **[genuine historic anomaly](https://www.zerohedge.com/political/everything-you-need-know-about-trump-were-afraid-admit-you-wondered)** none of these peoples will ever see the likes of for the remainder of their lives—and about whom it’s well advised to know about, as in seeing the truth shows the future soon to come—and as it’s, perhaps, been **[best observed](https://www.zerohedge.com/political/everything-you-need-know-about-trump-were-afraid-admit-you-wondered)**:   

**_For those who still entertain doubts about Trump’s agenda, do you really believe that the obvious implosion of American Imperialism over the planet is a coincidence?_**

**_Do you still believe that its because of the Russian influence on the 2016 election that the CIA, the FBI, every media, the American Congress, the Federal Reserve, the Democratic party and the warmongering half of the Republicans are working against him and are even trying to impeach him?_**

**_Like most stuff that comes out of medias,_** **_reality is the exact opposite of what you’re being told_****_: Trump might be the most dedicated man to ever set foot in the Oval office._**

**_And certainly the most ambitious and politically incorrect._**

**_The world will change drastically between 2020 and 2024._**

**_Trump’s second and last mandate coincides with Putin’s last mandate as President of Russia._**

**_There may never be another coincidence like this for a long time, and both know that it’s now or perhaps never._**

**_Together, they have to end NATO, Swift, and the European Union should crumble._**

**_Terrorism and anthropogenic global warming will jump in the vortex and disappear with their creators._**

**_Trump will have to drain the swamp in the CIA and Pentagon, and he has to nationalize the Federal Reserve._**

**_Along with Xi and Modi, they could put a final end to private banking in public affairs, by_** **_refusing to pay a single penny of their debts_****_, and_** **_reset the world economy_** **_by shifting to national currencies produced by governments, as private banks will fall like dominos, with no more Obama-like servant to bail them out at your expense._**

**_Once this is done,_** **_unbearable peace and prosperity could roam the planet_****_, as our taxes pay for the development of our countries instead of buying useless military gear and paying interests on loans by bankers who didn’t even have the money in the first place._**

![](mer21.jpg)

December 21, 2019 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Lincoln Jailed Over 13,000 Journalists—Roosevelt Went Around Them—Now Trump Presides Over Their Destruction](https://www.whatdoesitmean.com/index3055pl.htm)**

**[Great American Balloon Panic Of 2019 Initiates Destruction Of The Republic](https://www.whatdoesitmean.com/index3055.htm)**

**[Blood vs. Ballot Box: America Sets Itself On Civil War Collision Course](https://www.whatdoesitmean.com/index3022pl.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**