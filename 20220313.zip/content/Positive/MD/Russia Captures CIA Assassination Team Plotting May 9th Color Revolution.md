        Russia Captures CIA Assassination Team Plotting May 9th Color Revolution  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

**[What You Aren’t Being Told About The World You Live In](https://www.whatdoesitmean.com/)**

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](https://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

April 18, 2021

**Russia** **Captures CIA Assassination Team Plotting May 9th Color Revolution**

By: Sorcha Faal, and as reported to her Western Subscribers

A highly-classified “**_[Of Special Importance](https://fas.org/irp/world/russia/class.htm)_**” new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today first noting that **Ukraine’s Charge D’Affaires Ad Interim Vasily Pokotilo** has **[been informed](https://tass.com/russia/1279391)** about the decision to expel **Ukrainian Consul in St. Petersburg Alexander Sosonyuk** from the **Russian Federation** after the **Federal Security Service** ([FSB](http://government.ru/en/department/113/)) **[caught him red-handed attempting to buy from an undercover FSB female counterintelligence officer an archived KGB video recording showing a drunken US Senator Joe Biden urinating on a prostitute at a Moscow hotel when he visited to the Soviet Union 1979](https://www.whatdoesitmean.com/index3541.htm)**, says following this expulsion notification the **Ukrainian Foreign Ministry** issued a notice stating: “**_[A senior diplomat of the Russian Embassy in Kiev must leave Ukraine within 72 hours, starting 19 April...We strongly protest against the unlawful detention of an employee of Ukraine’s Consulate General in St. Petersburg on 16 April and against ordering him to leave Russia...We totally exclude the charges pressed against the consular officer…Those actions of the Russian authorities grossly violate the Vienna Convention on Diplomatic Relations of 1961 and the Vienna Convention on Consular Relations of 1963 and again prove the policy of further aggravation with Ukraine chosen by Russia](https://tass.com/world/1279421)_**”.

A defiant **Ukrainian** reaction coming **48-hours** after **Supreme Socialist Leader Joe Biden** **[abruptly ordered US Navy warships not to enter the Black Sea and threaten Russia](https://www.aljazeera.com/news/2021/4/15/us-cancels-warships-deployment-to-black-sea-turkish-officials)**—an abrupt turnabout preceded by **President Putin** **[accepting an unscheduled phone call](https://www.whatdoesitmean.com/index3538.htm)** from **Biden**—during this call saw **President Putin** not only warning **Biden** that any **US** warships entering the **Black Sea** would be in grave danger of being destroyed by **Russian** naval forces and should “**_[stay away for their own good](https://news.yahoo.com/russia-warns-u-warships-steer-083654350.html)_**”—then saw **President Putin** further warning **Biden** to “**_tread carefully_**” as the **FSB** knew exactly what the **CIA** was plotting.

A warning not heeded by socialist leader **Biden**, as evidenced by him **[persuading his British ally to announce that warships from the UK Royal Navy will sail for the Black Sea in May in solidarity with Ukraine](https://sputniknews.com/world/202104181082659988-uk-warships-to-sail-for-black-sea-in-may-to-show-solidarity-with-kiev-nato-allies---report/)**—that caused **President Putin** to retaliate by authorizing the **FSB** to begin the immediate arrest of known **CIA** operatives and release the restricted press announcement “**[THE FSB OF RUSSIA TOGETHER WITH THE KGB OF THE REPUBLIC OF BELARUS SUPPRESSED THE ILLEGAL ACTIVITIES OF CITIZENS OF THE REPUBLIC OF BELARUS ZYANKOVICH YURI LEONIDOVICH AND FEDUTA ALEXANDER IOSIFOVICH, WHO WERE PLANNING A MILITARY COUP IN BELARUS](http://www.fsb.ru/fsb/press/message/single.htm%21id%3D10439220%40fsbMessage.html)**” \[**[English](https://translate.google.com/translate?hl=en&sl=auto&tl=en&u=http%3A%2F%2Fwww.fsb.ru%2Ffsb%2Fpress%2Fmessage%2Fsingle.htm%2521id%253D10439220%2540fsbMessage.html)**\]—wherein it beyond shockingly reveals: 

**_The Federal Security Service of the Russian Federation, together with the State Security Committee of the Republic of Belarus, as a result of a special operation, suppressed the illegal activities of_** **_Yuri Leonidovich Zyankovich, who has dual citizenship of the United States and the Republic of Belarus_****_, and Alexander Iosifovich Feduta, a citizen of the Republic of Belarus, who were planning to carry out a military coup in Belarus according to a worked-out scenario of “_****_color revolutions_****_” with the involvement of local and Ukrainian nationalists, as well as_** **_the physical elimination of President A. Lukashenko_****_._**

**_According to the preemptive information received from the Belarusian partners, in the private chats of one of the Internet messengers, the ideologues of the Belarusian radical opposition Zyankovich Y. and Feduta A. organized a discussion of the plan for an armed insurrection in Belarus and decided to hold a personal meeting in Moscow using the measures of secrecy available to them with opposition-minded generals of the Armed Forces of the Republic._**

**_Upon Ziankovich's arrival in Moscow,_** **_after consultations in the United States and Poland_****_, the scheduled meeting took place in a separate office of one of the capital's restaurants._** 

**_During the meeting, the conspirators told the “Belarusian generals” that for the successful implementation of their plan, it was necessary to physically eliminate practically the entire top leadership of the republic._**

**_They detailed the plan for a military coup, in particular, including the seizure of radio and television centers to broadcast their appeal to the people, blocking the internal troops and riot police units loyal to the current government in the capital of the republic.  A complete shutdown of the power system of Belarus was being prepared to hinder the actions of power and law enforcement agencies.  It was assumed that some armed formations (“partisans”) located on the so-called “Hidden bases”._**

**_The ultimate goal was to change the constitutional order with the abolition of the presidency and the imposition of the country's leadership on the “Committee of National Reconciliation”.  At the same time,_** **_Zyankovich_** **_planned to become the “curator” of the country's parliament and the legal system_****_, while Feduta wanted to engage in political reform and ideological work._**

**_It is noteworthy that the oppositionists have chosen the day of the Victory Parade in Minsk on May 9th this year as the date of the military coup._**

**_After documenting the meeting, the conspirators were detained by the Russian security forces and handed over to their Belarusian partners._**

**_In relation to Zyankovich and Feduta, the investigative bodies of Belarus are investigating a criminal case on the grounds of a crime under Article 357 (conspiracy or other actions committed with the aim of seizing state power) of the Criminal Code of the Republic of Belarus._**

With shocking articles like “**[US-Backed Coup Plot Involving Assassination Of Belarusian President, Other Officials Foiled By Minsk & Moscow](https://www.rt.com/russia/521391-belarus-lukashenko-assassination-plot/)**” flooding the world at this hour, not being under the constraints imposed on **Security Council Members** by strict **Russian** secrecy laws involving highly-classified operations such as this, **Belarus President Alexander Lukashenko** was able to inform his nation’s citizens that this demonic colour revolution assassination plot to murder top officials and all of their family members was “**_[definitely the work of foreign intelligence…most likely the CIA or the FBI](https://www.rt.com/russia/521391-belarus-lukashenko-assassination-plot/)_**”—then saw him **[further stating](https://tass.com/world/1279437)**: 

**_Agents flew from the United States, operative Zenkovich._**

**_We were trailing and watching them._**

**_They were scared to come here after we detained several groups that had brought arms here and hidden them in caches._**

**_They left for Moscow.  And who else?  It was ours, Feduta._**

**_Then we started to look around, Kostusev appeared there but to a less extent.  He was not in Moscow, we found him here along with others._**

**_Another thing that surprises me is why Americans behave like this.  Remember that no one except the top political leadership can set the task of getting rid of a president. Only them, not the special services._**

**_I'll tell you more. I am grateful to Putin._**

**_When he was talking with Biden, he asked him this question.  Biden just gurgled and gave no answer._**

**_Putin called me and told me about this when I arrived from Azerbaijan._**

\[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](bbp21.jpg)

**Belarus** **President Alexander Lukashenko outside his residence in Minsk carrying assault rifle (_above center_) on 18 April 2021 after FSB smashes CIA color revolution assassination coup plot against him.**

![](bbp22.jpg)

**Gurgling Biden remains a very, very dangerous socialist idiot.**

April 18, 2021 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[The Watchers Have Arrived—And America Will Never Be The Same](https://www.whatdoesitmean.com/index3518pl.htm)**

**[God Is Playing Games With Biden—History Shows This Won't End Well](https://www.whatdoesitmean.com/index3518.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/index.htm)**