        You Are Living In A Fool’s Paradise—Enjoy It While It Lasts <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**You Are Living In A Fool’s Paradise—Enjoy It While It Lasts**

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“A fool's paradise is a wise man's hell.”_**

[Thomas Fuller](https://en.wikipedia.org/wiki/Thomas_Fuller)  (1608-1661)—English churchman and historian best remembered for his writings, particularly his Worthies of England, published in 1662, after his death.

 **Special Report from Sister Ciara**

**My Dearest Friends:**

For those of you new to our site, our mission and what we do, let me first explain that we don’t write **[news articles](https://en.wikipedia.org/wiki/Article_(publishing))**—which are writings having a defined structure designed to relay topical information, most frequently about current and breaking events.

What we do is create **[intelligence reports](https://www.thefreedictionary.com/intelligence+report)**—which is a specific report of information, usually on a single item, are made at any level of command in tactical operations and disseminated as rapidly as possible in keeping with the timeliness of the information—is called an **INTREP**—are produced by others, like the world’s leading private geopolitical platform **[Stratfor](https://www.stratfor.com/world-s-leading-geopolitical-intelligence-platform)** (aka “**_[Shadow CIA](https://www.helsinkitimes.fi/world-int/1619-stratfor-the-shadow-cia-2.html)_**”)—and one of whose most famous ones is the **Daily Presidential Briefing** ([PDB](https://www.intelligence.gov/publics-daily-brief/presidents-daily-brief)) written by the **Office of the Director of National Intelligence** ([ODNI](https://www.dni.gov/)). 

The three critical components in creating an **INTREP** are: **1.)** **Context**…the circumstances, both current and historical, that form the setting for an event, statement, or idea, and in terms of which it can be fully understood and assessed—**2.)** **Assessment**…the evaluation or estimation of the nature, quality, or ability of someone or something—**3.)** **Theory**…a supposition or a system of ideas intended to explain something, especially one based on general principles independent of the thing to be explained.

In the aftermath of **[President John F. Kennedy](https://en.wikipedia.org/wiki/John_F._Kennedy)** being assassinated on **22 November 1963**, too many to count private intellignece organizations and think tanks, from all around the world, created enough **INTREP’s** to fill a large library—all of which followed the rules for such reports and contained **context**, **assessments** and **theories**—all of whose **theories** in these **INTREP’s** factually, historically and contextually disputed the “**_official_**” narrative—and in response to, saw **[the CIA fighting back and ordering the American mainstream media to append to all of these independent theories with the word “_conspiracy_”](https://stateofthenation2012.com/?p=14945)**.

By having the mainstream **American** media append the word “**_conspiracy_**” to every independent **INTREP** involving the assassination of **President Kennedy**, it gave the **CIA** an additional **13-years** to complete the cover-up of what really happened—a fact documented by the **[United States House Select Committee on Assassinations](https://en.wikipedia.org/wiki/United_States_House_Select_Committee_on_Assassinations)**, that, in **1976**, saw it **[concluding it was probable that 4 shots were fired at President Kennedy by at least 2 gunmen](https://en.wikipedia.org/wiki/United_States_House_Select_Committee_on_Assassinations#Conclusions_regarding_the_Kennedy_assassination)**—which is the exact theory reached by the independent **INTREP’s** created over a decade earlier, whose assessments all agreed that it was impossible for this assassination to have been carried out by a single gunmen—all of which further warned that if an immediate investigation wasn’t carried out evidence would disappear and witnesses be killed and/or silenced—**[and is exactly what happened](https://spartacus-educational.com/JFKdeaths.htm)**.    

![](ycc23.jpg)

Unlike **news articles** you read, an **INTREP** must contain documented and verifiable information relating to all sides of an event and/or issue—which is why in our reports the facts are cited and linked to, with a vast number of them being from leftist propaganda mainstream media sources, like the **New York Times** and **Washington Post**—and in whose writings can always be glimpsed what these godless monsters are thinking and planning.

For example, every week I am following with great interest the writings of **[Thomas Friedman](https://en.wikipedia.org/wiki/Thomas_Friedman)**, the **Pulitzer Prize** winning weekly columnist for the **New York Times**—sees **Pulitzer Prize** winning independent investigative journalist **Glenn Greenwald** saying about **Friedman**: “**_[His status among American elites is the single most potent fact for understanding the nation's imperial decline](https://www.salon.com/2012/07/25/the_value_of_tom_friedman/)_**”—which is why every alarm bell in me went off this week when **Friedman** published his weekly article on **Tuesday** entitled “**[Want to Get Trump Re-elected? Dismantle the Police](https://www.nytimes.com/2021/06/22/opinion/gop-democrats-defund-police-voting.html)**”, wherein among his usual leftist dribble he buried the warning: “**_[Just beneath the surface calm in America, volcanic forces are gathering that could blow the lid off our democracy…We are living in a fool’s paradise…Enjoy it while it lasts](https://www.nytimes.com/2021/06/22/opinion/gop-democrats-defund-police-voting.html)_**”.

What made these alarm bells go off inside of me was because while I was reading **Friedman’s** warning about these “**_gathering volcanic forces_**”, I received an urgent message about a **NOTAM** (**Notice To Airmen**) alert placing temporary flight restrictions around **Gulkana-Alaska** where the **HAARP** (**short for High-Frequency Active Auroral Research Program**).facility is located, **[and which reads](https://www.zerohedge.com/political/haarp-firing-faa-issues-warning-about-electromagnetic-radiation)**:

**FDC 1/6022 ZAN AK..AIRSPACE GULKANA, AK..TEMPORARY FLIGHT RESTRICTIONS WI AN AREA DEFINED AS 2.5NM RADIUS OF 622333N1450902W (GKN007016.6) SFC-FL250 FOR ELECTROMAGNETIC RADIATION FR SCIENTIFIC RESEARCH. PURSUANT TO 14 CFR SECTION 91.137 (A)(1) TEMPORARY FLIGHT RESTRICTIONS ARE IN EFFECT. TRANSIT THRU THE AIRSPACE MAY BE AUTH BY HAARP COMMAND CENTER, TEL 907-822-5497 OR FREQ 123.3. ANCHORAGE /ZAN/ ARTCC TEL 907-269-1103 IS THE FAA CDN FACILITY. DLY 0400-1730 2106210400-2106251730**

What makes this **NOTAM** so alarming is that **[the US Air Force notified the US Congress it was shutting HAARP down in 2014](https://www.livescience.com/45829-haarp-shutdown.html)**—was a shutdown preceded by the late **Venezuelan President Hugo Chavez** **[declaring that HAARP was a tectonic weapon used to cause the catastrophic earthquake that destroyed Haiti](https://www.livescience.com/8071-chavez-tectonic-weapon-caused-haiti-quake.html)**—an accusation that was followed by **President Chavez** **[announcing he had cancer](https://en.wikipedia.org/wiki/Hugo_Ch%C3%A1vez#Illness)**, and saw him dying of this **[disease on 5 March 2013](https://en.wikipedia.org/wiki/Hugo_Ch%C3%A1vez#Illness)**.

With this **NOTAM** for **HAARP** **[being in force from 21-25 June](https://www.zerohedge.com/political/haarp-firing-faa-issues-warning-about-electromagnetic-radiation)**, and based on my knowledge of what this facility is capable of, I can honestly tell you I wasn’t surprised this morning when I received another urgent message about a small seismic event that occurred in **Miami-Florida**—an urgent message that was followed by news reports saying that at **[about 1:20 a.m this early morning in Miami](https://www.foxnews.com/us/surfside-florida-apartment-partially-collapses-emergency-crews-at-scene)**, witnesses reported “**_[suddenly hearing what sounded like a tornado or earthquake](https://www.foxnews.com/us/surfside-florida-apartment-partially-collapses-emergency-crews-at-scene)_**”—reports that were soon followed by the news that a **[luxury multi-story at 8777 Collins Avenue had collapsed](https://www.foxnews.com/us/surfside-florida-apartment-partially-collapses-emergency-crews-at-scene)**—and is a building **[one block away from where Ivanka Trump and Jared Kushner are leasing a condominium](https://www.wsj.com/articles/ivanka-trump-and-jared-kushner-lease-miami-condo-following-their-32-million-deal-on-indian-creek-11611095043)**.

![](ycc26.png)

![](ycc25.jpg)

![](ycc24.jpg)

**Was HAARP earthquake weapon activated (_top photo NOTAM alert_) to target Ivanka Trump and her husband Jared Kushner at their home in Miami-Florida (_second photo_), but missed and struck building one block away (_bottom photo_)?**

In creating an **INTREP** about this event (**_and believe me, they’re already being compiled by intelligence agencies the world over_**), the historical **context** about **HAARP**, along with an **assessment** of its mysterious activities, most certainly leads to a valid **theory** being made that the daughter and son-in-law of **President Donald Trump** are being targeted for death—but most importantly for you to know, is only a **_theory_**, not a conclusion—and as such, when included in any **INTREP**, means only that this **_theory_** has some validity making it worthy of further investigation.

Of course, and as always, any such **_theory_** like this will be immediately appended by the word “**_conspiracy_**” by every leftist mainstream propaganda media outlet and official government statement—which makes it prescient that the **Sorcha Faal** sent us **Sisters** the following message yesterday:

**_“We live in a world today where you can access information from all over the world on a device that you can hold in your hand._** 

**_But, how good is that information?_**

**_If you spend any amount of time researching current events using any search application, you are already aware that entering a particular word or phrase can return multiple articles from apparently different news sources that are exactly the same._** 

**_Most of them do not even bother to change the title of the article, and even if they do, the content is the same - and therefore all of the news providers that are listed in your search results are obtaining their information from one single source._**

**_In addition, the search engine that you are using is a very complex, scripted query generator that skews the list returned to you by parameters in the query program, which are inaccessible to you, that will exclude certain content from the search results, and prioritize the approved web sites presented in the results, and also file your identity and your query for future law enforcement use if it contains evidence of unapproved thought._**

**_So, who exactly is making Fake News?_** 

**_Is it us, who specifically state that we are a conspiracy theory site, provide our readers with articles that link to source and reference materials, and always expect our readers to make their own judgments on the material?_**

**_Or is it the establishment media, who bury inconvenient but true news, repeat stories that have been proven false, and use censorship to supress the "unapproved" feedback from their viewers?”_**

I have no doubt at all in my mind that **New York Times** columnist **Thomas Friedman** told the truth from his elite socialist pedestal that “**_volcanic forces are gathering_**”, which is why he warned his fellow comrades “**_We are living in a fool’s paradise…Enjoy it while it lasts_**”—a “**_fools paradise_**” that’s defined as a state of enjoyment based on false beliefs or hopes; a state of illusory happiness—and my two favorite quotes about come from famed **British** polymath **[Bertrand Russell](https://en.wikipedia.org/wiki/Bertrand_Russell)**, one of the early **20th Century's** most prominent logicians who said: “**_Do not feel envious of the happiness of those who live in a fool's paradise, for only a fool will think that it is happiness_**”, and **English** historian **[Thomas Fuller](https://en.wikipedia.org/wiki/Thomas_Fuller)**, who pointed out the truth that: “**_A fool's paradise is a wise man's hell_**”.

Finally for you to notice is that **Friedman** wouldn’t have sounded this warning unless he knew his side was losing this war—is a losing side becoming more desperate by the hour—and is losing because **YOU** continue to support us, and those like us, who keep searching for and revealing the truths being kept hidden—but whose cost to those of us dwindling few remaining in this fight are as staggering as they are crushing—which is why I’ll leave you today with the same words I imparted to you when we met last month, and are even more important for you to hear and heed right now:

**In the coming months, the dimensions of this looming war are going to shift in radical and unforeseen ways—which is why we believe it is your right to know the full truth about what is happening—a truth the demonic enemies of humanity and our** **God** **are doing everything in their power to suppress—which is why our** **Dear Lord** **ordered us to band together in such times as these to protect one another—a protection we urgently need at this very moment to keep the truth flowing to you—and in aiding us, our** **Dear Lord** **has promised you: “****_[Give, and it will be given to you. A good measure, pressed down, shaken together and running over, will be poured into your lap. For with the measure you use, it will be measured to you.](https://dailyverses.net/giving)_****”**

With God,

Sister Ciara

Dublin, Ireland

24 June 2021

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s June, 2021/July, 2021 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 111”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/)

[](https://www.whatdoesitmean.com/indexnews.htm)