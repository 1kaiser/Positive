        Putin Weighs Three Options: War, Permanent Tension, Or, Just Smile And Wave  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Georgia; panose-1:2 4 5 2 5 4 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; panose-1:2 2 6 2 8 5 5 2 3 3; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

**[What You Aren’t Being Told About The World You Live In](https://www.whatdoesitmean.com/)**

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](https://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

February 2, 2022

**Putin Weighs Three Options: War, Permanent Tension, Or, Just Smile And Wave**

By: Sorcha Faal, and as reported to her Western Subscribers

An enlightening new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today first noting **President Putin** **[warning](https://www.rt.com/russia/548013-putin-reason-war-nato/)** that a potential **NATO** membership would see **Ukraine** “**_[filled chock-full](https://www.rt.com/russia/548013-putin-reason-war-nato/)_**” with arms could prompt **Kiev** to proceed with its plan to start a military “**_[operation](https://www.rt.com/russia/548013-putin-reason-war-nato/)_**” in **Crimea**, a sovereign territory of the **Russian Federation** that **Moscow** **[would then be bound to respond to](https://www.rt.com/russia/548013-putin-reason-war-nato/)**, says to avert such a catastrophe **Russia** presented proposed security guarantee agreements to both the socialist **Biden Regime** and its **NATO** military bloc—but in whose replies **President Putin** revealed: “**_[Let me note that we are closely analyzing the written responses received from the United States and NATO on 26 January…However, it is already clear, and I informed Mr. Prime Minister about it, that the fundamental Russian concerns were ignored](https://tass.com/world/1396205)_**”.

The **Biden Regime** and **NATO** answers to the two proposals “**[Treaty Between the United States of America and the Russian Federation on Security Guarantees](https://mid.ru/ru/foreign_policy/rso/nato/1790818/?lang=en)**” and “**[Agreement on Measures to Ensure the Security of the Russian Federation and Member States of the North Atlantic Treaty Organization](https://mid.ru/ru/foreign_policy/rso/nato/1790803/?lang=en&clear_cache=Y)**”, this report notes, were **[leaked](https://english.elpais.com/usa/2022-02-02/us-offers-disarmament-measures-to-russia-in-exchange-for-a-deescalation-of-military-threat-in-ukraine.html)** this morning to the **Spanish** newspaper **[EL PAÍS](https://english.elpais.com/)**, that **[posted a direct link to these restricted documents](https://elpais.com/infografias/2022/02/respuesta_otan/respuesta_otan_eeuu.pdf)**—and in response to the leaking of these restricted documents top **Kremlin** spokesman **Dmitry Peskov** stated to questioning journalists: “**_[We did not publish anything and I do not want to comment on it…You need to address the newspaper or the Spanish government, at least not to us…We have, of course, seen the publication…Yesterday, President Putin gave a general conceptual assessment of the answers received in the part that concerns fundamentally important issues for Russia](https://sputniknews.com/20220202/us-nato-told-russia-they-are-refraining-from-deploying-nukes-in-eastern-europe-spanish-media-says-1092677026.html)_**”.

In a direct letter sent to all of the heads of these warmongering **Western** governments yesterday, this report continues, **Foreign Minister Sergey Lavrov** **[stated](https://mid.ru/en/foreign_policy/news/1796679/)**: 

**_You are well aware that Russia is seriously concerned about increasing politico-military tensions in the immediate vicinity of its western borders._**

**_With a view to avoiding any further escalation, the Russian side presented on 15 December 2021 the drafts of two interconnected international legal documents – a Treaty between the Russian Federation and the United States of America on Security Guarantees and an Agreement on Measures to Ensure the Security of the Russian Federation and Member States of the North Atlantic Treaty Organization._**

**_The U.S. and NATO responses to our proposals received on 26 January 2022 demonstrate serious differences in the understanding of the principle of equal and indivisible security that is fundamental to the entire European security architecture._**

**_We believe it is necessary to immediately clarify this issue, as it will determine the prospects for future dialogue._**

**_The Charter for European Security signed at the OSCE Summit in Istanbul in November 1999 formulated key rights and obligations of the OSCE participating States with respect to indivisibility of security._**

**_It underscored the right of each participating State to be free to choose or change its security arrangements including treaties of alliances, as they evolve, as well as the right of each State to neutrality._**

**_The same paragraph of the Charter directly conditions those rights on the obligation of each State not to strengthen its security at the expense of the security of other States._**

**_It says further that no State, group of States or Organization can have any pre-eminent responsibility for maintaining peace and stability in the OSCE area or can consider any part of the OSCE area as its sphere of influence._**

**_At the OSCE Summit in Astana in December 2010, the leaders of our nations approved a declaration that reaffirmed this comprehensive package of interconnected obligations._**

**_However, the Western countries continue to pick up out of it only those elements that suit them, and namely – the right of States to be free to choose alliances for ensuring exclusively their own security._**

**_The words ‘as they evolve’ are shamefacedly omitted, because this provision was also an integral part of the understanding of ‘indivisible security’, and specifically in the sense that military alliances must abandon their initial deterrence function and integrate into the all-European architecture based on collective approaches, rather than as narrow groups._**

**_The principle of indivisible security is_** **_selectively interpreted_** **_as a justification for the ongoing course toward irresponsible expansion of NATO._**

**_It is revealing that Western representatives, while expressing their readiness to engage in dialogue on the European security architecture, deliberately avoid making reference to the Charter for European Security and the Astana Declaration in their comments._**

**_They mention only earlier OSCE documents, particularly often – the 1990 Charter of Paris for a New Europe that does not contain the increasingly ‘inconvenient’ obligation not to strengthen own security at the expense of the security of other States._**

**_Western capitals also_** **_attempt to ignore a key OSCE document_** **_– the 1994 Code of Conduct on Politico-Military Aspects of Security,_** **_which clearly says that the States will choose their security arrangements, including membership in alliances, ‘bearing in mind the legitimate security concerns of other States’_****_._**

**_It will not work that way._**

**_The very essence of the agreements on indivisible security is that either there is security for all or there is no security for anyone._**

**_The Istanbul Charter provides that each OSCE participating State has_** **_equal right to security_****_, and not only NATO countries that_** **_interpret this right as an exceptional privilege of membership in the ‘exclusive’ North Atlantic club_****_._**

While outright ignoring every agreement on **European** security they’ve signed over the past **32-years**, this report details, yesterday it saw **Britain**, **Poland** and **Ukraine** **[announcing that they will collaborate in military moves designed to confront Russia](https://www.rt.com/russia/547986-anti-kremlin-pact-countries/)**—an announcement for war quickly followed by **Ukrainian President Volodymyr Zelensky** **[signing an order to expand his country’s military, including bolstering the ranks of its army by at least 100,000 soldiers](https://www.rt.com/russia/547953-ukraine-massive-military-expansion/)**—after which **Poland** **[announced it had joined Latvia and Lithuania to send shoulder-fired anti-aircraft missiles (MANPADs) to Ukraine, along with other weapons](https://www.thedrive.com/the-war-zone/44107/poland-says-it-will-send-ukraine-shoulder-fired-anti-aircraft-missiles)**—then it saw **[Ukraine demanding that these warmongering Western nations send it even more weapons](https://www.rt.com/russia/547839-germany-declined-send-weapons-kiev/)**—and in assessing the **West** flooding **Ukraine** with weapons, top **Russian** military strategist retired **Colonel Mikhail Khodarenok** factually observes: “**_[The question is, can they significantly improve Ukraine’s military arsenals and capacity?...Would that be enough to help the Ukrainian Army withstand a Russian Army assault, and prevail in a hypothetical battle?...The answer to both these questions is ‘no’...Russia’s economic and military potential significantly exceeds Ukraine’s...No supplies of single-use missile launchers or MANPADs can balance out the forces – which is why all the involved parties would be better off looking for a diplomatic solution](https://www.rt.com/op-ed/547851-weapons-nato-protect-ukraine-war/)_**”.

Most surprisingly agreeing with **Colonel Khodarenok’s** observation that “**_the involved parties would be better off looking for a diplomatic solution_**”, this report notes, is a new poll just released by **Data for Progress**, a left-leaning progressive think tank, that reveals **American** voters “**_[overwhelmingly support the idea of striking a diplomatic deal with Russia to avoid war over Ukraine](https://www.rt.com/russia/547878-americans-respond-to-idea-of/)_**”, with **[some 58% of respondents in favor](https://www.rt.com/russia/547878-americans-respond-to-idea-of/)**—and even more surprisingly agreeing with **Colonel Khodarenok** is one of **America’s** most powerful and influential leftist publishers **[Katrina vanden Heuvel](https://en.wikipedia.org/wiki/Katrina_vanden_Heuvel)**, who in her open letter just published by the **Washington Post** titled “**[The Exit From The Ukraine Crisis That’s Hiding In Plain Sight](https://www.washingtonpost.com/opinions/2022/02/01/exit-ukraine-crisis-thats-hiding-plain-sight/)**” factually states:

**_The crisis over Ukraine grows simultaneously more dangerous and more absurd._**

**_The only hope is the_** **_Minsk_** **_II_** **_agreement, forged in February 2015 between Russia and Ukraine, brokered by Germany and France, and endorsed by the European Union and the United Nations._**

**_The agreement essentially called for recognition of reality in law._**

**_It guaranteed an independent Ukraine in control of its own borders, with Russian “volunteers” removed, the separatists disarmed and Ukrainian military standing down in the Donbas._**

**_It promised full autonomy for the Russian-speaking region of the Donbas within a decentralized Ukrainian federation, written into a revised constitution._**

**_Samantha Power, then U.S. ambassador to the United Nations, told the Security Council in June 2015, “_****_The consensus here, and in the international community, remains that Minsk’s implementation is the only way out of this deadly conflict_****_”._**

**_What is the alternative?_**  **_For all the screeching of the hawks, there is none in sight._**

**_The Russians have served notice that the status quo can’t go on._**

In speaking at the **United Nations** on **Monday**, this report continues, **Russian Ambassador Vassily Nebenzya** warned the entire world: “**_[Ukraine’s continued refusal to implement the Minsk peace agreements means that Kiev only has itself to blame for its impending destruction…If our Western colleagues are pushing Kiev to sabotage the Minsk agreements, which the Ukrainian authorities are happy to do, this could end in the most disastrous way for Ukraine...And not because someone will destroy it...But because it will destroy itself...And Russia has absolutely nothing to do with it...Don’t try to shift the blame from the sick to the healthy](https://www.rt.com/russia/547922-kiev-blame-crisis-donbass/)_**”—a warning responded to a few hours ago by **Ukrainian Foreign Minister Dmitry Kuleba**, who **[decreed that Ukraine will not abide by the Minsk II agreement they signed promising full autonomy for the Russian-speaking region of Donbass](https://tass.com/world/1396525)**, and declared: “**_[No Ukrainian region will have a right power for national state decisions…This is set in stone!](https://tass.com/world/1396525)_**”.

With **Ukraine** having now “**_set in stone_**” the total obliteration of the **Minsk II** agreement it signed, that even **President Obama’s UN Ambassador Samantha Powers** warned “**_is the only way out of this deadly conflict_**”, this report concludes, it led to the **Kremlin’s** leading foreign policy expert **[Valdai Club Programme Director Ivan Timofeev](https://valdaiclub.com/about/experts/3111/)** presenting to **President Putin** this morning the following **[three scenarios to weigh](https://www.rt.com/russia/547943-west-proposed-security-guarantees/)**:

**Scenario One: War**

**_It is inevitable that amid peaceful conditions, Ukraine will pursue an anti-Russian course._**

**_An outwardly loose but sufficiently stable political regime has been formed in the country, for which compromises with Russia are impossible._**

**_The Ukrainian government itself sees no alternative way of ensuring the country’s security other than through NATO membership._**

**_The West will also work towards integrating Ukraine into its security structures. It is, therefore, impossible to change Ukraine’s course of action without a war._**

**_The Ukrainian army could be defeated relatively quickly, and it is possible to avoid a protracted war by carrying out a lightning-fast operation._**

**_Furthermore, it would then be possible either to divide the country into two states, one of which (Eastern Ukraine) remains in the Russian orbit, and the other (Western Ukraine) in the Western one._**

**_Another option is a forceful regime change in Ukraine, with the expectation that there will be no massive resistance from the population._**

**_Western sanctions will be a painful blow to Russia, but they won’t be fatal._**

**_The benefits to military security are greater than the economic damage._**

**_The harm to the economy will not translate into public protest in Russia; it can be kept under control._**

**_The prestige of the authorities will grow due to their solving a major historical task._**

**_Sanctions against Russia will further undermine confidence in the US-centric financial system._**

**_Russia_** **_will be able to exist as a 'fortress’._**

**_An exit from the global economy is possible, and even desirable._**

**_The West itself is in decline.  Its imminent death is inevitable._**

**_A victory in Ukraine will deal another blow to the authority of the United States and the West, and will accelerate their global retreat._**

**Scenario Two: Permanent Tension**

**_Maintaining permanent tension in relations with the West is producing results._**

**_At least the Western powers are beginning to listen to Russia._**

**_Tension is a useful tool for diplomacy._**

**_It is necessary to keep it on Ukraine’s borders, and to also apply it in other regions – Latin America, the Middle East, the Asia-Pacific Region (together with China), and Africa._**

**_If possible, Russia can operate with relatively cheap but effective campaigns, similar to the Russian operation in Syria._**

**_This scenario does not radically change the situation in Europe._**

**_Relations between Russia and the West remain categorized by rivalry, but do not cross red lines._**

**Scenario Three: Smile And Wave**

**_Ukraine_** **_is a toxic asset for the West.  Large-scale aid is stolen and institutions remain corrupt._**

**_The country is not a supplier, but a consumer of security._**

**_Its NATO membership is counterproductive for the bloc due to unresolved conflicts and dubious contributions to common security._**

**_On the contrary, Ukraine is a source of numerous problems.  Bailing it out is troublesome and costly._**

**_If the West goes for it, then Ukraine will make NATO an even more unbalanced structure, in which the number of ’'free-riders’ will grow._**

**_While it remains in the Western sphere, Ukraine is doomed to further degradation._**

**_There will be a 'Moldovisation of Ukraine’ – that is, an outflow of citizens to the West and the primitivisation of its economy._**

**_The West has no reason to support Ukraine for a long time with its help._**

**_Aid will dwindle as Ukraine’s position slides in the West’s list of priorities._**

**_Without any military intervention, Ukraine will degrade, turning into a peripheral country and a third-order priority in the global agenda._**

**_In this scenario, there is a partial de-escalation of the Ukrainian issue, although rivalry with the West remains._**

**_Moscow skilfully manages such rivalries, facilitating them where possible, and thereby overloading the West with toxic assets in the form of free-riders and fiery liberals._**

\[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](bvv23.jpg)

February 2, 2022 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[“_Destruction Of The World_” Forecasted Thanks To “_Amazing Stupidity_” of Americans](https://www.whatdoesitmean.com/index3808pl.htm)**

**[Fear Stalking America Awakens Europe To True Terror](https://www.whatdoesitmean.com/index3808.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/index.htm)**