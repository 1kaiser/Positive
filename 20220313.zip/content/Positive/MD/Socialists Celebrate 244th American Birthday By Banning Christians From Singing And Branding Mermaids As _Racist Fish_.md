        Socialists Celebrate 244th American Birthday By Banning Christians From Singing And Branding Mermaids As “Racist Fish”  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

July 4, 2020

**Socialists Celebrate 244th American Birthday By Banning Christians From Singing And Branding Mermaids As “_Racist Fish_”**

By: Sorcha Faal, and as reported to her Western Subscribers

A truly despairing new **Ministry of Foreign Affairs** ([MoFA](http://government.ru/en/department/92/events/)) report circulating in the **Kremlin** today noting the call made yesterday by **President Putin** for [public, rather than state control over the promotion of subversive values spread by propaganda in **Russia**](https://tass.com/society/1174575), says this normal societal function has broken down in the **United States**, where on its **244th** birthday celebrated every **4 July Weekend** since its founding, headlines are now appearing saying such things like “**[On Birthday 244, America Is Upside Down — And It’s Scary](https://www.sungazette.com/opinion/other-commentaries/2020/07/on-birthday-244-america-is-upside-down-and-its-scary/)**” and it being warned: “**_[It is clear that the political left has gone so far off the rails into its own cultism that there is no coming back…There can be no reconciliation between the two sides, so we must separate, or we must fight](https://www.zerohedge.com/political/america-heading-civil-war)_**”—all which is being caused by the crushing wave of socialist tyranny sweeping over **America**, that over the past few days saw tyrant **Governor Gavin Newsome** of the socialist **Democrat Party** stronghold **State of California** **[shockingly banning all Christian peoples from singing songs to God in their churches](https://www.rt.com/usa/493781-california-bans-singing-church/)**—after which tyrant **Governor Newsome** shut down the majority of **California’s** wineries and bars for this holiday weekend, **[except for his own](https://www.redstate.com/jenvanlaar/2020/07/02/ca-gov-newsom-shuts-down-majority-of-states-wineries-for-4th-of-july-but-not-his-own/)**, which **[he bragged about doing in social media posts](https://www.thegatewaypundit.com/2020/07/newsoms-winery-deletes-instagram-post-bragging-open-4th-july-weekend-major-public-backlash/)**—and to display to the fearful and cowering **American** people how extensive their global reach is, then saw these socialists defacing the world beloved **Hans Christian Anderson** statue of “**_[The Little Mermaid](https://en.wikipedia.org/wiki/The_Little_Mermaid_(statue))_**” in **Copenhagen-Denmark** by branding it as a “**_[Racist Fish](https://pjmedia.com/news-and-politics/rick-moran/2020/07/03/little-mermaid-statue-in-copenhagen-branded-racist-fish-n602831)_**”—a branding done in **English**, not **Danish**—thus making it unmistakably clear whom this socialist message of hate and fear was intended for.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](rff23.jpg)

![](rff24.jpg)

![](rff21.jpg)

According to this report, in the socialist **Democrat Party** stronghold **State of Oregon**, specifically its radical communist run **City of Portland**, for **120-years**, since **1900**, stood an historic outdoor fountain and bronze sculpture created by the world renowned **American** artist **[Roland Hinton Perry](https://en.wikipedia.org/wiki/Roland_Hinton_Perry)** called “**_[The Elk](https://en.wikipedia.org/wiki/Elk_(sculpture))_**”—that is until this past **Wednesday**, on **1 July**, when a **[socialist mob descended upon it, defaced it with the spray painted words “_Oink-Oink_”, then set a raging fire underneath it to melt it into oblivion](https://ktvz.com/news/oregon-northwest/2020/07/02/iconic-120-year-old-portland-elk-statue-removed-after-fire-set-during-protest/)**—and which no police forces stepped in to stop. 

Not being understood by the **American** people as to why socialist mobs would attack statues of elk animals and mermaids, this report explains, is that these **Marxists** who want to destroy the **United States** as a free republic and establish an authoritarian socialist state in its place are also terrorists, and terror is one of their principal tactics—who want those they terrify to think that the ground is unsteady beneath their feet, that the old order is crumbling, and that they represent the new, energized vanguard—or what the **Islamic** terrorist **Osama bin Laden**, called “**_The Strong Horse_**”—and as best documented in the **2010** non-fiction historical book “**[The Strong Horse: Power, Politics, and the Clash of Arab Civilizations](https://www.amazon.com/Strong-Horse-Power-Politics-Civilizations/dp/0767921801)**”—whose title is drawn from **Osama bin Laden’s** assertion that “**_When people see a strong horse and a weak horse, by nature they will like the strong horse_**”.

As **Osama bin Laden** knew when he launched his **11 September 2001** attacks against **America**, this report details, “**_The Strong Horse_**” principle is designed to make you think that at any moment, you yourself could be targeted and destroyed, even if you’re an innocent—and as used by socialist forces in **America** today, sees them forcing innocent people to cower in fear lest they be accused of wrongthink and having unacceptable political opinions—**Marxist** terrorist tactics exhaustively documented by the late **Nobel Prize** winning **Soviet** dissident **[Aleksandr Solzhenitsyn](https://en.wikipedia.org/wiki/Aleksandr_Solzhenitsyn)** in his monumental work **[The Gulag Archipelago](https://www.amazon.com/Gulag-Archipelago-Aleksandr-Solzhenitsyn/dp/1843430851)** depicting what life is like under tyrannical socialist rule—who explained that socialist terror is deliberately designed to be random, unpredictable and seemingly senseless in order to force a population into fear about what is going to happen next, or even worse who is going to be attacked next—as a terrorized population is a docile one, where a relaxed one might have the leisure to start entertaining thoughts of resistance—“**_[so the elk had to get it](https://pjmedia.com/news-and-politics/robert-spencer/2020/07/03/no-theyre-not-stupid-why-leftists-destroyed-a-statue-of-an-elk-in-portland-n603513)_**”—because the destruction of **Portland’s** elk statue is a socialist mob warning to the rest of **America** that “**_[You’re Next](https://pjmedia.com/news-and-politics/robert-spencer/2020/07/03/no-theyre-not-stupid-why-leftists-destroyed-a-statue-of-an-elk-in-portland-n603513)_**”.

![](rff25.jpg)

![](rff26.jpg)

In **1990**, this report continues, the former **Soviet Union** restored the citizenship of **Aleksandr Solzhenitsyn**—but who didn’t return to the **Motherland** until **1994**, which was after the **Russian Federation** had destroyed the **Soviet Union** and its godless socialists—and from where **Solzhenitsyn** saw **President George W. Bush** becoming “**_The Strong Horse_**” over **Osama bin Laden** after **America** was attacked on **9/11**—but in **2007**, saw **Solzhenitsyn** becoming gravely concerned over the rise of socialist forces in **America**—a concern so great, it caused **Solzhenitsyn** to travel to **Washington D.C.** where, on **30 June 2007**, he gave first major public address since his expulsion from the **Soviet Union** in **1974**—one of the most historic addresses in modern times now known as “**[Words of Warning to the Western World](http://www.orthodoxytoday.org/articles7/SolzhenitsynWarning.php)**”—and in which **Solzhenitsyn** said:

**_I would like to call upon America to be more careful with its trust and prevent those wise persons who are attempting to establish even finer degrees of justice and even finer legal shades of equality - some because of their distorted outlook, others because of short-sightedness and still others out of self-interest - from_** **_falsely using the struggle for peace and for social justice to lead you down a false road_****_._**

**_Because they are trying to weaken you; they are trying to disarm your strong and magnificent country in the face of this fearful threat - one which has never been seen before in the history of the world_****_._**

As history now records, this report notes, this grave warning **Solzhenitsyn** issued to **America** was ignored—that is until **2016** when **President Donald Trump** was elected to power, who has now become one of the most powerful “**_Strong Horse_**” leaders the **United States** has seen in generations, and shortly after assuming office, traveled to **Poland** where he gave his own “**[Defense of Western Civilization](https://www.whitehouse.gov/briefings-statements/remarks-president-trump-people-poland/)**” address to the world that saw him remarkably saying: 

**_As I stand here today before this incredible crowd, this faithful nation, we can still hear those voices that echo through history._** 

**_Their message is as true today as ever._** 

**_The people of Poland, the people of America, and the people of Europe still cry out_** **_“_****_We want God_****_”._**

**_What we’ve inherited from our ancestors has never existed to this extent before._** 

**_And if we fail to preserve it, it will never, ever exist again.  So we cannot fail._**

Just hours ago, at one of his nation’s most honored memorials known as **Mount Rushmore**, this report concludes, **President Trump** once again came to the defense of **Western** **Civilization** and his own under socialist siege **American** citizens—a rousing defence that saw **President Trump** **[declaring unequivocally that these godless socialist forces would never win out and be able to destroy the United States](https://www.rev.com/blog/transcripts/donald-trump-speech-transcript-at-mount-rushmore-4th-of-july-event)**—and in calling his citizens to arms **[proclaimed](https://www.rev.com/blog/transcripts/donald-trump-speech-transcript-at-mount-rushmore-4th-of-july-event)**:  

**_1776 represented the culmination of thousands of years of Western civilization and the triumph of not only spirit, but of wisdom, philosophy, and reason._**

**_And yet, as we meet here tonight, there is a growing danger that threatens every blessing our ancestors fought so hard for, struggled, they bled to secure._**

**_Our nation is witnessing a merciless campaign to wipe out our history, defame our heroes, erase our values, and indoctrinate our children._**

**_Angry mobs are trying to tear down statues of our founders, deface our most sacred memorials, and unleash a wave of violent crime in our cities._**

**_Many of these people have no idea why they’re doing this, but some know what they are doing._**

**_They think the American people are weak and soft and submissive, but no, the American people are strong and proud and they will not allow our country and all of its values, history, and culture to be taken from them._**

**_This attack on our liberty, our magnificent liberty must be stopped and it will be stopped very quickly._**

**_We will expose this dangerous movement, protect our nation’s children from this radical assault, and preserve our beloved American way of life._**

**_Make no mistake._**

**_This left-wing cultural revolution is designed to overthrow the American Revolution._**

**_In so doing they would destroy the very civilization that rescued billions from poverty, disease, violence, and hunger, and that lifted humanity to new heights of achievement, discovery, and progress. To make this possible, they are determined to tear down every statue, symbol, and memory of our national heritage._**

**_Our people have a great memory._**

**_They will never forget the destruction of statues and monuments to George Washington, Abraham Lincoln, Ulysses S. Grant, abolitionists and many others._**

**_The violent mayhem we have seen in the streets and cities that are run by liberal Democrats in every case is the predictable result of years of extreme indoctrination and bias in education, journalism, and other cultural institutions._**

**_No movement that seeks to dismantle these treasured American legacies can possibly have a love of America at its heart._**

**_Can’t happen._**

**_No person who remains quiet at the destruction of this resplendent heritage can possibly lead us to a better future._**

**_The radical ideology attacking our country advances under the banner of social justice, but in truth, it would demolish both justice and society._**

**_It would transform justice into an instrument of division and vengeance and it would turn our free and inclusive society into a place of a repression, domination, and exclusion._**

**_They want to silence us, but we will not be silenced._**

**_It is time for our politicians to summon the bravery and determination of our American ancestors._**

**_It is time._**

**_It is time to plant our flag and to protect the greatest of this nation for citizens of every race in every city in every part of this glorious land._**

**_For the sake of our honor, for the sake of our children, for the sake of our union, we must protect and preserve our history, our heritage, and our great heroes._**

**_Here tonight before the eyes of our forefathers, Americans declare again, as we did 244 years ago, that we will not be tyrannized, we will not be demeaned, and we will not be intimidated by bad, evil people._**

**_It will not happen._**

![](rff27.jpg)

July 4, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Lincoln-Tsar-Hitler Paradox Of Course Means A Comet Is Coming!](https://www.whatdoesitmean.com/index3255pl.htm)**

**[Blood Soaked Fangs Of New York Times Clutching Throat Of America Ready To Kill Again](https://www.whatdoesitmean.com/index3255.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**