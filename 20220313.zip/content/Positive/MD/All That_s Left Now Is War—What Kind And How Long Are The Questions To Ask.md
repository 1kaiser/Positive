        All That's Left Now Is War—What Kind And How Long Are The Questions To Ask <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

**All That's Left Now Is War—What Kind And How Long Are The Questions To Ask**

![](pppz2.jpg)![](pppz1.jpg)![](ujk1.jpg)

 **_“To every thing there is a season, and a time to every purpose under the heaven...A time to love, and a time to hate; a time of war, and a time of peace.”_**

[Book of Ecclesiastes](https://www.britannica.com/topic/Ecclesiastes-Old-Testament)—an Old Testament book of wisdom literature that belongs to the third section of the biblical canon, known as the Ketuvim (_Writings_).and the Hebrew Qohelet (_Preacher_) whose most quoted section is [Chapter 3, Verses 1-8](https://www.biblegateway.com/passage/?search=Ecclesiastes+3&version=KJV).

**Special Report from Sister Ciara**

**My Dearest Friends:**

In early **2012**, the **Sorcha Faal** began her **120-part** monthly lecture series “**_Total War: the Collapse of the United States and the Rise of Chaos_**”, and for those of you who have graciously aided us and followed, **Part-98** of will shortly be available. (**_See bottom of this page for more information._**)

In aid of this monumental effort having now entered its **8th year**, my **Dear Sisters** have diligently and daily used this great expanse of time to keep true news and facts flowing to you in the hope that what is to occur takes none of you by surprise—with my meager contribution being these monthly letters I send to you.

Such as last month when I sent to you my letter titled “**_[Stone Cold Truth Feared By Elites Points To Viking King Trump Saving America](https://www.whatdoesitmean.com/index3195.htm)_**”, which I began by telling you about one the greatest journalists who ever lived named **[Isidor Feinstein Stone](https://en.wikipedia.org/wiki/I._F._Stone)**—best known as **I.F. Stone**, and whose **[I.F. Stone Weekly](http://www.ifstone.org/)** newsletter was a must read for anyone wanting to know what was true and really happening in our world.

One of today’s counterparts to **I.F. Stone** and his **I.F. Stone Weekly** is **[James G. Rickards](https://dailyreckoning.com/author/jrickards/)** and his monthly subscription newsletter **[Strategic Intelligence](https://agorafinancial.com/publications/awn/)**—which your generous aid allows us to subscribe to so you don’t have to—and is likewise **[subscribed to by institutional investors, government directorates and the US intelligence community](https://dailyreckoning.com/author/jrickards/)**—all of whom, like myself, stood up and took notice this past week when **James** posted a rare public warning article to the masses titled “**_[Is War Next?](https://dailyreckoning.com/is-war-next-2/)_**”—wherein he noted that the arc of history has come full circle with the words: “**_[First came currency wars (1921–1936). Then came trade wars (1930–34) and then finally a shooting war (1939–1945)](https://dailyreckoning.com/is-war-next-2/)_**”—and stated:

**_With history as a guide, we can see that today’s pattern is a repeat of what the world went through in the 1920s and 1930s._**

**_Are we heading for another shooting war with China?_**  **_The signs are not good_****_._**

**_Trade war tariffs can be weaponized to pursue geopolitical goals. Trump is using tariffs to punish China for its criminal negligence (or worse) in connection with the spread of the Wuhan virus to the U.S. and the rest of the world._**

**_This also has historical precedent._**

**_Between June and August 1941, President Franklin Roosevelt placed an oil embargo on Japan and froze Japan’s accounts in U.S. banks._**

**_In December 1941, the Japanese retaliated with the sneak attack on Pearl Harbor._**

**_Will China now escalate its retaliation to the point of armed conflict?_**

**_We’ll find out soon, possibly in the South China Sea or the Taiwan Strait._**

**_The latest reemergence of tensions in Hong Kong only adds kerosene to the fire._**

![](ric21.jpg)

In **September-2018**, a video recorded by **American** tech giant **Google** was “**_[leaked](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)_**” to the public showing what occurred there shortly after the **2016** presidential election—a video that reveals an atmosphere of panic and dismay amongst this tech giant’s leadership—in which **Google** co-founder **Sergey Brin** can be heard **[comparing Trump supporters to fascists and extremists](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)** and saying that they were motivated to vote for him by “**_[boredom](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)_**”, which he said in the past led to fascism and communism.

**Google** vice president for global affairs **Kent Walker** in this video further argued that supporters of populist causes like the **Trump** campaign were motivated by “**_[fear, xenophobia, hatred, and a desire for answers that may or may not be there](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)_**”—then described the **Trump** phenomenon as a sign of “**_[tribalism that’s self-destructive in the long-term](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)_**”—and then said that **Google** must ensure the rise of populism doesn’t turn into “**_[a world war or something catastrophic … and instead is a blip, a hiccup](https://www.breitbart.com/tech/2018/09/12/leaked-video-google-leaderships-dismayed-reaction-to-trump-election/)_**”.

It goes without saying, at least for those who know about such things, that the **American** intelligence community “**_leaked_**” this video to demonstrate whom **Google** owes its allegiance to, as only a nation state as powerful as the **United States** has the capability to break through **Google’s** firewalls to gain access to their most closely guarded secrets—but most important about to note in the here and now, is how **Google’s** vice president **Kent Walker’s** fear of “**_a world war or something catastrophic_**” and **James Rickards** warning this week that “**_The latest reemergence of tensions in Hong Kong only adds kerosene to the fire_**” were just joined by **Communist China’s** rubber-stamp parliament, the **National People's Congress**, **[nearly unanimously approving a resolution today to introduce the sweeping security legislation, which bans secession, subversion of state power, terrorism, foreign intervention and allows mainland China's state security agencies to operate in the city](https://www.cnn.com/2020/05/28/asia/china-npc-hk-security-law-intl-hnk/index.html)**.

![](ric22.jpg)

Along with **Communist China** today defying the world in its bid to destroy **Hong Kong**, yesterday their **National People’s Congress** **[proposed drafting a sovereign immunity law on to allow Chinese people to sue the American State in courts as an act of revenge for the mounting litigation against China for its causing the coronavirus pandemic](https://www.breitbart.com/asia/2020/05/27/china-drafts-sovereign-immunity-bill-to-fight-global-coronavirus-lawsuits/)**—that was swiftly followed by **United States Secretary of State Mike Pompeo** **[officially declaring that Hong Kong is no longer autonomous from mainland China](https://www.marketwatch.com/story/revoking-hong-kongs-special-status-is-trumps-nuclear-option-that-could-trigger-irrevocable-us-china-split-analysts-warn-2020-05-27)**—an official action to empower **President Trump’s** “**_[nuclear option](https://www.marketwatch.com/story/revoking-hong-kongs-special-status-is-trumps-nuclear-option-that-could-trigger-irrevocable-us-china-split-analysts-warn-2020-05-27)_**” that could **[trigger an irrevocable US-China split](https://www.marketwatch.com/story/revoking-hong-kongs-special-status-is-trumps-nuclear-option-that-could-trigger-irrevocable-us-china-split-analysts-warn-2020-05-27)**—and yesterday **[at lightening speed](https://www.courthousenews.com/congress-approves-china-sanctions-over-ethnic-crackdown/)**, too, saw the entire **US Congress** passing a bill for **President Trump** to sign that would **[place crushing sanctions on Communist China for its having created a gulag to imprison its Muslim citizens](https://www.courthousenews.com/congress-approves-china-sanctions-over-ethnic-crackdown/)**—and in passing, saw **US House Speaker Nancy Pelosi** declaring: “**_[Beijing’s barbarous actions targeting the Uighur people are an outrage to the collective conscience of the world](https://www.courthousenews.com/congress-approves-china-sanctions-over-ethnic-crackdown/)_**”.

![](ric23.jpeg)

As a young child growing up in **Germany**, our small farming village about **100 kilometers** (**_62 miles_**) from **Hanover** was largely insulated from the politics and controversies of the times—and contrary to popular modern belief, not all **Germans** were members of the **Nazi Party**—especially those like my parents, extended family and large numbers of farmers who were all congregants of the **[Bekennende Kirche](https://en.wikipedia.org/wiki/Confessing_Church)**—in **English** known as the “**_Confessing Church_**”, and the **Nazis** didn’t bother with because these strictly devout **Christian** farmers would just stop working if bothered too much.

But everything changed for everyone in my village in **October-1943** when army troops arrived and began building large tent cities—tent cities to house some of the tens-of-thousands of refugees coming from **Hanover** whose city had been **[obliterated by a massive Allied bombing attack](https://humanities.exeter.ac.uk/history/research/centres/warstateandsociety/projects/bombing/germany/)**—and which in fact and reality, literally brought war to the doorstep of my home.

Spending some of my most formative young orphaned years in refugee camps, first in the **Netherlands**, and then in **Ireland** where the **Sisters of Sorcha Faal** rescued me, barely any **German**, either young or old, knew what really caused the war that destroyed our lives and country—an ignorance we could not be blamed for, as no one had ever told us the truth about anything—which then determined the course of my life to make sure that what had happened to me never happened to anyone else!

Fortunately for me was that the **Sorcha Faal** and my **Dear Sisters** had dedicated their lives to this mission, too—a mission to make sure that when war shows up on anyone else’s doorstep, they’ll be warned about it as long as possible before it happens, and know what caused it—with the hope being in that knowing, you can protect yourselves and your families, and if possible, maybe even stop it before it happens.

Right now, all that’s left to happen is war—the facts to prove this are true and overwhelming—thus meaning the only questions now needing answers for is how and when it’s going to start, what kind of war is it going to be, and how long will it last.

As of this moment, I can tell you that the strongest evidence shows this being a “**_cold war_**”—one taking on the dimensions of a strategic realigning of global power designed to push **Communist China** into a designated sphere of influence back within in its own borders, like was done to the **Soviet Union**—but could very likely erupt into a “**_hot war_**” if **Communist China** responds like the **Empire of Japan** did and tries to break out of the confines it’s being pushed into.

The so-called “**_coronavirus pandemic_**” is the smoke screen that’s been deployed around this strategic global realignment to keep your attention diverted from what’s really happening—which daily my **Dear Sisters** keep slogging through to find and present to you the facts of what is most critically important for you to know.

This effort, though, needs **YOU** to continue to support it—as everything we’re doing is for **YOU**—and the very last thing we want, is for you to be standing in a refugee camp one day not knowing what happened.  

In times such as these, and as I leave you today, my most earnest prayer is that each and every one of **YOU** will remember and be guided by the words of **Our Lord** that say: “**_[Let each of you look not only to his own interests, but also to the interests of others.](https://www.openbible.info/topics/helping_others)_**”—and— “**_[Give, and it will be given to you. Good measure, pressed down, shaken together, running over, will be put into your lap. For with the measure you use it will be measured back to you.](https://www.openbible.info/topics/helping_others)_**”—for in these gentle words are our hopes, and our ultimate freedom, too.       

With God,

Sister Ciara

Dublin, Ireland

28 May 2020

Our needs today are dire indeed, but, if every one of you reading this gave just $20.00 today, our budget for the entire year would be met!  So, before you click away, ask yourself this simple question….if your knowing the truth about what is happening now, and what will be happening in the future isn’t worth 5 US pennies a day what is?     

[![](do37.jpg)](https://fundrazr.com/f1fYo3?ref=sh_79C0K1_ab_1Kr7htbtQ5H1Kr7htbtQ5H)

_(Please note that those who respond to this appeal, in any amount, will receive, at no charge, Sorcha Faal’s May, 2020/June, 2020 lecture series to the Sisters of the Order titled “Total War: the Collapse of the United States and the Rise of Chaos: Part 98”.  This is another one of the Sorcha Faal’s most important lectures dealing with the coming timelines of war, famine, catastrophic Earth changes and disease as predicted by ancient prophecies.)_

[Continue To Main News Site](https://www.whatdoesitmean.com/)

[](https://www.whatdoesitmean.com/indexnews.htm)