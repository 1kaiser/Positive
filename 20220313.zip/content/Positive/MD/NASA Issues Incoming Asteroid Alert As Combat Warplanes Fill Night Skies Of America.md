        NASA Issues Incoming Asteroid Alert As Combat Warplanes Fill Night Skies Of America  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

**Other reports in this series include:**

**[Trump Convenes Emergency Meeting, Mobilizes NATO, After ANTIFA Leftists Confirmed Training In Venezuela](https://www.whatdoesitmean.com/index2361.htm)**

**[Google Backed ANTIFA Attempt To Assassinate President Trump Captured On Video](https://www.whatdoesitmean.com/index2372.htm)**

**[ANTIFA Terrorists Cripple Canadian Rail System As Train Derailment Attacks Begin Striking America](https://www.whatdoesitmean.com/index3136.htm)**

**[Socialists Declare American Revolution As Low-Intensity Conflict Erupts In United States](https://www.whatdoesitmean.com/index3230.htm)**

**[Russia Designates George Floyd “_Incident_” Psyop Operation—Warns CIA Is Main Target](https://www.whatdoesitmean.com/index3231.htm)**

June 2, 2020

**NASA Issues Incoming Asteroid Alert As Combat Warplanes Fill Night Skies Of America**

By: Sorcha Faal, and as reported to her Western Subscribers

A striking new **Security Council** ([SC](http://en.kremlin.ru/structure/security-council)) report circulating in the **Kremlin** today, whose discussions note **Foreign Ministry** spokeswoman **Maria Zakharova** describing the situation with ongoing mass protests and riots in the **United States** as an “**_[American tragedy](https://tass.com/russia/1162865)_**”, quickly turned its attention to a **Ministry of Defense** ([MoD](https://eng.mil.ru/)) document revealing they’ve just been alerted by the **Planetary Defense Coordination Office** ([PDCO](https://www.nasa.gov/planetarydefense/overview/)) that **NASA** scientists have detected a “**_[potentially dangerous asteroid](https://tass.com/science/1162909)_**” approaching **Earth** on **6 June** having a diameter between **250**\-**570 meters**—that was then followed by a discussion related to **President Donald Trump** having called his nation’s socialist **Democrat Party** governors “**_[fools](https://www.mediaite.com/trump/trump-reportedly-berates-governors-as-fools-jerks-in-conference-call-demands-they-dominate-protesters-with-force/)_**” and “**_[jerks](https://www.mediaite.com/trump/trump-reportedly-berates-governors-as-fools-jerks-in-conference-call-demands-they-dominate-protesters-with-force/)_**” for them having failed to use enough forces to stop the rioting in their **States**—which itself was followed by **President Trump** **[vowing to use military force to restore order himself](https://www.courthousenews.com/trump-tells-cities-to-dominate-protesters-in-unrest-over-floyd-killing/)**—a vow quickly put into action over these past few hours in the night skies over **America**, where into them have **[flooded multiple C-130J and C-17A combat troop loaded warplanes from Fort Riley, Fort Drum, and Fort Bragg that are now arriving into Andrews Air Force Base outside of Washington D.C.](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**—as well as **[five C-17 combat warplanes that have left Fort Bragg flying towards Washington D.C., too](https://www.thedrive.com/the-war-zone/33802/military-helicopters-descend-on-washington-in-bizarre-very-low-altitude-show-of-force)**—the latter of which **[are known to be carrying the US Army’s elite 82nd Airborne Division’s Immediate Response Force](https://www.breitbart.com/politics/2020/06/01/82nd-airborne-division-officially-alerted-to-deploy-to-d-c-amid-riots/)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](tbj22.jpg)

**Planetary Defense Coordination Office warning alert for potentially dangerous asteroid due to near Earth on 6 June…**

![](tbj23.jpg)

**…comes at same time US military helicopters fly low over Washington D.C. rioters (_above_)…**

![](tbj24.jpg)

**…and elite FBI force’s helicopters over fly Washington D.C., too (_above_)…**

![](tbj27.jpg)

![](tbj25.jpg)

![](tbj26.jpg)

**…while radar tracks (_3 photos above_) show US military warplanes flooding into Andrews Air Force Base outside of Washington D.C. during early morning hours of 2 June 2020.**

According to this report, most important to note about the “**_[American tragedy](https://tass.com/russia/1162865)_**” assessment made by **Foreign Ministry** spokeswoman **Zakharova**, was her observation that: “**_[It looks like a curtain has been drawn back to reveal the entire picture the United States has been seeking to hide from people](https://tass.com/russia/1162865)_**”—an “**_entire picture_**” now being revealed that exposes to the **American** people the vile hatred their socialist **Democrat Party** leaders and leftist mainstream media elites have for their own nation and its wellbeing—best exampled in a **[beyond shocking video from 2011 that’s resurfaced](https://www.thegatewaypundit.com/2020/06/watch-resurfaced-joe-biden-speech-shows-urging-chinese-communist-party-increase-influence-united-states/)** showing nominal socialist **Democrat Party** leader **Joe Biden** **[urging the Chinese Communist Party to increase its influence in the United States](https://www.thegatewaypundit.com/2020/06/watch-resurfaced-joe-biden-speech-shows-urging-chinese-communist-party-increase-influence-united-states/)**—which explains why the mainstream leftist media supporting him have **[dropped all of their pandemic fearmongering so they can defend the riots, looting and chaos tearing America apart](https://www.dailywire.com/news/knowles-media-drops-pandemic-fearmongering-to-defend-riots)**. 

In truth and actuality what these now being exposed socialist godless monsters are defending, however, this report notes, are “**_[Leftist Rules](https://saraacarter.com/leftist-rules-target-small-business-owners-during-covid-19-bail-out-anarchist-rioters/)_**” to destroy all small businesses so they can’t reopen from the pandemic lockdowns they’ve been slammed with, while the anarchist rioters who are destroying these businesses are being bailed out of jail as soon as they’ve been arrested—and after leaving jail, these anarchist rioters then **[walk onto streets where piles of bricks have been mysteriously sprouting up near riot hotspots all over the United States](https://www.rt.com/usa/490444-bricks-appear-mysteriously-cities-riots/)**—great multitudes of whom, also, are **[flying Mexican flags as they torch every American Flag they can get their hands on throughout all of the US](https://www.breitbart.com/politics/2020/06/01/photos-rioters-fly-mexican-flags-as-american-flags-are-torched-across-u-s/)**—as well as their **[_defacing every Jewish synagogue they can by spray painting on them the words “Fuck Israel_” and  “_Free Palestine_”](https://pjmedia.com/news-and-politics/tyler-o-neil/2020/06/01/rioters-so-angry-about-george-floyd-they-wrote-free-palestine-on-a-synagogue-n478113)**.

![](tbj30.png)

![](tbj31.jpg)

![](tbj32.jpeg)

![](tbj33.png)

![](tbj28.jpg)

![](tbj29.jpg)

**Overwhelming evidence proves socialist Democrat Party and leftist mainstream media supported riots have nothing to do with death of black man—and everything to do with starting war.**

In this war **Russian** military and intelligence officials have designated as being a “**_[Low-Intensity Conflict](https://www.whatdoesitmean.com/index3230.htm)_**”, this report continues, since **[the “_domestic terror_” killing of a US federal officer during rioting in Oakland-California this past Friday](https://www.forbes.com/sites/jackbrewster/2020/05/30/homeland-security-calls-killing-of-federal-officer-in-oakland-domestic-terrorism/#2a95fb0963a7)**, deadly violence is now sweeping all across the **United States**—where during the past **24-hours** alone:

**[Four St. Louis-Missouri police were shot and wounded during a raging gun battle with socialist rioters](https://www.thegatewaypundit.com/2020/06/four-st-louis-cops-shot-raging-gun-battle-peaceful-protesters/).**

**A shootout with socialist rioters in Las Vegas-Nevada has left a** **[US Marshall wounded after being shot](https://www.thegatewaypundit.com/2020/06/shootout-vegas-u-s-marshal-shot-near-courthouse-lv-officer-shot-near-circus-circus-casino/)****, as well as a** **[Las Vegas police officer clinging to life after being shot in the head](https://www.cbsnews.com/news/las-vegas-police-officer-shot-head/)****.**

**A** **[New York City police officer clinging to life after socialist rioters horrifically ran him over with a car](https://www.rt.com/usa/490464-us-police-officer-nyc/)****.**

**A** **[socialist rioter in Louisville-Kentucky being killed after he made the mistake of opening fire on police and National Guard troops](https://www.fox5ny.com/news/police-and-soldiers-return-fire-killing-man-in-louisville)****.**

**Another** **[socialist rioter killed in Omaha-Nebraska after he tried to kill a small business owner](https://www.breitbart.com/politics/2020/06/01/no-charges-will-be-filed-against-omaha-bar-owner-who-fatally-shot-protester/)****—whom** **[police quickly freed after video showed he had to fire his gun to protect his own life](https://www.breitbart.com/politics/2020/06/01/no-charges-will-be-filed-against-omaha-bar-owner-who-fatally-shot-protester/)****.**

**Self protection not afforded to small business owners in the socialist Democrat Party stronghold of California—where** **[police are now arresting business owners trying to protect their own property](https://www.rt.com/usa/490500-la-looters-standoff-police/)****.**

**That enraged Sheriff Grady Judd from the Free State of Florida to the extent that he went on television and warned all socialist rioters: “****_[If you value your life, they probably shouldn’t do that in Polk County.  Because the people of Polk County like guns, they have guns, I encourage them to own guns, and they’re going to be in their homes tonight with their guns loaded, and if you try to break into their homes to steal, to set fires, I’m highly recommending they blow you back out of the house with their guns.  So, leave the community alone](https://www.breitbart.com/politics/2020/06/01/watch-fl-sheriff-recommends-armed-residents-blow-looters-back-out-of-the-house/)_****”.**

![](tbj34.png)

**Sheriff Grady Judd from the Free State of Florida (_above_) warns socialist rioters to leave his community and its citizens alone, or else be prepared to be blown away.**

Having at his disposal should he need to use it, this report concludes, **President Trump** has available to him what is known as “**[The Insurrection Act Of 1807](https://www.thedrive.com/the-war-zone/33799/this-is-what-the-insurrection-act-of-1807-is-and-how-trump-could-try-to-use-it)**”—a seldom used act that would allow **President Trump** to use federal troops to restore law and order in **America**—but wouldn’t be needed if socialist **Democrat Party** governors would only use the **[over 343,000 troops they have in their own Army National Guard](https://en.wikipedia.org/wiki/Army_National_Guard)**—**Army National Guard** troops used to restore law and order during the **[worst rioting in US history that occurred in 1968](https://www.politico.com/news/magazine/2020/06/01/no-this-isnt-as-bad-as-1968-so-far-294187)**, when **[1,000 buildings were burned in Washington D.C. alone](https://www.politico.com/news/magazine/2020/06/01/no-this-isnt-as-bad-as-1968-so-far-294187)**—but unlike then, today sees these vile socialist **Democrats** and their leftist mainstream media lapdogs supporting this violence and chaos terrorizing their nation—best exampled yesterday when after **President Trump** **[left the media speechless when he walked from the Rose Garden at the White House to visit the historic St. John’s Church rioters had tried to burn down the night before](https://www.redstate.com/beccalower/2020/06/01/donald-trump-leaves-media-speechless-rose-garden-walks-historic-church-burned-riots/)**, he was viciously attacked by godless socialist **Democrat Party** leaders **US House Speaker Nancy Pelosi** and **US Senate Minority Leader Chuck Schumer** for going to this historic church and holding aloft a **Bible**—both of whom blasted **President Trump** for what they said was his “**_[Faith-Dishonoring Photo-op](https://sputniknews.com/us/202006021079494892-dems-pelosi-schumer-knocked-for-blasting-trump-over-his-faith-dishonouring-photo-op-with-bible/)_**”—but in a swift reply to socialist monsters **Pelosi** and **Schumer**, saw thousands of **American** people mockingly exclaiming in near unison the truth that: “**_[If you’re more upset that Trump waved a Bible in front of a church than you are about leftist arsonists setting that church on fire, you might be a Democrat!](https://sputniknews.com/us/202006021079494892-dems-pelosi-schumer-knocked-for-blasting-trump-over-his-faith-dishonouring-photo-op-with-bible/)_**”.

![](tbj21.jpg)

June 2, 2020 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green) (1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Global Battlefields Littered With Coronavirus Dead—But Who’s Winning War?](https://www.whatdoesitmean.com/index3229pl.htm)**

**[All That's Left Now Is War—What Kind And How Long Are The Questions To Ask](https://www.whatdoesitmean.com/index3229.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**