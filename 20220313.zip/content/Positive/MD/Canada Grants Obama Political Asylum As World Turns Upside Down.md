        Canada Grants Obama Political Asylum As World Turns Upside Down  <!-- /\* Font Definitions \*/ @font-face {font-family:Tahoma; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-520077569 -1073717157 41 0 66047 0;} @font-face {font-family:Verdana; panose-1:2 11 6 4 3 5 4 4 2 4; mso-font-charset:0; mso-generic-font-family:swiss; mso-font-pitch:variable; mso-font-signature:-1610610945 1073750107 16 0 415 0;} @font-face {font-family:"Bookman Old Style"; panose-1:2 5 6 4 5 5 5 2 2 4; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:647 0 0 0 159 0;} @font-face {font-family:"Baskerville Old Face"; mso-font-charset:0; mso-generic-font-family:roman; mso-font-pitch:variable; mso-font-signature:3 0 0 0 1 0;} /\* Style Definitions \*/ p.MsoNormal, li.MsoNormal, div.MsoNormal {mso-style-parent:""; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} h1 {margin-top:0in; margin-right:0in; margin-bottom:3.75pt; margin-left:0in; mso-pagination:widow-orphan; mso-outline-level:1; font-size:13.0pt; font-family:"Times New Roman"; color:windowtext; font-weight:bold;} p.MsoCaption, li.MsoCaption, div.MsoCaption {mso-style-noshow:yes; mso-style-next:Normal; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:10.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black; font-weight:bold;} p.MsoBodyText, li.MsoBodyText, div.MsoBodyText {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:windowtext;} a:link, span.MsoHyperlink {color:black; text-decoration:underline; text-underline:single;} a:visited, span.MsoHyperlinkFollowed {color:black; text-decoration:underline; text-underline:single;} p.MsoDocumentMap, li.MsoDocumentMap, div.MsoDocumentMap {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; background:navy; font-size:10.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} p {mso-margin-top-alt:auto; margin-right:0in; mso-margin-bottom-alt:auto; margin-left:0in; mso-pagination:widow-orphan; font-size:12.0pt; font-family:"Times New Roman"; mso-fareast-font-family:"Times New Roman"; color:black;} tt {font-family:"Courier New"; mso-ascii-font-family:"Courier New"; mso-fareast-font-family:"Times New Roman"; mso-hansi-font-family:"Courier New"; mso-bidi-font-family:"Courier New";} p.MsoAcetate, li.MsoAcetate, div.MsoAcetate {mso-style-noshow:yes; margin:0in; margin-bottom:.0001pt; mso-pagination:widow-orphan; font-size:8.0pt; font-family:Tahoma; mso-fareast-font-family:"Times New Roman"; color:black;} span.title1 {mso-style-name:title1; mso-ansi-font-size:15.0pt; mso-bidi-font-size:15.0pt; font-family:Verdana; mso-ascii-font-family:Verdana; mso-hansi-font-family:Verdana; font-weight:bold;} span.byline1 {mso-style-name:byline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.creditline1 {mso-style-name:creditline1; mso-ansi-font-size:7.0pt; mso-bidi-font-size:7.0pt; color:#666666;} span.body-content1 {mso-style-name:body-content1; mso-ansi-font-size:9.0pt; mso-bidi-font-size:9.0pt;} span.dateline {mso-style-name:dateline;} span.dateline-separator {mso-style-name:dateline-separator;} span.SpellE {mso-style-name:""; mso-spl-e:yes;} span.GramE {mso-style-name:""; mso-gram-e:yes;} @page Section1 {size:8.5in 11.0in; margin:1.0in 1.25in 1.0in 1.25in; mso-header-margin:.5in; mso-footer-margin:.5in; mso-paper-source:0;} div.Section1 {page:Section1;} -->       

![](logo322.jpg)

**World's Largest English Language News Service with Over 500 Articles Updated Daily**

**_"The News You Need Today…For The World You’ll Live In Tomorrow."_** 

<!-- e9 = new Object(); e9.size = "728x90,468x60"; //-->

<!-- e9 = new Object(); e9.noAd = 1; e9.popOnly = 1; //-->  

[**What You Aren’t Being Told About The World You Live In**](https://www.whatdoesitmean.com/)

**[How The “Conspiracy Theory” Label Was Conceived To Derail The Truth Movement](http://stateofthenation2012.com/?p=14945)**

**[How Covert American Agents Infiltrate the Internet to Manipulate, Deceive, and Destroy Reputations](https://firstlook.org/theintercept/2014/02/24/jtrig-manipulation/)**

October 17, 2019

**Canada** **Grants Obama Political Asylum As World Turns Upside Down**

By: Sorcha Faal, and as reported to her Western Subscribers

A fascinating new **Ministry of Foreign Affairs** ([MoFA](http://government.ru/en/department/92/events/)) report circulating in the **Kremlin** today noting that on **[19 October 1781](https://en.wikipedia.org/wiki/Siege_of_Yorktown)** the largest military power in the world **[British Empire](https://en.wikipedia.org/wiki/British_Empire)** surrendered to the ragtag army of its **North American** colonists, who then went on to establish the **United States**, says the most enduring legend of this surrender was the **British Army** band playing the ballad “**_[The World Turned Upside Down](https://www.americanrevolution.org/upside.php)_**” whose lyrics include the phrase “**_[If ponies rode men and grass ate the cows...Just what tune was in the air when The World Turned Upside Down?](https://www.americanrevolution.org/upside.php)_**”—an ancient ballad that echoed with full and terrible force into our modern day world a fortnight ago when a likewise **[rag tag Yemeni army obliterated the bulk of the Western armed Saudi Arabian army killing and capturing over 2,500 Saudis soldiers](https://www.theguardian.com/world/2019/sep/29/houthis-claim-killed-hundreds-saudi-soldiers-captured-thousands)**—the stunning repercussions of which saw the **Americans** rushing troops to **Saudi Arabia** to save it from collapsing, the first of which they had to rapidly deploy from **Syria**—and that now has seen former **Democrat Party President Barack Obama** being granted political asylum in **Canada** in a secret agreement reached yesterday with **Canadian Prime Minister Justin Trudeau**—a secret agreement **[Obama thanked Trudeau for by endorsing him in Canada’s upcoming election](https://pjmedia.com/trending/obama-endorses-justin-trudeau/)**—is an asylum deal that will see **[Obama reunited with his younger sister Maya Soetoro-Ng who is already a Canadian citizen](https://www.cbc.ca/news/canada/obama-in-canada-uncle-rocky-and-his-burlington-family-ties-1.771456)**—and was expected to occur as **[Obama is the first President in modern history not to have built a Presidential Library to memorialize his time in office](https://www.nytimes.com/2019/02/20/arts/obama-presidential-center-library-national-archives-and-records-administration.html)**—and who is **[facing likely criminal charges for directing the coup plot against President Donald Trump](https://www.amazon.com/Spygate-Obama-Corruption-5-Eyes-ebook/dp/B07DTC846C)**.  \[Note: Some words and/or phrases appearing in quotes in this report are English language approximations of Russian words/phrases having no exact counterpart.\]

![](peltt2.jpg)

According to this report, the most lucid and frightening document describing the current events now occurring in **America** has recently been released by **[Matt Taibbi](https://en.wikipedia.org/wiki/Matt_Taibbi)**—the award winning international journalist for **[Rolling Stone Magazine](https://en.wikipedia.org/wiki/Rolling_Stone)** whose grimly worded article titled “**_[We're In A Permanent Coup](https://taibbi.substack.com/p/were-in-a-permanent-coup)_**” warns that **Americans** might soon wish they just waited to vote their way out of the **Trump** era—and from his first hand historical knowledge writes:

**_I’ve lived through a few coups. They’re insane, random, and terrifying, like watching sports, except your political future depends on the score._**

**_The kickoff begins when a key official decides to buck the executive._**

**_From that moment, government becomes a high-speed head-counting exercise.  Who’s got the power plant, the airport, the police in the capital? How many department chiefs are answering their phones?  Who’s writing tonight’s newscast?_**

**_We have long been spared this madness in America._**  **_Our head-counting ceremony was Election Day._**  **_We did it once every four years._**

**_That’s all over, in the Trump era._**

![](peltt3.jpg)

Further worth contemplating for its strategic value and understanding, this report continues, is **Taibbi’s** critical analysis of this “**_Permanent Coup_**”—the [most noticeable and important points of which are](https://taibbi.substack.com/p/were-in-a-permanent-coup):

**_The Trump presidency is the first to reveal a full-blown schism between the intelligence community and the White House._**

**_Senior figures in the CIA, NSA, FBI and other agencies made an open break from their would-be boss before Trump’s inauguration, commencing a public war of leaks that has not stopped._**

**_The agencies’ new trick is inserting themselves into domestic politics using leaks and media pressure._**

**_The “intel chiefs” meeting was just the first in a series of similar stories, many following the pattern in which a document was created, passed from department from department, and leaked._**

**_A shocking number of these voices were former intelligence officers who joined Clapper in becoming paid news contributors._**

**_Op-ed pages and news networks are packed now with ex-spooks editorializing about stories in which they had personal involvement: Michael Morell, Michael Hayden, Asha Rangappa, and Andrew McCabe among many others, including especially all four of the original “intel chiefs”: Clapper, Rogers, Comey, and MSNBC headliner John Brennan._**

**_Russiagate birthed a whole brand of politics, a government-in-exile, which prosecuted its case against Trump via a constant stream of “approved” leaks, partisans in congress, and an increasingly unified and thematically consistent set of commercial news outlets._**

**_Imagine if a similar situation had taken place in January of 2009, involving president-elect Barack Obama._**

**_Picture a meeting between Obama and the heads of the CIA, NSA, and FBI, along with the DIA, in which the newly-elected president is presented with a report complied by, say, Judicial Watch, accusing him of links to al-Qaeda. Imagine further that they tell Obama they are presenting him with this information to make him aware of a blackmail threat, and to reassure him they won’t give news agencies a “hook” to publish the news._**

**_Now imagine if that news came out on Fox days later. Imagine further that within a year, one of the four officials became a paid Fox contributor._**

**_Democrats would lose their minds in this set of circumstances._**

**_The country mostly did not lose its mind, however, because the episode did not involve a traditionally presidential figure like Obama, nor was it understood to have been directed at the institution of “the White House” in the abstract._**

**_Trump, at least insofar as we know, has not used section 702 of the Foreign Intelligence Surveillance Act to monitor political rivals.  He hasn’t deployed human counterintelligence “informants” to follow the likes of Hunter Biden.  He hasn’t maneuvered to secure Special Counsel probes of Democrats._**

**_I don’t believe most Americans have thought through what a successful campaign to oust Donald Trump would look like._**

**_Most casual news consumers can only think of it in terms of Mike Pence becoming president._**

**_The real problem would be the precedent of a de facto intelligence community veto over elections, using the lunatic spookworld brand of politics that has dominated the last three years of anti-Trump agitation._**

**_CIA/FBI-backed impeachment could also be a self-fulfilling prophecy._**

**_If Donald Trump thinks he’s going to be jailed upon leaving office, he’ll sooner or later figure out that his only real move is to start acting like the “dictator” MSNBC and CNN keep insisting he is._**

**_Why give up the White House and wait to be arrested, when he still has theoretical authority to send Special Forces troops rappelling through the windows of every last Russiagate/Ukrainegate leaker?_**

**_That would be the endgame in a third world country, and it’s where we’re headed, unless someone calls off this craziness._**

**_Welcome to the Permanent Power Struggle._**

![](peltt4.jpg)

**American people should start asking themselves whom their military forces are going to defend—their constitutionally elected President—or the socialist forces trying to oust him in a coup?**

Seeking to keep in place their **[socialist inspired school-to-prison pipeline that has seen over 30,000 American children under the age of 10 being arrested and criminally charged since being implemented by the Obama-Clinton Regime in 2013](https://www.zerohedge.com/health/school-prison-pipeline-exposed-30000-kids-under-age-10-arrested-2013)**, this report notes, **President Trump’s** opposing of this demonic leftist madness to indoctrinate and enslave his nation’s youth now sees him today being **[subjected to the Soviet-Style secret basement impeachment occurring in the US Capitol](https://www.breitbart.com/politics/2019/10/16/republicans-schiff-secret-basement-impeachment-hearings/)**—secret hearings where **[witnesses are being threatened and pressured to tell the socialist Democrats what they want to hear](https://www.dailywire.com/news/breaking-schiff-pressured-witness-to-say-trump-pressured-ukraine-to-investigate-biden-report-says)**—and when opposed by top **Democrat Party** actual war hero **US Congresswoman Tulsi Gabbard**, saw her being **[attacked for being a “_Russian puppet_”](https://www.rt.com/usa/471007-tulsi-gabbard-cnn-sellers-russia/)** and **[smeared by the New York Times who called her a traitor](https://sputniknews.com/us/201910161077058467-tulsi-gabbard-slams-cnn-nyt-at-dem-debate-for-completely-despicable-smears-over-syria-russia/)**—all of which is occurring at the same time **[Democrat Party leader Nancy Pelosi is leading America towards an economic catastrophe the White House is warning will occur if she doesn’t allow the US-Mexico-Canada trade deal to be voted on soon](https://www.breitbart.com/politics/2019/10/16/exclusive-video-white-houses-peter-navarro-pushes-nancy-pelosi-to-pass-us-mexico-canada-agreement-more-important-than-any-china-deal/)**—and when told this fact yesterday, saw **[Pelosi erupting in unhinged leftist meltdown rage and storming out of the White House](https://www.zerohedge.com/political/pelosi-says-trump-had-meltdown-after-vote-condemning-syria-withdrawal)**. 

![](peltt5.jpg)

With **US House Speaker Pelosi** and her socialist **Democrats** now seeing **[their panic level rise because of the criminal investigation into their intelligence agency led coup plot against President Trump](https://pjmedia.com/rogerlsimon/democrats-fear-of-durham-about-to-reach-panic-level/)**, this report concludes, their erupting into full unhinged meltdown rage is because **[after 1,000 days in office, Trump holds a 50% approval rating with likely voters](https://www.thegatewaypundit.com/2019/10/after-first-1000-days-in-office-president-trump-holds-50-approval-rating-5-points-higher-than-obama-despite-impeachment-scam/)**—despite the continued barrage of fake news and vicious media attacks since he won the **2016** election and this latest impeachment scam—which stands opposed to **[Obama’s approval rating at the same time in his presidency that was 45% despite having a fawning media his entire tenure as president](https://www.thegatewaypundit.com/2019/10/after-first-1000-days-in-office-president-trump-holds-50-approval-rating-5-points-higher-than-obama-despite-impeachment-scam/)**—an astonishing popularity level for **Trump** who’s being **[aided by his nation’s working class citizens who are flocking to his Republican Party because these socialist Democrats are only supporting the rich](https://www.breitbart.com/politics/2019/10/16/dems-rep-rich-working-class-gop/)**—all of whom have **[seen the highest wage growth in their lives under the Trump economy](https://www.breitbart.com/politics/2019/10/16/low-income-american-workers-enjoy-highest-wage-growth/)**—all of which explains why the prestigious election polling firm **Moody Analytics**—**_[who failed only once in their Presidential predictions since 1980](https://www.cnbc.com/2019/10/15/moodys-trump-on-his-way-to-an-easy-2020-win-if-economy-holds-up.html)_**—has now **[declared that Trump is on his way to an easy win in 2020](https://www.cnbc.com/2019/10/15/moodys-trump-on-his-way-to-an-easy-2020-win-if-economy-holds-up.html)**—a “**_win_**” the world prays will be accomplished at the ballot box like it’s supposed to be—but if not, will, beyond all doubt, be secured like all third-world coups end, in blood. 

![](peltt6.png)

**Red** **State** **Trump supporting citizens’ guns _versus_** **Blue** **State** **Pelosi supporting unarmed leftist snowflake mobs shows the wisdom of voting for leaders instead of trying to overthrow them in a coup.**

October 17, 2019 © EU and US all rights reserved. Permission to use this report in its entirety is granted under the condition it is linked  to its original source at WhatDoesItMean.Com. Freebase content licensed under [CC-BY](https://creativecommons.org/licenses/by-sa/2.0/) and [GFDL](https://en.wikipedia.org/wiki/GNU_Free_Documentation_License).

_\[_**_Note_**_: Many governments and their intelligence services actively campaign against the information found in these reports so as not to alarm their citizens about the many catastrophic Earth changes and events to come, a stance that the [Sisters of Sorcha Faal](https://www.whatdoesitmean.com/index7381.htm) strongly disagree with in believing that it is every human being’s right to know the truth. Due to our mission’s conflicts with that of those governments, the responses of their ‘agents’ has been a [longstanding misinformation/misdirection campaign designed to discredit us, and others like us,](https://theintercept.com/2014/02/24/jtrig-manipulation/) that is exampled in numerous places, including_ **_[HERE](https://www.whatdoesitmean.com/indexsf33778855.htm)_**_.\]_

_\[_**_Note:_** _The WhatDoesItMean.com website was created for and donated to the Sisters of Sorcha Faal in 2003 by a small group of American computer experts led by the late global technology guru [Wayne Green](https://en.wikipedia.org/wiki/Wayne_Green)(1922-2013) to counter the propaganda being used by the West to promote their illegal 2003 invasion of Iraq.\]_

_\[_**_Note:_** _The word Kremlin (fortress inside a city) as used in this report refers to Russian citadels, including in Moscow, having cathedrals wherein female Schema monks (Orthodox nuns) reside, many of whom are devoted to the mission of the Sisters of Sorcha Faal.\]_

**[Democrat Party “_Burn The Ships!_” Strategy To Destroy Trump Forewarns American Annihilation](https://www.whatdoesitmean.com/index2995pl.htm)**

**[Lucifer Unleashed Against President Trump As Last Stand For America Begins](https://www.whatdoesitmean.com/index2995.htm)**

**[“_Ghost Warrior_” Wants Trump Assassinated—Hints It’s Coming Soon](http://whatdoesitmean.com/index2968pl.htm)**

**[Return To Main Page](https://www.whatdoesitmean.com/)**